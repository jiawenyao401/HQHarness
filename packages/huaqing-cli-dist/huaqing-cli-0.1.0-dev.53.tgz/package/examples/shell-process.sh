#!/bin/sh
# Usage: shell-process.sh OPERATION [CONFIG_FILE [PROFILE]] [-- WRITE_FLAGS] < input.json
# HUAQING_NODE selects one executable. HUAQING_CLI_ENTRY selects an absolute CLI entry.
# This process forwards stdin and replaces itself with the CLI. It does not retry.
set -eu

usage() {
  printf '%s\n' 'Usage: shell-process.sh OPERATION [CONFIG_FILE [PROFILE]] [-- --yes --idempotency-key KEY --dry-run] < input.json' >&2
  exit 2
}

[ "$#" -ge 1 ] || usage
case $1 in
  ''|-*|*[!A-Za-z0-9._-]*) usage ;;
esac
huaqing_operation=$1
shift
huaqing_config=
huaqing_profile=
if [ "$#" -gt 0 ] && [ "$1" != '--' ]; then huaqing_config=$1; [ -n "$huaqing_config" ] || usage; shift; fi
if [ "$#" -gt 0 ] && [ "$1" != '--' ]; then huaqing_profile=$1; [ -n "$huaqing_profile" ] || usage; shift; fi
if [ "$#" -gt 0 ]; then [ "$1" = '--' ] || usage; shift; fi
huaqing_confirm=
huaqing_key=
huaqing_dry_run=
while [ "$#" -gt 0 ]; do
  case $1 in
    --yes) [ -z "$huaqing_confirm" ] || usage; huaqing_confirm=yes; shift ;;
    --dry-run) [ -z "$huaqing_dry_run" ] || usage; huaqing_dry_run=yes; shift ;;
    --idempotency-key) [ "$#" -ge 2 ] && [ -n "$2" ] && [ -z "$huaqing_key" ] || usage; huaqing_key=$2; shift 2 ;;
    *) usage ;;
  esac
done
huaqing_node=${HUAQING_NODE:-node}
case $huaqing_node in
  -*) usage ;;
esac
if [ -n "${HUAQING_CLI_ENTRY:-}" ]; then
  case $HUAQING_CLI_ENTRY in
    /*) huaqing_entry=$HUAQING_CLI_ENTRY ;;
    *) usage ;;
  esac
else
  huaqing_install_dir=$(CDPATH= cd -P "$(dirname "$0")/.." && pwd)
  huaqing_entry=$huaqing_install_dir/dist/cli.js
fi

set -- "$huaqing_entry" api call "$huaqing_operation" --input - --format json --non-interactive
if [ -n "$huaqing_config" ]; then set -- "$@" "--config=$huaqing_config"; fi
if [ -n "$huaqing_profile" ]; then set -- "$@" "--profile=$huaqing_profile"; fi
if [ -n "$huaqing_confirm" ]; then set -- "$@" --yes; fi
if [ -n "$huaqing_key" ]; then set -- "$@" "--idempotency-key=$huaqing_key"; fi
if [ -n "$huaqing_dry_run" ]; then set -- "$@" --dry-run; fi
exec "$huaqing_node" "$@"
