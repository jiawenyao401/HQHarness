import { spawn } from 'node:child_process';
import { isAbsolute } from 'node:path';
import { fileURLToPath } from 'node:url';

const defaultCliPath = fileURLToPath(new URL('../dist/cli.js', import.meta.url));
const inputLimit = 8 * 1024 * 1024;
const stdoutLimit = 16 * 1024 * 1024;
const stderrLimit = 64 * 1024;

/**
 * @typedef {object} Envelope
 * @property {1} schemaVersion
 * @property {boolean} ok
 * @property {string} operation
 * @property {unknown} data
 * @property {{code:string,message:string,retryable:boolean,hint?:string}|null} error
 * @property {{requestId:string,status:string}} meta
 * @property {unknown[]} warnings
 */
/**
 * @typedef {object} ProcessResult
 * @property {number|null} exitCode
 * @property {NodeJS.Signals|null} signal
 * @property {Envelope|null} envelope
 * @property {string|null} issue A static process/protocol code. Only null denotes a valid CLI result.
 * @property {boolean} started Whether Node successfully spawned; this does not prove remote dispatch.
 */
/**
 * @typedef {object} RunOptions
 * @property {string} operation Discover supported operations with the CLI's commands/schema entries.
 * @property {Record<string,unknown>} [input]
 * @property {string} [cliPath] Absolute installed dist/cli.js path.
 * @property {string} [configPath]
 * @property {string} [profile]
 * @property {NodeJS.ProcessEnv} [env]
 * @property {AbortSignal} [signal]
 * @property {number} [timeoutMs] CLI budget, 1–300000 ms.
 * @property {number} [graceMs] Startup/shutdown allowance, 1–30000 ms.
 * @property {{confirm?:true,idempotencyKey?:string,dryRun?:true}} [execution] Explicit CLI flag grants; false is omitted by callers.
 */

/** @param {unknown} value @returns {value is Record<string,unknown>} */
function record(value) { return value !== null && typeof value === 'object' && !Array.isArray(value); }

/** @param {string} issue @returns {ProcessResult} */
function unstarted(issue) { return { exitCode: null, signal: null, envelope: null, issue, started: false }; }

/** Validate only the common envelope; operation input/output schemas belong to the CLI.
 * @param {unknown} value @returns {Envelope|null}
 */
function envelopeValue(value) {
  if (!record(value) || value.schemaVersion !== 1 || typeof value.ok !== 'boolean' ||
      typeof value.operation !== 'string' || !Object.hasOwn(value, 'data') || !Array.isArray(value.warnings) ||
      !record(value.meta) || typeof value.meta.requestId !== 'string' || !value.meta.requestId.length ||
      typeof value.meta.status !== 'string') return null;
  if (value.ok ? value.error !== null : !record(value.error) || typeof value.error.code !== 'string' ||
      !value.error.code.length || typeof value.error.message !== 'string' || typeof value.error.retryable !== 'boolean' ||
      (value.error.hint !== undefined && typeof value.error.hint !== 'string')) return null;
  return /** @type {Envelope} */ (value);
}

/**
 * Call one operation without a shell. JSON travels only through stdin, which is always ended.
 * No retries are performed. Check issue before interpreting an envelope, then preserve nonzero
 * CLI results such as 11 or 130 and their requestId for recovery. Stderr is bounded and discarded.
 * POSIX cancellation gives the CLI a grace period. Windows termination may yield no envelope.
 * @param {RunOptions} options
 * @returns {Promise<ProcessResult>}
 */
export async function runOperation(options) {
  if (!record(options)) return unstarted('OPTIONS_INVALID');
  const { operation, input = {}, cliPath = defaultCliPath, configPath, profile, env = process.env,
    signal, timeoutMs = 30000, graceMs = 1000, execution } = options;
  if (typeof operation !== 'string' || !operation.length || operation.startsWith('-') || operation.includes('\0') ||
      typeof cliPath !== 'string' || !isAbsolute(cliPath) || cliPath.includes('\0') ||
      (configPath !== undefined && (typeof configPath !== 'string' || configPath.includes('\0'))) ||
      (profile !== undefined && (typeof profile !== 'string' || profile.includes('\0'))) ||
      !record(env) || Object.values(env).some(value => value !== undefined && typeof value !== 'string') ||
      (signal !== undefined && !(signal instanceof AbortSignal)) ||
      !Number.isSafeInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 300000 ||
      !Number.isSafeInteger(graceMs) || graceMs < 1 || graceMs > 30000) return unstarted('OPTIONS_INVALID');
  if (execution !== undefined && (!record(execution) || Object.keys(execution).some(key => !['confirm', 'idempotencyKey', 'dryRun'].includes(key)) ||
      (execution.confirm !== undefined && execution.confirm !== true) || (execution.dryRun !== undefined && execution.dryRun !== true) ||
      (execution.idempotencyKey !== undefined && (typeof execution.idempotencyKey !== 'string' || !execution.idempotencyKey.length ||
        Buffer.byteLength(execution.idempotencyKey) > 256 || /[\u0000-\u001f\u007f]/u.test(execution.idempotencyKey))))) return unstarted('OPTIONS_INVALID');
  if (signal?.aborted) return unstarted('CANCELLED_BEFORE_START');
  if (!record(input)) return unstarted('INPUT_INVALID');
  let serialized;
  try { serialized = JSON.stringify(input); }
  catch { return unstarted('INPUT_INVALID'); }
  if (typeof serialized !== 'string' || !serialized.startsWith('{')) return unstarted('INPUT_INVALID');
  if (Buffer.byteLength(serialized) + 1 > inputLimit) return unstarted('INPUT_TOO_LARGE');
  const payload = Buffer.from(serialized + '\n');
  const args = [cliPath, 'api', 'call', operation, '--input', '-', '--format', 'json', '--non-interactive', '--timeout', String(timeoutMs)];
  if (configPath !== undefined) args.push(`--config=${configPath}`);
  if (profile !== undefined) args.push(`--profile=${profile}`);
  if (execution?.confirm) args.push('--yes');
  if (execution?.idempotencyKey !== undefined) args.push(`--idempotency-key=${execution.idempotencyKey}`);
  if (execution?.dryRun) args.push('--dry-run');

  /** @type {import('node:child_process').ChildProcessWithoutNullStreams} */ let child;
  try { child = spawn(process.execPath, args, { shell: false, stdio: 'pipe', env }); }
  catch { return unstarted('SPAWN_FAILED'); }
  return new Promise(resolve => {
    let started = false;
    let settled = false;
    let stopping = false;
    let forced = false;
    let pipesForced = false;
    let stdinFailed = false;
    let stdoutBytes = 0;
    let stderrBytes = 0;
    /** @type {string|null} */ let processIssue = null;
    /** @type {Buffer[]} */ const chunks = [];
    /** @type {ReturnType<typeof setTimeout>|undefined} */ let watchdog;
    /** @type {ReturnType<typeof setTimeout>|undefined} */ let hardKill;
    /** @type {ReturnType<typeof setTimeout>|undefined} */ let closeGuard;

    /** @param {number|null} exitCode @param {NodeJS.Signals|null} exitSignal */
    function finish(exitCode, exitSignal) {
      if (settled) return;
      settled = true;
      clearTimeout(watchdog);
      clearTimeout(hardKill);
      clearTimeout(closeGuard);
      signal?.removeEventListener('abort', stop);
      /** @type {Envelope|null} */ let envelope = null;
      let issue = processIssue;
      if (!started) { resolve(unstarted('SPAWN_FAILED')); return; }
      if (issue === null && forced) issue = 'HOST_KILLED';
      if (issue === null && pipesForced) issue = 'STDIO_INCOMPLETE';
      if (issue === null && exitSignal !== null) issue = 'PROCESS_SIGNAL';
      try {
        const output = new TextDecoder('utf-8', { fatal: true }).decode(Buffer.concat(chunks)).trim();
        const parsed = output.length ? envelopeValue(JSON.parse(output)) : null;
        if (!parsed) issue ??= output.length ? 'ENVELOPE_INVALID' : 'ENVELOPE_MISSING';
        else {
          // Unknown operation identifiers deliberately use a safe, fixed operation in CLI errors.
          const unavailable = !parsed.ok && exitCode === 6 && parsed.operation === 'api.call' && parsed.error?.code === 'CAPABILITY_UNAVAILABLE';
          if (parsed.operation !== operation && !unavailable) issue ??= 'ENVELOPE_MISMATCH';
          else {
            envelope = parsed;
            const status = parsed.meta.status;
            const statusMatches = parsed.ok ? status === 'complete' : exitCode === 11 ? ['partial', 'uncertain'].includes(status) : status === 'failed';
            if ((exitCode === 0) !== parsed.ok || exitCode === null || !statusMatches ||
                (exitCode === 11 && parsed.error?.retryable !== false)) issue ??= 'EXIT_MISMATCH';
            if (stdinFailed && parsed.ok) issue ??= 'STDIN_FAILED';
          }
        }
      } catch { issue ??= 'ENVELOPE_INVALID'; }
      chunks.length = 0;
      resolve({ exitCode, signal: exitSignal, envelope, issue, started });
    }

    function stop() {
      if (settled || stopping) return;
      stopping = true;
      // Do not pass signal/timeout to spawn: the CLI must first finalize its own result.
      try { child.kill('SIGTERM'); } catch { /* Final classification uses close, never a raw OS error. */ }
      hardKill = setTimeout(() => {
        if (settled) return;
        forced = child.exitCode === null && child.signalCode === null;
        if (forced) { try { child.kill('SIGKILL'); } catch { /* The bounded close guard remains active. */ } }
        else pipesForced = true;
        child.stdin.destroy();
        child.stdout.destroy();
        child.stderr.destroy();
        // Inherited pipes or an OS-level termination failure must not wait forever.
        closeGuard = setTimeout(() => { child.unref(); finish(child.exitCode, child.signalCode); }, graceMs);
      }, graceMs);
    }

    child.once('spawn', () => { started = true; });
    child.once('error', () => { processIssue = started ? 'PROCESS_ERROR' : 'SPAWN_FAILED'; });
    child.once('close', finish);
    child.stdin.on('error', () => { stdinFailed = true; });
    child.stdout.on('data', chunk => {
      stdoutBytes += chunk.length;
      if (stdoutBytes > stdoutLimit) {
        processIssue = 'OUTPUT_LIMIT';
        chunks.length = 0;
        stop();
      } else if (processIssue === null) chunks.push(chunk);
    });
    child.stderr.on('data', chunk => {
      stderrBytes += chunk.length;
      if (stderrBytes > stderrLimit) { processIssue = 'OUTPUT_LIMIT'; stop(); }
    });
    for (const stream of [child.stdout, child.stderr]) stream.on('error', () => { processIssue = 'STDIO_FAILED'; stop(); });
    signal?.addEventListener('abort', stop, { once: true });
    // The CLI's budget starts after startup. Give it one allowance before host intervention.
    watchdog = setTimeout(stop, timeoutMs + graceMs);
    if (signal?.aborted) stop();
    try { child.stdin.end(payload); }
    catch { stdinFailed = true; }
  });
}
