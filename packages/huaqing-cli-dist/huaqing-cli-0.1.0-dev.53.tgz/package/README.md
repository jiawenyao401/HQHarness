# 华清 CLI

华清 CLI 是供终端和 Agent Harness 使用的独立 TypeScript 工具。它通过 OA 应用会话访问泛微 OA，也支持按需接入 A 端知识库和企查查。A 账号、OA 应用会话和 OA 操作者分别配置。

CLI、结构化 API 和 MCP 共用操作目录与执行器。OA 基础能力提供认证、人员、文件、发票和通用流程操作。业务 Workflow Skill 调用这些操作完成报销，按任务选择模板、收集事实并核对回执。

## 从源码运行

需要 Node.js 24.19.0 或更新的 24.x 版本。在仓库根目录运行：

```sh
npm ci --ignore-scripts
npm run build
node dist/cli.js info --format json --non-interactive
node dist/cli.js doctor --format json --non-interactive
node dist/cli.js schema oa.file.inspect --format json
node dist/cli.js skills list --format json
```

这些示例可离线运行。后续示例使用已安装的 `huaqing`，从源码运行时可换成 `node dist/cli.js`。

```sh
npm pack
npm install --global --ignore-scripts ./huaqing-cli-0.1.0-dev.49.tgz
huaqing --version
```

当前源码版本为 `0.1.0-dev.49`。也可用 `npm install --prefix /absolute/private-cli --ignore-scripts` 安装本地 tarball，并以该目录下的 `node_modules/.bin/huaqing` 作为宿主入口。打包时保留 npm 生命周期，以生成编译产物并随包提供锁定依赖图。

## 配置 OA

创建 JSON 配置文件。示例中的地址、租户、企业和 OA 人员 ID 均需替换为实际部署值。

```json
{
  "schemaVersion": 1,
  "defaultProfile": "oa-test",
  "profiles": {
    "oa-test": { "connections": { "oa": "custom-oa-test" } }
  },
  "connections": {
    "custom-oa-test": {
      "provider": "oa",
      "environment": "test",
      "baseUrl": "https://oa.example.invalid/papi/openapi",
      "tenantKey": "TEST_TENANT",
      "corpId": "TEST_CORP",
      "appKeyRef": "env:HUAQING_OA_TEST_APP_KEY",
      "appSecretRef": "env:HUAQING_OA_TEST_APP_SECRET",
      "operatorId": "123456789"
    }
  }
}
```

```sh
huaqing profile show oa-test --config /absolute/config.json --format json
huaqing auth login --provider oa --config /absolute/config.json --profile oa-test --format json --non-interactive
huaqing oa identity verify --config /absolute/config.json --profile oa-test --format json --non-interactive
huaqing doctor --provider oa --live --config /absolute/config.json --profile oa-test --format json --non-interactive
```

- `operatorId` 使用已核实的 OA `queryEmployee.id`，并作为字符串保存。可先用 `oa person resolve --name '正式姓名'` 查找唯一匹配。应用登录与人员核验分别执行。
- 应用凭据支持 `env:`、`file:`、`keyring:` 引用。默认令牌后端为系统钥匙串。无桌面环境可设置 `HUAQING_CREDENTIAL_STORE=encrypted-file`，并通过独立密钥挂载设置 `HUAQING_CREDENTIAL_MASTER_KEY_FILE`。
- `--config` 选择配置文件。也可通过 `HUAQING_CONFIG_HOME` 指定配置目录，使用 `HUAQING_STATE_HOME` 隔离状态目录。CLI 与 MCP 应沿用同一配置、profile、状态目录和凭据后端。
- `auth status` 检查本地会话元数据，`doctor --live` 才检查实际 OA 接入。内网 HTTP、令牌续期和退出规则见 [OA 连接与命令契约](docs/contracts/oa.md)。

## OA 基础能力

| 任务 | CLI 入口 |
| --- | --- |
| 应用认证与续期 | `auth login/status/logout --provider oa`、`oa auth get-code/token/refresh` |
| 操作者与员工查询 | `oa identity show/verify`、`oa person resolve` |
| 原件摘要与普通附件上传 | `oa file inspect`、`oa file upload` |
| 发票原件上传、可选识别与实体查询 | `oa invoice upload/recognize/query/inspect` |
| 可发起流程搜索与表单解析 | `oa workflow search`、`oa workflow resolve-form` |
| 流程待办、详情与表单元数据 | `oa workflow +todo`、`oa workflow +detail`、`oa workflow fields` |
| 通用草稿创建与主表字段更新 | `oa workflow draft create`、`oa workflow form fill` |

用 `huaqing oa workflow search --keyword '差旅' --resolve-form --format json` 获取当前操作者的候选流程，唯一命中时同时返回表单和字段。多条命中时选定流程，再用 `huaqing oa workflow resolve-form --workflow-id ID --format json` 查询。[OA 搜索与解析契约](docs/contracts/oa.md#搜索可发起流程)

`oa file inspect` 离线读取 1–10 份 PDF、PNG 或 JPEG，按输入顺序返回 SHA-256、媒体类型和字节数。

```sh
huaqing oa file inspect --json '{"paths":["/absolute/materials/invoice.pdf"]}' --format json --non-interactive
huaqing schema oa.invoice.materials.check --format json
```

发票有可读文本时，使用原件中的票号、开票日期、购买方和价税合计进行材料核对。扫描支持材料可由宿主转为页图后交给多模态模型读取。票面字段缺失且已获准时，可单独调用 `oa invoice recognize`，由 OA 识别原件并返回票面字段。入库和专栏关联分别检查回执。[材料事实契约](docs/contracts/material-facts.md) · [票据保存契约](docs/contracts/invoice-save.md)

## 报销 Workflow

差旅报销通过 [oa-workflow-expense](skills/oa-workflow-expense/SKILL.md) 分步调用。先核对原件、差旅模板与票池，再创建并回读材料草稿。可复用的票据沿用已核验的实体 ID。需要新增的票据通过 `oa expense invoice save` 入库，随后用 `oa expense invoice link` 写入发票专栏并回读。普通支持 PDF 进入附件栏。

差旅与往返居住地分别使用 `travelExpense`、`homeTravelExpense`。新测试差旅可配置经部署核实的 `workflowId`、`formId` 和 `bindingVerification: "creatable-workflow"`，CLI 核对当前操作者可发起的团队流程及实时表单字段。已有 `bindingRequestId` 的部署保留该值供历史执行恢复和单据写保护。默认核验方式、生产差旅与往返居住地仍使用可读参考单。往返居住地当前支持材料草稿及城市查询。[差旅绑定契约](docs/contracts/travel-expense.md#配置测试差旅的固定流程与表单) · [往返居住地契约](docs/contracts/home-travel-expense.md)

```sh
huaqing schema oa.expense.draft --format json
huaqing oa expense draft --dry-run --input intake.json --config /absolute/config.json --profile oa-test --format json
huaqing operations status EXECUTION_ID --config /absolute/config.json --profile oa-test --format json
```

写入须有明确授权，直接调用需要确认及稳定幂等键。收到退出码 11 或缺少可信回执时，保留原输入、键和执行 ID，先查原执行，再按支持范围做只读回查。草稿、票据实体、发票专栏和正式提交各有自己的验收条件。

**dev.44 验收边界**　AgentOS 客户端已在测试 OA 创建并实时回读可编辑的差旅草稿。该轮票据入库受 OA `2069` 和未决执行占用阻塞，专栏关联尚未通过。

## 出差申请 Workflow

普通出差申请使用 `oa workflow travel-application draft`。由部署方配置该 OA 连接的 `travelApplication` 绑定，再通过 CLI 或 MCP 保存及回读草稿。 [业务 Skill](skills/oa-workflow-travel-application/SKILL.md) · [出差申请契约](docs/contracts/oa.md#普通出差申请草稿)

## Agent Harness 接入

**进程调用**使用结构化输入和 JSON 输出。用 `schema OPERATION_ID` 查询单个操作的参数。

```sh
printf '%s\n' '{}' | huaqing api call system.info --input - --format json --non-interactive
```

**MCP stdio** 默认只开放符合当前配置的只读工具，`--tools` 使用操作 ID 白名单。读本机材料须明确 `--file-root`，开放写工具还须传 `--allow-write`。宿主直接发结构化的 `input`，已授权的写操作在 `execution` 中传确认和幂等键。

```sh
huaqing mcp serve --stdio --config /absolute/config.json --profile oa-test \
  --file-root /absolute/materials \
  --tools system.info,oa.file.inspect,oa.workflow.todo
```

AgentOS 部署可使用 `/opt/data/huaqing` 作为持久入口。更新后在实际桌面新会话核对工具目录，必要时重载 MCP。[进程调用契约](docs/harness-process.md) · [MCP stdio 接入](docs/mcp-stdio.md) · [AgentOS 安装说明](docs/skills.md#agentos-报销-skill-安装)

**Skills** 随包交付。报销 Skill 直接依赖 `oa-workflow`、`oa-file`、`oa-invoice`。导出保留依赖和各自的 `references/`。目标须是新目录，父目录须已存在。

```sh
huaqing skills list --format json
huaqing skills export oa-workflow-expense --target-dir /absolute/new-expense-skills --format json
```

## 其他连接与维护

- **A 端知识库**使用独立的 `agentos` 连接和 `auth login --provider agentos`。查询与下载沿用 A 的资源权限。[A 与知识库契约](docs/contracts/agentos.md)
- **企查查**使用独立的 QCC MCP 连接。先用 `qcc tools list` 核对供应商 schema，再使用已批准的企业搜索和详情工具。调用可能计费。[企查查契约](docs/contracts/qcc.md)
- **状态维护**使用 `state inspect`、`state backup`、`state migrate`。状态库保存执行与恢复证据，升级前先备份。[状态备份与回退](docs/state-maintenance.md)
- **开发校验**运行 `npm run check`。命令定义变更后用 `npm run catalog:generate` 同步[生成目录](docs/generated/command-catalog.json)。[CLI 公共契约](docs/contracts/cli.md)
