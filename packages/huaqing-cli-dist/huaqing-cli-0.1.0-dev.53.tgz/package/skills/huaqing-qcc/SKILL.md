---
name: huaqing-qcc
description: 华清企查查指导。发现获准 QCC MCP 工具目录、核对企业查询或详情参数、处理供应商费用及结果未决时使用；依赖 huaqing-shared。
---

# 企查查查询

先加载 [`huaqing-shared`](../huaqing-shared/SKILL.md) Skill，固定已获准的供应商连接和 profile。企业搜索与登记详情各是一次可能计费的调用，按本次任务已有的授权执行。授权范围未覆盖下一次调用时，先确认费用与查询范围。

首次发现目录或核对工具名称、schema 和批准状态时，执行 `qcc tools list`。批准记录由部署方维护。

```sh
huaqing schema qcc.tools.list --format json
huaqing qcc tools list --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

核对企业搜索与登记详情均有准确的已批准工具名称、实际 `inputSchema` 和 `schemaSha256`。官方公司 MCP 使用 `get_company_by_query` 和 `get_company_registration_info`，既有聚合代理使用相应的 `company_` 前缀。两类名称并存时按获准配置选用。缺少批准项或目录变更时，报告具体条件并等待部署方处理。

按名称查企业、按已知标识读取登记详情，或判断查询未决时，读 [`references/company-lookup.md`](references/company-lookup.md)。
