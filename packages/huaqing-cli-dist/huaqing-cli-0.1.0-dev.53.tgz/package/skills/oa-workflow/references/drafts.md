# 创建和填写通用草稿

按 [`references/execution.md`](execution.md) 固定 OA 配置、profile 和授权操作者。核对所选连接的 `workflowDrafts` 已批准该流程及主表字段。现有通用写入范围是获准的主表文本和日期。差旅及往返居住地业务按 `oa-workflow-expense` 的模板步骤办理。

以下 CLI 示例以标准输入接收 JSON。按执行约定核对本次写入授权及稳定任务键，记录原执行以备回查。

## 新建草稿

新建操作 `oa.workflow.draft.create` 接收 `{workflowId,fields:[{fieldId,value}]}`。只有关键词时，按 [`references/read-workflow.md`](read-workflow.md#按关键词查流程) 在搜索时请求表单。已有 `resolvedForm` 时直接使用该结果。已知流程全名或 `workflowId` 时可按 [`references/read-workflow.md`](read-workflow.md#按流程查表单及字段) 读取当前定义。以配置批准的字段和本次业务事实组织输入。

```sh
huaqing schema oa.workflow.draft.create --format json
huaqing oa workflow draft create --input - --idempotency-key STABLE_DRAFT_KEY --yes --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

MCP 宿主可直接调用已开放的 `huaqing_oa_workflow_draft_create`。将同一业务对象传入 `arguments.input`，并在 `arguments.execution` 提供本次确认及稳定键，例如 `{"confirm":true,"idempotencyKey":"STABLE_DRAFT_KEY"}`。

用 `data.requestId`、`data.draftSaved:true` 和 `data.readback:"live"` 核对本次草稿写入。

## 更新已有草稿

更新操作 `oa.workflow.form.fill` 接收 `{workflowId,requestId,fields:[{fieldId,expected,value}]}`。按 [`references/read-workflow.md`](read-workflow.md#查申请单详情) 用 `oa workflow +detail` 取原草稿的 `expected`，原值为空时用 `null`。字段 ID 未知时查 `oa workflow fields`。

```sh
huaqing schema oa.workflow.form.fill --format json
huaqing oa workflow form fill --input - --idempotency-key STABLE_FILL_KEY --yes --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

核对同一 `data.requestId`、`data.saved:true` 和 `data.readback:"live"`。原值冲突时先核对现场。缓存及未决结果按 [`references/execution.md`](execution.md) 判定。
