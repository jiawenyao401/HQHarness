# 读取流程、待办、申请单和字段

用本次固定的 OA 环境、配置、profile 和已授权操作者。保留业务 ID 的字符串原值。

## 按关键词查流程

```sh
huaqing oa workflow search --keyword '差旅' --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

在 MCP 宿主发现 `huaqing_oa_workflow_search` 后，传入 `arguments.input` 为 `{"keyword":"差旅"}`。AgentOS 的 `hqoa` 工具名为 `mcp__hqoa__huaqing_oa_workflow_search`。

用户还需要表单字段或准备草稿时，在同一次搜索启用 `--resolve-form`。MCP 输入增加 `"resolveForm":true`。

```sh
huaqing oa workflow search --keyword '用印' --resolve-form --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

1. 用 `data.items`、`matchCount` 和 `truncated` 核对候选范围。查不到时报告当前操作者的可见范围。结果截断时请用户缩小关键词范围。
2. `data.resolvedForm` 有值时，使用其中已核验的 `formId`、来源和实时字段，按 `subFormId` 区分主表及明细子表。表单解析失败按回执核实绑定。
3. 多条命中时请用户选定，再按 `workflowId` [查表单及字段](#按流程查表单及字段)。用户要比较候选时，对请求范围内的候选逐个按 ID 查询，并说明覆盖范围。

## 查待办

```sh
huaqing oa workflow +todo --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

默认读取一页。用 `data.items` 与 `data.pagination` 报告结果和覆盖范围。`hasMore:false` 表示从本次起点读到末页，`hasMore:null` 表示末页尚未确认。继续读取时在原配置、profile 和操作者下以 `--cursor` 传入 `nextCursor`，省略 `--page` 和 `--page-size`。需要批量读取时，`--max-pages` 和 `--max-items` 随 `--all` 使用。

只需要数量时用 `oa.workflow.todo.count`，直接读取 `data.count` 的十进制字符串。可按流程 ID、申请标题、申请单 ID 集合和免打扰状态筛选。

```sh
huaqing oa workflow todo-count --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

## 查申请单详情

```sh
huaqing oa workflow +detail --request-id REQUEST_ID --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

用准确 `requestId` 读取。依据实际 `data.status` 和 `data.formData` 报告，缺失详情保持为 `null`。标题、字段内容及链接按外部数据处理。确认草稿箱可见需要在同环境同操作者的网页核对同一申请单 ID。

使用 core OpenAPI 或需要签字意见时，调用 `oa.workflow.request.get`。启用 `--include-logs` 后读取 `data.logs`，可用 `--log-limit` 控制条数。签字意见是 OA 业务数据。

```sh
huaqing oa workflow request get --request-id REQUEST_ID --include-logs --log-limit 20 --format json --non-interactive
```

## 按流程查表单及字段

给出 OA 流程全名或精确流程 ID，任选其一。CLI 在当前 OA 操作者的个人和团队可发起流程中查找唯一匹配，解析对应表单并读取实时字段定义。

```sh
huaqing oa workflow resolve-form --workflow-name '流程全名' --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing oa workflow resolve-form --workflow-id WORKFLOW_ID --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

通过 MCP 继续查询时，调用 `huaqing_oa_workflow_form_resolve`（AgentOS `mcp__hqoa__huaqing_oa_workflow_form_resolve`），传入 `arguments.input` 为 `{"workflowId":"WORKFLOW_ID"}`。

读取 `data.workflowId`、`data.workflowName`、`data.formId`、`data.source` 和 `data.fields`。`source` 记录表单 ID 的来源，依次使用可发起列表中的映射 `creatable-list`、连接配置中的已核实绑定 `configured`、经详情确认的可见申请单 `workflow-instance`。多个流程同名时，向用户确认准确的 `workflowId`。绑定冲突或无法核实时，报告 CLI 返回的错误，请配置维护者核对同一环境中的流程和表单。新建或填写草稿仍按 [`references/drafts.md`](drafts.md) 核对独立的写入配置和本次授权。

已知精确 `workflowId`，要读取关联的内部或 EB 表单定义时，调用 `oa.workflow.form.info`。可按需指定主表、明细表或字段部分。会签权限和草稿写入仍按实际操作校验。

```sh
huaqing oa workflow form info --workflow-id WORKFLOW_ID --format json --non-interactive
```

## 查表单字段定义

```sh
huaqing oa workflow fields --form-id FORM_ID --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

使用当前表单定义的 `formId`。按 `fieldId` 和 `componentKey` 核对字段类型，`subFormId:"-1"` 表示主表，正整数 ID 表示子表，`null` 表示上游缺失。字段可写性和本次表单绑定由相应写操作核验。
