# 流程执行与恢复

适用于 [`oa-workflow`](../SKILL.md) 和引用它的业务 Workflow。业务 Skill 负责选择操作、构造业务输入和定义业务完成条件。

## 固定执行上下文

- 核对本次 OA 环境、配置、profile 和已授权操作者。在线命令、状态查询和恢复沿用同一配置、profile、凭据后端与状态目录。通过 [`oa-auth`](../../oa-auth/SKILL.md) 核对应用会话，通过 [`oa-person`](../../oa-person/SKILL.md) 核验操作者。
- 按操作区分流程定义 `workflowId`、表单 `formId` 和实际单据 `requestId`，以配置、原单或读取结果为准。`executionId` 定位一次写入执行，`meta.requestId` 只追踪一次调用。后续业务步骤使用该步骤返回的实际对象 ID，恢复使用原执行 ID。
- 从宿主已发现的工具或 CLI 操作 schema 取得参数。MCP 将业务对象放入 `arguments.input`。CLI 以 `--input -` 接收同一 JSON，送入标准输入后关闭输入。保留业务 ID 的字符串原值，凭据留在配置的存储后端。

## 写入与恢复

每次独立写入先核对本次授权并选定稳定任务键。草稿保存和正式提交分别核对授权。调用前在私有执行上下文保留原 operation、原输入和任务键。返回 `executionId` 时一起记录。后续步骤使用上一步已证实的结果。

- **MCP**。直接调用宿主已开放的业务写工具。用 `arguments.input` 传业务对象，用 `arguments.execution` 传 `{"confirm":true,"idempotencyKey":"TASK_KEY"}`。如需离线预览，只传 `{"dryRun":true}` 作为执行选项。所需业务工具缺失时报告缺项。
- **CLI**。按 [`huaqing-shared/references/execution-recovery.md`](../../huaqing-shared/references/execution-recovery.md) 准备并记录 `executionId`。核对准备结果后用原输入应用同一执行。

`oa.expense.draft` 返回完整回执，且 `meta.status:"failed"`、`data:null`、`error.retryable:false`，错误码为 `OA_OPERATOR_NOT_FOUND` 或 `OA_OPERATOR_AMBIGUOUS` 时，属于派发前的人员校验失败。直接结束本轮并报告本次未创建草稿，按 `error.hint` 请用户核实被报销人或请维护者核实当前 OA 操作者。此时无需查询原任务键。

写入超时、取消、退出码 11 或缺可信回执时，先查原执行，再按该操作支持的范围只读回查。沿用同一 profile、operation、输入和任务键。回查仍无法证实时，报告未决并保留原执行。

- **MCP**。调用 `operations.status`，`arguments.input` 传 `{"executionId":"EXECUTION_ID"}`，或在缺执行 ID 时传 `{"operation":"OPERATION","idempotencyKey":"TASK_KEY"}`。调用 `operations.reconcile` 时在原业务对象中加入查到的 `executionId`，将该对象整体传给 `arguments.input`。
- **CLI**。用 `operations status EXECUTION_ID` 查询，或用 `operations status --operation OPERATION --idempotency-key TASK_KEY` 定位。用 `operations reconcile EXECUTION_ID --input -` 送入原输入回查。

准备返回完整失败回执且 `retryable:false` 时，按明确的字段错误修正有来源支持的输入，或按 `hint` 交给相应维护者。OA 拒绝读取配置模板参考单时，停止写入和后续票据步骤，报告环境、失败阶段、业务码和调用追踪 ID。等待原前置条件恢复，禁止用改日期、移除材料、更换任务键或另找单据试探。

收到 `OA_EXPENSE_RESOURCE_CONFLICT` 时结束当前写入分支。已有原执行 ID 或原任务键时，用 `operations status` 查询一次并报告状态。缺定位信息或原执行只有文件回执时，报告占用未决，交给维护者核实。票夹未匹配、换目标草稿或更换任务键都不能解除原执行的占用。

## 判断业务结果

- `readback:"live"` 表示本次有实时回读，具体确认范围以所选操作和返回证据为准。业务 Skill 核对自己的完成条件。
- `readback:"cached"` 表示返回已有成功执行。要判断当前 OA 状态，按原单号重新查详情。
- 预览或准备只报告已检查的范围。结果未决时报告已有回执、证实范围和 `executionId`。同一单据只有在同环境同操作者的网页核对后，才报告网页可见。
