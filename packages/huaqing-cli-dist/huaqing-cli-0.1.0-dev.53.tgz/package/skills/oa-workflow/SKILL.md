---
name: oa-workflow
description: OA 流程。按关键词搜索可发起流程并查对应表单和字段。也可按流程全名、流程 ID 或表单 ID 查字段，查审批待办或申请单详情，以及新建或更新已配置流程中获准的主表文本或日期草稿。
---

# OA 流程公共能力

先读本 Skill 的 [`references/execution.md`](references/execution.md)，固定上下文和执行规则。调用与错误处理读 [`huaqing-shared`](../huaqing-shared/SKILL.md)。应用会话读 [`oa-auth`](../oa-auth/SKILL.md)，操作者核验读 [`oa-person`](../oa-person/SKILL.md)。业务 Workflow 再按自身 Skill 选择模板、字段和步骤。

| 想做什么 | CLI 子命令 | 按需读 |
| --- | --- | --- |
| 只知道关键词，查可发起流程。需要表单时，同次查询唯一命中的字段 | `oa workflow search`，按需加 `--resolve-form` | [`references/read-workflow.md`](references/read-workflow.md#按关键词查流程) |
| 查当前 OA 操作者的审批待办 | `oa workflow +todo` | [`references/read-workflow.md`](references/read-workflow.md#查待办) |
| 只查当前 OA 操作者的待办数量 | `oa workflow todo-count` | [`references/read-workflow.md`](references/read-workflow.md#查待办) |
| 已知申请单 `requestId`，查状态或表单值 | `oa workflow +detail` | [`references/read-workflow.md`](references/read-workflow.md#查申请单详情) |
| 使用 core 接口查申请单或签字意见 | `oa workflow request get` | [`references/read-workflow.md`](references/read-workflow.md#查申请单详情) |
| 已知流程全名或 `workflowId`，查对应 `formId` 和字段定义 | `oa workflow resolve-form` | [`references/read-workflow.md`](references/read-workflow.md#按流程查表单及字段) |
| 已知 `workflowId`，查关联主表和明细表 | `oa workflow form info` | [`references/read-workflow.md`](references/read-workflow.md#按流程查表单及字段) |
| 已知 `formId`，查工作流字段 ID、类型和子表归属 | `oa workflow fields` | [`references/read-workflow.md`](references/read-workflow.md#查表单字段定义) |
| 给已配置的流程新建仅含获准主表文本或日期的草稿 | `oa workflow draft create` | [`references/drafts.md`](references/drafts.md#新建草稿) |
| 按已核实的原值更新已有草稿的获准主表文本或日期 | `oa workflow form fill` | [`references/drafts.md`](references/drafts.md#更新已有草稿) |

只查报销单状态或详情使用本 Skill。需要办理报销、处理发票专栏或首提完整差旅单时，按 `oa-workflow-expense` 的业务步骤处理。当前待办入口查询 OA 审批待办。消息中心待办、通用同意、拒绝、撤回、已办列表和指定节点意见征询没有已登记入口，遇到这些请求时报告命令覆盖范围。

填写普通出差申请并保存草稿时，加载 `oa-workflow-travel-application`。
