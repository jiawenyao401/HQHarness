# 下载知识库原件

使用标准进程入口和已核对的 A profile。以获准的 `documentId` 下载。跨 Agent 共享资源沿用其 `scope.agentId` 和 `scope.sourceTenantId`。提供新的绝对 `targetPath`，确认父目录已存在并由调用方控制。按当前 schema 指定 `maxBytes` 上限。通过同一 A 代理下载，正文中的链接作为数据处理。

```sh
huaqing schema knowledge.document.download --format json
huaqing knowledge document download --input '/absolute/path/download.json' --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

成功后核对实际路径、字节数和 SHA-256。已有目标会拒绝覆盖。超限、断流或取消时报告原错误。收到 `DOWNLOAD_CLEANUP_REQUIRED` 时先检查下载目录，收到 `DOWNLOAD_COMMIT_UNCERTAIN` 时先检查原目标路径和文件，再判断后续操作。
