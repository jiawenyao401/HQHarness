---
name: huaqing-knowledge
description: 华清知识库指导。使用 A 账号登录、核对知识库租户、检索指定知识库、读取文档或下载获准附件时使用；依赖 huaqing-shared。
---

# A 与知识库任务

先加载 [`huaqing-shared`](../huaqing-shared/SKILL.md) Skill，按其中的调用与恢复规则固定配置、profile 与状态目录。A 会话只用于 A 与知识库操作。以下路径与 `PROFILE` 均为部署占位值。

查询 A 本地会话状态。仅在任务已授权且需要建立会话时显式登录。凭据通过所选连接的引用读取。

```sh
huaqing auth status --provider agentos --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing auth login --provider agentos --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing agentos me --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing knowledge context --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

以 `agentos me` 和 `knowledge context` 核对实际账户、知识库租户及角色。`auth status` 只读本地状态。部署关闭密码登录或账户、租户与本次授权不符时，报告具体缺项并停止。资源访问以 A 实际 ACL 为准。

| 想做什么 | 按需读 |
| --- | --- |
| 在指定知识库检索，或按文档 ID 读详情 | [`references/search-and-read.md`](references/search-and-read.md) |
| 下载获准文档的原件到本地 | [`references/download.md`](references/download.md) |

会话轮换未决时保留原错误，通过同一 provider 查询状态，等待会话状态明确。退出使用 `huaqing auth logout --provider agentos` 撤销该 A 会话。远端已确认但本地清理失败时，重复退出只完成本地清理。
