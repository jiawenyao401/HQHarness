---
name: oa-workflow-expense
description: 办理 OA 差旅报销或往返居住地报销。新建报销先确认被报销人。用于报销材料核对、匹配可关联票据、保存或修改报销草稿、为差旅草稿入库、验真或挂票、补齐差旅财务和正式提交完整差旅单。单独查票、识别或上传发票原件用 oa-invoice。只查审批待办、单据状态或详情用 oa-workflow。
---

# OA 报销工作流

## 新建前确认被报销人

新建报销的第一步是确定唯一的被报销人。先看用户本次是否明确指定。需要从材料确认时，只核对已明确属于本次报销的申请单中标注的被报销人或出差人。

身份缺失、有歧义或冲突时，本轮只回复「这批发票要给谁报销？请提供被报销人的 OA 正式姓名。」确认后再加载后续 reference、查工具参数和处理整批材料。

OA 操作者取当前配置和授权，被报销人取本次已确认的身份，收款人取独立核实的收款信息。发票抬头、AgentOS 账号、OA 操作者和历史草稿都不能作为新报销的被报销人依据。

新建差旅草稿时，先在本次 OA profile 用只读 `oa.person.resolve` 按已确认的正式姓名查找唯一人员，再核对材料和票据。MCP 使用宿主已开放的工具，参数为 `{"input":{"name":"已确认的 OA 正式姓名"}}`。CLI 使用 `oa person resolve --name`。收到 `OA_OPERATOR_NOT_FOUND` 或 `OA_OPERATOR_AMBIGUOUS` 时，报告并请用户核实该环境中的正式姓名和记录唯一性，结束本轮。宿主未开放独立查人工具时，沿用草稿内的精确校验。

按指定单号修改、挂票或查状态时，核对原单。单独查票、上传原件或核对票面材料时，按实际请求执行。

## 选择办理路径

用户只上传发票且用途不明时，先区分核对材料、查询票据和办理报销。办理报销时，按实际行程和用户任务选择差旅或往返居住地，再核对当前 profile 的模板绑定。

直接调用宿主已连接的华清 MCP 或宿主提供的 CLI 进程工具。JSON 业务参数交给该工具，原件摘要用 [`oa-file`](../oa-file/SKILL.md) 的 `oa.file.inspect`，票面读取用宿主文档能力。缺少华清调用工具时报告接入缺项，禁止用 `execute_code`、自写脚本、读取安装源码或直连 OA 代替办理。

## 核对报销模板

进程宿主先用 `profile show` 离线检查 `data.connections.oa.config`，MCP 宿主沿用部署固定的配置和 profile，由所选 operation 校验绑定。差旅检查 `travelExpense`，往返居住地检查 `homeTravelExpense`。绑定缺失、失配或收到 `OA_EXPENSE_BINDING_UNREADABLE` 时，结束本轮办理，报告环境和错误，等待配置维护者核实。报销任务不得从待办、历史会话或旧工具推断或自行写入绑定。仅核对票面材料或只查申请单状态时按对应读取分支处理。

使用当前 profile 已核实的 `workflowId`、`formId` 及模板校验方式。测试差旅的 `creatable-workflow` 模式由 CLI 核对固定流程和表单字段，直接调用草稿操作。默认模式由 CLI 读取配置参考单。`targetRequestId` 只取本轮创建并已回读的草稿 ID，或用户明确指定且已核对的现有草稿 ID。

准备写入、执行写入或回查时，按名称加载 [`oa-workflow`](../oa-workflow/SKILL.md) Skill，读取它目录内的 `references/execution.md`（[`oa-workflow/references/execution.md`](../oa-workflow/references/execution.md)）。

## 任务入口

| 用户实际要做什么 | 入口 | 按需读取 |
| --- | --- | --- |
| 离线核对已从发票或支持材料提取的事实 | `oa invoice materials check` | [`references/material-evidence.md`](references/material-evidence.md) |
| 创建差旅草稿并保留已确认事实 | `oa expense draft`，`materials` 只传支持 PDF 或空数组 | [`references/travel.md`](references/travel.md#新建差旅材料草稿) |
| 按单号读草稿版本、附件和票据引用，或修订差旅文本 | `oa expense inspect` 或 `oa expense amend` | [`references/travel.md`](references/travel.md#读取或修订已有草稿) |
| 已有差旅草稿，给它入库一张新票，或把已有票据实体写入发票专栏 | `oa expense invoice save` 或 `oa expense invoice link` | [`references/travel.md`](references/travel.md#为已有草稿入库或关联) 的「为已有草稿入库或关联」 |
| 为差旅草稿验真一张票 | `oa expense invoice verify` | [`references/travel-complete.md`](references/travel-complete.md#单票验真) |
| 已回读的差旅草稿缺收款账户，且获准用该报销人的历史单据补写 | `oa expense payment fill` | [`references/travel-payment.md`](references/travel-payment.md) |
| 补齐差旅财务 | `oa expense complete` | [`references/travel-complete.md`](references/travel-complete.md#补齐财务) |
| 正式提交已补齐的差旅草稿 | `oa workflow submit` | [`references/travel-complete.md`](references/travel-complete.md#提交完整差旅草稿) |
| 保存往返居住地报销材料草稿，或查本次填单用的城市选项 | `oa expense home-travel draft` 或 `oa city search` | [`references/home-travel.md`](references/home-travel.md) |
| 单独按票号查票、按实体 ID 查详情、识别票面或上传发票原件 | 票据查询、详情、原件识别或上传 | [`oa-invoice`](../oa-invoice/SKILL.md) |
| 只查审批待办、单据状态或通用详情 | 通用流程查询 | [`oa-workflow`](../oa-workflow/SKILL.md) |
| 已有执行记录，查执行进度或恢复未决操作 | `operations status` 或 `operations reconcile` | [`oa-workflow/references/execution.md`](../oa-workflow/references/execution.md#写入与恢复)，差旅回执见 [`references/travel.md`](references/travel.md#恢复原执行) |

新建差旅时，发票单独按 [`references/travel.md`](references/travel.md#新建差旅材料草稿) 入库和关联。报告时分别列出已回读的草稿、票据入库与专栏状态、待补字段。
