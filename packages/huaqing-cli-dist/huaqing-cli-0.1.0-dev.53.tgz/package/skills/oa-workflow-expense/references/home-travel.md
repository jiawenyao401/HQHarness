# 往返居住地报销

新建时，先按 [`oa-workflow-expense`](../SKILL.md#新建前确认被报销人) 确认被报销人，再按 [`oa-workflow-expense`](../SKILL.md#核对报销模板) 核对往返居住地模板。申请人使用已授权的操作者。此分支办理不完整草稿。

1. 核对当前 OA 连接的模板及参考单据，用参考单据验证流程和表单配对。对待填城市调用 `oa.city.search`，它读取随包目录，运行时无需 OA profile。在 `matchedCount:1` 且 `truncated:false` 时记录同一项的 `optionId` 和 `content`。多候选时用国家或省份缩小范围。分别确认出行地、目的地和本人居住地。
2. 从原件确认申请日期、事由和各段行程。时间精确到小时，未知项保留待补。按照 `oa.expense.home.draft` schema 提供 `expenseType:"home-travel"`、`mode:"incomplete"`、已确认的 `reimburseeName`、`applicationDate`、`reason`、`trips` 和 `materials`。材料须有至少一份绝对路径 PDF。图片或 OFD 如需转换，核对完整页面和转换结果。本草稿将发票及支持材料的 PDF 上传为普通附件。票据实体、金额及银行信息分别记为待核实事项。
3. 如需预览先调用草稿命令的 `--dry-run`。按名称打开 `oa-workflow` Skill，读取它目录内的 `references/execution.md`（[`oa-workflow/references/execution.md`](../../oa-workflow/references/execution.md)）。以 `oa.expense.home.draft` 为 operation 保存并回查。同一创建 ID、`draftSaved:true` 和实时回读共同证明已保存。结果仍是待补草稿。

```sh
huaqing oa city search --query '四川省 成都市' --format json --non-interactive
huaqing oa expense home-travel draft --dry-run --input - --format json --non-interactive
```

报告实际状态、已保存材料和待补项。
