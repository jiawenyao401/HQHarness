# 核对报销材料与票面证据

1. 按格式分批。用 [`oa-file`](../../oa-file/SKILL.md) 的 `oa.file.inspect` 一次取得受支持的 PDF、PNG 和 JPEG 原件的 `sha256`。OFD 单列，取得可核对的完整 PDF 转换件后再送检。无法取得转换件时列为待补，继续核对可读原件。按原件内容分类，出差申请单属于支持材料。
2. 用宿主的 PDF 文本读取核对原件。扫描件先用宿主的 PDF 页转图能力，再对页图使用视觉能力。缺少该能力且行程事实无法确认时，请用户提供可读页图或确认缺失事实。
3. 发票的四项票面事实齐全后直接做下方的离线检查。只有确认为发票、仍缺票面事实且已获准在 OA 识别时，才按 [`oa-invoice`](../../oa-invoice/SKILL.md) Skill 的 [`oa-invoice/references/upload-original.md`](../../oa-invoice/references/upload-original.md#识别原件票面) 补取字段。核对识别回执中的 `sha256` 与原件一致。后续确需新票入库，由单票保存步骤处理原件。

为每件材料记录绝对 `path`、根据文件字节计算的 `sha256` 和 `kind`（`invoice`、`support` 或 `unknown`），最多 10 件，单件 16 MiB、总计 32 MiB。离线检查接受 PDF、PNG 和 JPEG。OA 写入使用核实过的 PDF。OFD 如需转换，保留完整页面、图像和版式，并核对原件及转换件。

`invoice` 使用 20 位票号、`format:"cn-20-digit"` 和 `currency:"CNY"`。按 schema 为票号 `number`、开票日期 `date`、购买方 `buyer`、价税合计 `totalAmount` 提供规范 `value` 与原文 `evidence:[{page,quote}]`。日期用 `YYYY-MM-DD`，金额用两位小数字符串，图片页码为 1。未知事实填 `null` 并回到原件核实。净额和税额分别核实后成对提供。航空行程单的票价按票面原义记录。

```sh
huaqing oa invoice materials check --input - --format json --non-interactive
```

检查本批 `data.status` 和 `data.materials[].issues`。`consistent` 表示原件摘要、给定事实和摘录通过离线检查，继续使用同一原件摘要。`needs-review` 表示按条目索引和问题码补证。`NO_INVOICES` 表示本批只有支持材料或分类待定。只办支持材料草稿时，材料由草稿准备核验。离线检查只报告材料事实，发票入库、验真和报销资格按各自回读报告。
