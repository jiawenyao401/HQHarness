# 差旅报销

新建时，先按 [`oa-workflow-expense`](../SKILL.md#新建前确认被报销人) 确认并核对被报销人。办理前按 [`oa-workflow-expense`](../SKILL.md#核对报销模板) 核对差旅模板。下文的 `--dry-run` 命令用于预览。

| 步骤 | operation | 交给下一步的结果 |
| --- | --- | --- |
| 核对整批材料 | `oa.invoice.materials.check` | 已核实的票面事实及绑定原件的摘要 |
| 核对差旅发票专栏 | `oa.expense.invoice.preflight` | `invoiceFieldsVerified:true` |
| 按票面事实匹配可见票据 | `oa.invoice.match` | `matched` 与实体 `infoId`，或已完整查询后的 `absent` |
| 建待补差旅草稿 | `oa.expense.draft` | 同一环境的 `requestId` 及草稿回读 |
| 查目标差旅草稿 | `oa.expense.inspect` | `revision`、附件 ID 和票据引用 |
| 为目标草稿入库一张缺失的发票 | `oa.expense.invoice.save` | 已回读的票据实体 `infoId` |
| 把已核实的发票关联到草稿专栏 | `oa.expense.invoice.link` | 同一草稿的专栏回读和最新 `revision` |

## 新建差旅材料草稿

1. 核实用户授权和本单归属。按 [`references/material-evidence.md`](material-evidence.md) 核对可读材料，`data.status:"consistent"` 才可继续使用该批核对事实。行程日期范围取用户确认或申请单、行程单明确记载的行程。只有住宿、开票日期时，行程范围留待确认。
2. 有可办理的发票时先预检专栏并逐张匹配。复用 `matched` 的 `infoId`，仅在完整查询返回 `absent` 时走入库。票据事实冲突、占用未知或预检失败时，记录对应待补项。用户授权的基础草稿仍可保存。
3. 用 `mode:"incomplete"` 创建待补草稿，按 schema 提供 `travelerName`、`applicationDate`、`reason` 和 `destination`，并传 `fillApplicantOrganization:true` 让 CLI 从 OA 核对并填写申请人的部门和单位。组织核对失败时报告缺项并停在创建前。行程日期范围确证后才传 `travelDates`。把用户确认的餐补标准和本单费用归属浓缩为一行 `confirmedNotes`，由 CLI 写入特殊说明。完整行程时刻、收款资料及待核定金额留待补齐。草稿的 `materials` 只传核对过的支持 PDF 及摘要，或传 `[]`。每张发票留给下面的单票操作。以 `draftSaved:true`、`readback:"live"` 和 `requestId` 确认已存。
4. 检查同一可编辑草稿，保存 `revision`。对每张 `absent` 票据调用 `oa.expense.invoice.save`，输入 `targetRequestId` 和一份经核对的发票 `material`。以 `invoiceSaved:true`、`factsMatched:true` 和 `readback:"live"` 取得已入库的 `infoId`。验真和占用分别看对应证据。入库未决时先沿原执行核实该票。
5. 用已核实且符合关联条件的发票办理专栏关联。输入 `mode:"invoice-link"`、同一 `targetRequestId`、当前 `expectedRevision`、逐票事实和费用说明，申领额仅在已确认时提供且不得超过票面合计。只把 `linkedToDraft:true`、`preservedFieldsMatched:true` 和 `readback:"live"` 的发票报告为已关联。收到 `OA_EXPENSE_INVOICE_USAGE_UNKNOWN` 时停止重试该批关联，报告 `error.details.issues` 中的占用字段路径及当前单号。只有在网页核对同一环境与单号后才报告网页可见。

专栏预检通过只说明表单的票据字段可用，`--dry-run` 通过只说明离线输入可预览。线上准备用同一 OA 应用和操作者校验当前 profile 的流程绑定。收到 `OA_EXPENSE_BINDING_UNREADABLE` 或 `OA_EXPENSE_BINDING_MISMATCH` 时，按公共执行规则报告失败并结束本轮，等待配置维护者修复。

草稿返回人员校验错误时，按 [`oa-workflow/references/execution.md`](../../oa-workflow/references/execution.md#写入与恢复) 判断是否结束本轮或回查原执行。已有回读成功的草稿且本次获准补收款账户时，再加载 [`references/travel-payment.md`](travel-payment.md)。

### 命令与输入

MCP 宿主按当前步骤的 operation 选择已开放的原生工具并读取该工具的参数定义。`oa.expense.draft` 对应 `huaqing_oa_expense_draft`，工具前缀以宿主发现结果为准。草稿、入库和关联分别使用自己的稳定任务键，按 [`oa-workflow/references/execution.md`](../../oa-workflow/references/execution.md#写入与恢复) 直接调用和恢复。

专栏预检接收 `{}`，票据匹配接收已核实的 `number`、`date`、`buyer` 和 `totalAmount`，草稿检查接收 `targetRequestId`。同一 operation 的预览和写入使用同一业务 schema。下列 CLI 示例中的 `PROFILE` 和配置路径替换为宿主已核实的值。

```sh
huaqing oa expense invoice preflight --input - --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing oa invoice +match --input - --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing oa expense draft --dry-run --input - --format json --non-interactive
huaqing oa expense inspect --input - --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing oa expense invoice save --dry-run --input - --format json --non-interactive
huaqing oa expense invoice link --dry-run --input - --format json --non-interactive
```

## 为已有草稿入库或关联

先确认目标差旅草稿的 `requestId`，用草稿检查取得当前 `revision`，再预检专栏。

- **只入库一张新票。** 用 PDF 原件按 [`references/material-evidence.md`](material-evidence.md) 核对事实。匹配完整可见票池并得到 `absent` 后，准备 `oa.expense.invoice.save`，应用后以票据实体 `infoId` 和实时回读报告结果。匹配已有实体时报告该实体并沿用它。单独入库到此结束。
- **关联已有票。** 从原件或已核实的票面资料取得票号、开票日期、购买方和票面合计，确定费用说明。匹配结果须与提供的 `infoId` 一致。缺任一所需事实时先补证。用目标单号、草稿版本及逐票事实准备 `oa.expense.invoice.link`，应用后核对发票专栏回读。已确认的申领额可随关联提交，未知时省略。

## 读取或修订已有草稿

用户只要核对已有差旅草稿的版本或附件与票据引用时，按给定单号执行 `oa expense inspect`，报告实际 `status`、`canEdit`、`revision`、`attachmentIds` 和 `referencedInvoiceIds`。业务完整性以具体办理步骤的回读为准。

明确获准修改现有差旅草稿时，先用 `oa workflow +detail` 读取同一单号的当前表单值。用 `oa.expense.amend` 输入 `targetRequestId` 和 `updates`，只填写待改的事由 `reason` 或目的地 `destination`，每项包含原值 `expected` 和新值 `value`。原值或版本变动时先核实。实时回读改动及未修改字段后，报告结果和执行 ID。

```sh
huaqing oa expense amend --dry-run --input - --format json --non-interactive
```

## 恢复原执行

按 `oa-workflow` Skill 的执行规则回查最后尝试的步骤。已有或可能已有专栏写入时，以关联回读为准。创建草稿的回读覆盖草稿阶段。

单票保存未决时，停止后续写入，用原 `executionId` 在同一 profile 查 `operations status`，按原输入做只读回查。上传回执的 `fileId` 只证明原件上传，票据实体需以已核实的 `infoId` 为准。结果仍未证实时，报告已证实的阶段、未决的票据和原 `executionId`，保留原执行。禁止重传、换任务键或换入口再保存。

历史混合 `materials` 草稿以 `workflowComplete:true`、`invoicesLinkedToDraft:true` 和 `readback:"live"` 一同证明专栏回读。历史调用若明确需要原材料检查入口，沿用 `oa.expense.materials.check`。新任务读 [`references/material-evidence.md`](material-evidence.md)。

```sh
huaqing oa expense materials check --input - --format json --non-interactive
```
