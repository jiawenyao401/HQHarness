# 补写差旅草稿收款信息

1. 核对用户授权及同一张可编辑差旅草稿。用 `oa.expense.inspect` 取得 `targetRequestId` 和最新 `revision`。
2. 调用 `oa.expense.payment.fill`，输入 `targetRequestId` 和 `expectedRevision`。用户指定已归档的来源单据时传 `sourceRequestId`，否则由 CLI 在当前 OA 环境有限查询。CLI 从草稿的出差人身份匹配来源单，在同一付款行核实收款人、开户行和账号。
3. 按 [`oa-workflow/references/execution.md`](../../oa-workflow/references/execution.md) 办理写入和回查。以 `paymentSaved:true`、`preservedFieldsMatched:true` 和 `readback:"live"` 确认账户保存。以 `paymentAmountFilled:true` 确认付款金额，金额只按本单表内已核对的报销合计填写。
4. 来源缺失、账户冲突或已有不同收款信息时，报告当前单号和待核实项。保留原草稿并按同一单号办理。汇报字段填写状态，账号、开户行和收款人原文留在 OA。

```sh
huaqing oa expense payment fill --dry-run --input - --format json --non-interactive
```
