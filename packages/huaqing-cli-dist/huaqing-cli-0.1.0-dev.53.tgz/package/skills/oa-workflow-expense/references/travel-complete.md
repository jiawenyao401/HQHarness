# 差旅验真、完整财务草稿与首提

沿用同一 OA 配置、授权操作者和目标草稿。按 [`oa-workflow-expense`](../SKILL.md#核对报销模板) 核对差旅模板，再按 [`references/travel.md`](travel.md#读取或修订已有草稿) 获取当前 `revision`、附件和票据引用。每一步沿用公共流程执行规则，分别核对该步骤的授权与回读。

## 单票验真

需要验真且已获授权时，先核对票据匹配的唯一实体和原票事实，确认票据未删除、未占用且已使用金额为零。用 `targetRequestId`、票据实体 `infoId` 和已核实票面事实准备 `oa.expense.invoice.verify`。验真可能消耗额度。取得 `verificationObserved:true`、`authenticityVerified:true` 和 `readback:"live"` 后报告验真通过。额度不足或不适用时保留返回的实际状态。

```sh
huaqing oa expense invoice verify --dry-run --input - --format json --non-interactive
```

## 补齐财务

1. 从本次获准来源核实被报销人的 `travelerId`、部门 `departmentId`、单位 `subcompanyId` 和收款明细。缺失组织或账户事实时保留待补草稿。将实际行程连续拆成逐日事实，按小时记录出发和到达时间。从 `oa city search` 返回的唯一城市记录取得 `optionId` 和 `content`，选择规则见 [`references/home-travel.md`](home-travel.md)。
2. 为每个现有附件 ID 记录一项材料决议，可保留支持材料、纳入已核实的发票实体或按已确认理由排除。专用票据实体用自己的 `infoId`，普通附件 ID 保留原用途。
3. 按 schema 用两位小数字符串记录金额。每票分摊额合计等于已核实申领额，申领额至多为票面总额。逐日按交通、住宿、市内交通、其他费用核对分摊，每类等于当日该类费用。全部逐日费用加明确补贴等于收款总额。补贴依据随当日备注提供，含零补贴的依据。
4. 事实齐备且获准补齐时，用同一目标、当前 `expectedRevision` 和本次已核实事实准备 `oa.expense.complete`。取得 `completeDraftObserved:true`、`preservedFieldsMatched:true`、`readback:"live"` 和新 `revision` 后报告完整财务草稿。

```sh
huaqing oa expense complete --dry-run --input - --format json --non-interactive
```

## 提交完整差旅草稿

用户明确允许本单正式提交时，重新核对同一单号、当前 `revision` 和已回读的完整财务事实。`oa.workflow.submit` 接收 `expense` 内的完整事实和当前 `expectedRevision`，签字意见按需填 `remark`。准备后复核本次首提授权。以 `submissionObserved:true`、`fullFormMatched:true`、`readback:"live"` 和实际 `flowStatus` 报告提交。完成条件包括实际非草稿状态及新的 `SUBMIT` 日志。

```sh
huaqing oa workflow submit --dry-run --input - --format json --non-interactive
```
