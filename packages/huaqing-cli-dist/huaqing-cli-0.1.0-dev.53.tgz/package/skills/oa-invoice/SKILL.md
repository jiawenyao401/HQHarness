---
name: oa-invoice
description: OA 发票文件与票据实体。按票号查票夹，按 infoId 读详情，用 OA 从 PDF 原件识别票面字段，或单独上传取得文件回执。为报销单入库、验真或关联发票走 oa-workflow-expense。
---

# OA 发票与票据

先加载 [`huaqing-shared`](../huaqing-shared/SKILL.md) Skill，按其中的共用规则固定已登录的 OA profile 和授权操作者。按用户要的产物区分发票文件、票据实体与报销单。

| 想做什么 | CLI 子命令 | 按需读 |
| --- | --- | --- |
| 按完整 20 位票号查询操作者可见的票据池 | `oa invoice query` | [`references/read-invoices.md`](references/read-invoices.md#按票号查询) |
| 已知票据实体 `infoId`，读取这张票 | `oa invoice inspect` | [`references/read-invoices.md`](references/read-invoices.md#按票据-id-读取详情) |
| 从 PDF 原件取得 OA 识别的票面字段 | `oa invoice recognize` | [`references/upload-original.md`](references/upload-original.md#识别原件票面) |
| 单独上传一份发票原件，取得 `fileId` | `oa invoice upload` | [`references/upload-original.md`](references/upload-original.md#上传原件取回执) |
| 给报销草稿保存发票、验真或填写发票专栏 | `oa-workflow-expense` | 读取对应业务分支 |

普通支持材料的单独上传使用 `oa-file`。用户只给出发票文件且用途不明时，先确认要票面字段、文件回执、票据查询还是办理报销。
