# 读取 OA 票据

使用已登录的 OA profile 和已授权操作者。调用前按当前 CLI schema 核对参数。

## 按票号查询

传入原始 20 位票号字符串，保留前导零。查询覆盖当前操作者可见池内的各报销状态。

```sh
huaqing oa invoice query --number INVOICE_NUMBER --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

核对 `data.items` 和 `data.coverage.complete`。完整覆盖且没有匹配时，报告本次可见范围未找到。存在多个匹配时，保留各匹配并请用户明确目标。覆盖未完成时，报告已扫描范围和 `nextStart`，`nextStart` 是诊断信息。需要扩大覆盖时可在同一上下文内按 schema 调整 `--page-size` 和 `--max-pages` 重新查询。

## 按票据 ID 读取详情

从已有票据记录取得准确 `infoId`。上传得到的 `fileId` 只用于文件回执。

```sh
huaqing oa invoice inspect --info-id INFO_ID --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

核对 `data.item.id` 与请求的 ID 一致。保留金额和状态的原值，缺失字段保持 `null`。查到票据后，报销资格仍按返回的 `eligibility: "unknown"` 报告。要为差旅草稿匹配、入库或挂票时，转到 `oa-workflow-expense` 的对应分支。
