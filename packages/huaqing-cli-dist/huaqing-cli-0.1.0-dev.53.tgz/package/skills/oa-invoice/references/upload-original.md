# 发票原件识别与上传

按 [`oa-invoice`](../SKILL.md) Skill 固定已登录的 OA profile 和授权操作者。原件操作使用配置中的 OA 应用会话及核验后的 `queryEmployee.id`。

## 识别原件票面

需要 OA 从一份 PDF 发票提取票面字段时，使用 `oa.invoice.recognize`。它自行上传原件并调用 OA 的 `is_save=1` 识别模式。该调用会上传文件，可能消耗识别额度，须在本次授权内使用。只查已有票夹时选择 `query` 或 `inspect`。

用标准输入传入绝对 `path` 和可选的原件 `sha256`，再关闭输入。为同一张票的本次识别固定一个任务键。

原生 MCP 调用传 `arguments.input.path`。确认本次上传及识别已获准后，在同一次调用传 `arguments.execution` 为 `{ "confirm": true, "idempotencyKey": "STABLE_RECOGNITION_KEY" }`，将示例值替换为该票的稳定任务键。收到未决回执时查原执行。

```sh
huaqing schema oa.invoice.recognize --format json
huaqing oa invoice recognize --input - --idempotency-key STABLE_RECOGNITION_KEY --yes --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

以 `data.readback:"acknowledged"` 和 `data.facts` 报告本次识别结果，包括票号、开票日期、购买方及价税合计。`data.sha256` 标识识别所用原件，`data.fileId` 是上传回执，`invoiceSaved:false` 表示本次只执行了识别。相同任务键的缓存只恢复回执，`data.facts:null` 时以调用方留存的原始响应为准，否则报告仅取得回执。未决时用原执行 ID 查 `operations status`，报告未决并保留回执，避免重新上传或改用保存入口。

## 上传原件取回执

只需文件回执时使用 `oa.invoice.upload`。获准后上传一份原始 PDF。

用标准输入传入 JSON `{kind:"invoice",path,sha256}` 后关闭输入。`path` 是绝对路径，`sha256` 从原件字节计算。保持该上传的稳定任务键。

```sh
huaqing schema oa.invoice.upload --format json
huaqing oa invoice upload --input - --idempotency-key STABLE_UPLOAD_KEY --yes --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

用 `data.fileId` 和 `data.readback` 报告上传回执。票据实体的 `infoId` 由入库产生。给差旅草稿入库时直接使用 `oa-workflow-expense` 的单票保存步骤，由该步骤接续原件上传和入库。

结果未决时，沿原操作和执行 ID 查询本地执行，按原输入回查已保存的上传回执。`readback:"local-receipt"` 表示恢复了本地回执。缺少完整回执时报告未决，保留原执行及已知证据，等待核实。
