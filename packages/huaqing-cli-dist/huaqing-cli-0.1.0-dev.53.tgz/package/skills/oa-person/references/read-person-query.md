# 查询 OA 人员

已知员工正式姓名或人员记录 ID 时，用已登录的 OA profile 查询。从 `--name` 和 `--id` 中选一个。若办理报销且尚未确认被报销人，先由报销 Workflow 确定要查谁。

```sh
huaqing oa person resolve --name '员工正式姓名' --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing oa person resolve --id OA_PERSON_ID --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

命令会核验结果集完整性及匹配唯一性。成功时把 `data.name` 和 `data.operatorId` 交给调用方，ID 按 `queryEmployee.id` 的原字符串保留。未找到、重名或查询不完整时，先核实输入或补充准确 ID。查询结果可核对已确认的被报销人。实际 OA 操作者由 profile 绑定，见 [`references/operator-identity.md`](operator-identity.md)。
