# 查看和核验 OA 操作者

查看 profile 中配置的 `operatorId` 和本地核验记录时使用 `show`。需要重新核验这个 OA 人员时，在同一已登录的 OA profile 使用 `verify`。

```sh
huaqing oa identity show --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing oa identity verify --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

核对 `data.operatorId`、`data.verificationStatus` 和 `data.expiresAt`。`not-configured` 表示需要部署方先绑定获准的 OA 人员 ID。`verified` 表示该人员记录已核验。具体单据权限以 OA 实际调用为准。
