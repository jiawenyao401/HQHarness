---
name: oa-person
description: OA 人员记录与操作者。用户要按员工准确姓名或人员 ID 查找唯一人员、查看当前 OA 操作者或重新核验该人员记录时使用。
---

# OA 人员与操作者

先加载 [`huaqing-shared`](../huaqing-shared/SKILL.md) Skill，按其中的共用规则固定本次配置和 OA profile。查某位员工和核验当前 profile 的操作者是两种任务。处理 OA 应用登录或令牌时使用 `oa-auth`。

| 想做什么 | CLI 子命令 | 按需读 |
| --- | --- | --- |
| 按准确姓名或人员 ID 找一位员工 | `oa person resolve` | [`references/read-person-query.md`](references/read-person-query.md) |
| 查看配置中的操作者及本地核验记录 | `oa identity show` | [`references/operator-identity.md`](references/operator-identity.md) |
| 重新核验当前 profile 的已配置操作者 | `oa identity verify` | [`references/operator-identity.md`](references/operator-identity.md) |
