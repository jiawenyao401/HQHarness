---
name: huaqing-shared
description: 华清 CLI 共用身份、调用与恢复规则。为 Agent 配置进程或 MCP、发现操作、核对权限及处理未决结果时使用。
---

# 华清 CLI 共用指导

## 1. 发现能力，固定上下文

示例使用安装包提供的 `huaqing` 可执行名。宿主已配置绝对入口时用该入口执行。AgentOS 的华清入口若为 `/opt/data/huaqing`，OA 子命令始终通过该完整路径调用。能力和参数以当前安装的目录及本组 Skill 为准。遇到入口、能力或配置缺失时，停止对应业务步骤并报告缺项。

领域 Skill 已指明 operation 时，只查该操作的 schema。需要发现 Skill 未列出的能力时，再查看当前安装版本的命令目录。参数、类型、效果和输出以实际 schema 为准。

```sh
huaqing --help
huaqing commands list --format json
huaqing commands list --provider oa --format json
huaqing schema system.info --format json
```

对业务调用，确定一个明确的配置文件和 profile，后续调用与恢复都显式传入同一组 `--config` / `--profile`。任务中保持相同的运行环境、凭据后端及持久状态目录。涉及 OA 登录、人员身份、权限或写入时，先读 [`references/oa-identity-and-permissions.md`](references/oa-identity-and-permissions.md) 核对身份与权限，再读对应操作的 Skill。

```sh
huaqing profile show --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

上面的绝对路径和 `PROFILE` 是待替换的部署值。配置只保存凭据引用，秘密由运行环境或凭据存储提供；凭据值不进入业务参数、命令行、对话或报告。OA 可独立运行；按所选 operation 的实际需要准备连接，不要求 A 登录或旧工程文件。

完成条件：已找到可用 operation 及其 schema，并核对本次任务的配置、profile 和连接。缺少能力或连接时，报告具体缺项，保留仍可进行的离线工作。

## 2. 选择宿主已有的调用方式

优先直接调用宿主已连接的华清 MCP 工具，或使用宿主已有的进程调用工具运行安装好的 CLI。OA 步骤只走本组 Skill 对应的公开 operation。按所选 operation 传入 JSON，由工具收集回执。缺少可直接调用的华清入口时，报告宿主接入缺项，等待接入恢复。

**进程调用**：使用固定可执行入口和参数数组，把一份 JSON 对象送入 stdin 后关闭输入；保留非零退出时的 stdout，读取完输出流，再核对退出状态。业务参数采用 `--input -`，不用拼接模型生成的 shell 命令。

`--input` 接收文件路径或 `-`。调用方需要传内联 JSON 时使用 `--json`。

```sh
huaqing api call system.info --input - --format json --non-interactive --timeout 30000
```

该示例的 stdin 为 `{}`，随后发送 EOF。业务调用增加已固定的配置和 profile。每个字段只从一种来源提供：位置参数、命令选项和 JSON 中的同名字段会被拒绝。输入采用一种方式；参数细节查 `huaqing --help` 及 operation schema。

**MCP 调用**：使用宿主实际发现的工具及其 inputSchema，业务对象放在 `arguments.input`；有需要时用允许的 `execution.timeoutMs` 缩短本次预算。profile 名和进程环境在启动时固定，每次调用仍检查连接配置，工具参数不能切换它们。部署入口可离线查看：

```sh
huaqing mcp serve --stdio --help
```

MCP 独占 stdin/stdout；通过宿主 MCP 客户端发工具请求，不向该进程写普通业务 stdin。已有连接优先复用。需要建立连接时，由宿主按明确的 config/profile 启动该入口，工具范围以实际发现结果为准。

完成条件：调用使用已发现的 schema 和固定上下文；进程输入已关闭且输出有界收集，或 MCP 返回了可识别的工具结果。

## 3. 核对结果

CLI JSON 的成功和失败都在 stdout envelope 中；检查 `ok`、`operation`、`meta.status`、`error`、`warnings` 与进程退出状态是否一致。MCP 取 `structuredContent` 中的同一 envelope（仅支持文本的宿主解析其 JSON text），并检查 `isError` 和 `_meta["huaqing/exitCode"]`。工具的退出码不是 MCP 服务器进程的退出码。只有完整可信的成功结果才作为本次任务结果。

输入失败的 `error.details.issues` 仅给安全字段路径、固定 code/expected 和截断标志；按该位置及当前 schema 修正输入，expected 是格式要求，不是待填写的事实。OA 失败可带 `error.upstreamError` 的数值业务码和固定阶段；与 `failureCode`、原 execution 一起保留，用于区分创建、票据保存或回查失败，不把业务码解释成没有远端写入。完整上游正文和凭据不进入诊断。

成功后按领域 Skill 核对 `data` 和覆盖范围。准备 OA 写入，或遇到异常、退出 11、断连和无可信输出时，读 [`references/execution-recovery.md`](references/execution-recovery.md)，沿同一上下文查原执行。Raw 仅限已登记的 OA 读取，以实际目录和 schema 为准。
