# 写入准备与异常恢复

原生 MCP 宿主按领域 Skill 使用已开放的业务写工具及原执行回查工具。下列命令适用于 CLI。

使用 CLI 准备支持该阶段的 OA 写入时，提供已登记的 operation、稳定任务键及原业务输入。记录返回的 `executionId`、原输入和 profile。确认本次授权和计划后，用原输入应用同一执行。稳定任务键使用可存入私有状态库的业务标识，凭据留在凭据存储。

```sh
huaqing operations prepare OPERATION --input - --idempotency-key TASK_KEY --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing operations apply EXECUTION_ID --input - --yes --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

| 结果 | 下一步 |
| --- | --- |
| 0，且成功 envelope 完整 | 按领域指导核对数据、状态和覆盖范围。 |
| 2 / 3 / 4 / 6 / 10 | 依据 `error.code` 和 `hint` 修正输入、配置、认证、权限或确认条件。 |
| 5 / 130 / 70，或断连、强杀、无可信输出 | 记录错误和追踪信息。已启动的写入按可能派发处理，先查原执行。安全读取重试由 operation 自身策略处理。 |
| 11 | 保留原 envelope，按错误类型选择下面的状态入口。 |

恢复沿用原配置、profile、凭据后端和状态目录。

- `CONFIG_COMMIT_UNCERTAIN` 用 `huaqing profile list` 核对实际默认项。
- `AUTH_SESSION_UNCERTAIN` / `AUTH_COMMIT_UNCERTAIN` 用原 provider 的 `auth status` 核对，OA 传 `--provider oa`，A 传 `--provider agentos`。按状态和授权恢复，保留旧 refresh token 的未决状态。
- `IDENTITY_COMMIT_UNCERTAIN` 用 `huaqing oa identity show` 核对后决定是否重新核验。
- `SKILLS_EXPORT_PARTIAL` / `SKILLS_EXPORT_COMMIT_UNCERTAIN` 先检查原目标已写文件，保留现场，重试使用新目标。导出可用 `huaqing schema skills.export --format json` 核对契约，无需业务 profile。

```sh
huaqing auth status --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

业务写入按原 `executionId` 查本地记录。缺失时用原 operation 和原稳定键定位。命中多个历史执行时报告歧义。`meta.requestId` 追踪调用，OA `data.requestId` 定位申请单。恢复使用原执行 ID。

```sh
huaqing operations status EXECUTION_ID --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing operations status --operation OPERATION --idempotency-key TASK_KEY --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
huaqing operations reconcile EXECUTION_ID --input - --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

按 operation 支持的范围，把原输入交给 `reconcile` 只读核实。报告已知对象 ID、回查证据及未证实项。MCP 断连或取消后也走原上下文的状态入口。仍未决时保留原 operation、原输入和原记录，避免换入口或换键重放。旧版本的成功缓存和只读恢复仅覆盖原执行，旧准备结果先查实际是否派发。
