---
name: oa-workflow-travel-application
description: 填写、发起或保存 OA 普通出差申请草稿，处理申请人、出差事由、行程和目的地。差旅报销用 oa-workflow-expense，按单号查详情用 oa-workflow。
---

# OA 普通出差申请

1. 加载 [`oa-workflow`](../oa-workflow/SKILL.md)，读取 [`oa-workflow/references/execution.md`](../oa-workflow/references/execution.md)。沿用本次 OA 环境、profile 和授权操作者。使用该 profile 的 `travelApplication` 绑定，包含 `workflowId`、`formId` 和 `bindingRequestId`。MCP 使用宿主固定的 profile，由业务操作核验绑定。配置缺失或绑定校验失败时，报告环境和诊断，交由配置维护者核实。
2. 核对申请人正式姓名 `applicantName`、申请日期 `applyDate`、出差事由 `reason`，以及每段行程 `entries` 的 `startDate`、`endDate`、`headcount` 和 `destination`。申请人必须是当前已授权的 OA 操作者。日期使用 `YYYY-MM-DD`，行程按日期排序，人数为正整数。目的地填写明确的城市名称或完整的 `中国/省/市`；单独标注的出发地写在已确认的行程安排中。遇到“甲地—乙地”等表述时，核对各段的目的地和日期，集中询问缺失或有歧义的事实。CLI 从行程计算出差天数。
3. 按需提供已确认的行程安排 `itinerary`，或以 OA 正式姓名数组传主表或行程的 `companions`。用户已授权随本单上传的支持 PDF 用 `materials` 传入 `{path,sha256?}` 数组，`path` 为绝对路径。MCP 附件位于宿主批准的材料根。业务操作校验人员、组织和城市，并处理支持材料。
4. 确认本次草稿写入授权，沿用公共执行规则保存一份未提交草稿。使用宿主已开放的 `huaqing_oa_workflow_travel_application_draft` 工具，或用宿主进程工具调用已安装的 CLI。MCP 业务对象放入 `arguments.input`，在 `arguments.execution` 提供本次确认与稳定任务键。CLI 以一份 JSON 对象作为 stdin，按公共规则准备和应用。

```sh
huaqing schema oa.workflow.travel.application.draft --format json
huaqing oa workflow travel-application draft --dry-run --input - --format json --non-interactive
```

缺少宿主可直接调用的工具时，报告接入缺项。成功时核对 `data.requestId`、`data.draftSaved:true` 和 `data.readback:"live"`，并报告草稿单号。缓存、超时和未决按公共执行规则使用原执行 ID 或任务键回查。
