---
name: oa-file
description: 按 OA 文件 ID 查附件信息或下载附件，核对本地原件摘要，或上传普通 PDF 取得 fileId。单独上传发票原件用 oa-invoice，办理报销单用 oa-workflow-expense。
---

# OA 普通附件

先加载 [`huaqing-shared`](../huaqing-shared/SKILL.md) Skill，按用户需要的结果选入口。

| 想做什么 | 入口 | 按需读 |
| --- | --- | --- |
| 取原件的 SHA-256、类型及字节数 | `oa file inspect` | [核对原件](#核对原件) |
| 按 OA `fileId` 查文件名、类型和大小 | `oa file info` | [查询与下载](#查询与下载) |
| 保存一份已授权的 OA 附件到本机 | `oa file download` | [查询与下载](#查询与下载) |
| 单独上传普通 PDF，取得普通附件 `fileId` | `oa file upload` | [上传及回执](#上传及回执) |
| 单独上传发票原件，取得发票文件回执 | `oa-invoice` | 读取对应 Skill |
| 把材料用于差旅或往返居住地报销 | `oa-workflow-expense` | 读取对应业务分支 |

## 核对原件

用 `oa.file.inspect` 读取 1–10 个 PDF、PNG 或 JPEG 原件的绝对 `paths`。在 MCP 调用中传 `arguments.input.paths`，文件须位于宿主批准的材料根。按 `data.files[].index` 对应原输入，保留 `sha256` 供材料检查和写入复核。此操作离线读取文件，不上传原件。

```sh
huaqing oa file inspect --input - --format json --non-interactive
```

## 上传及回执

固定已登录的 OA profile 和授权操作者，确认本次上传已经获准。操作 `oa.file.upload` 读取一份 PDF 的绝对 `path`，可附原件 `sha256`。通过标准输入传入一份 JSON 后关闭输入，保持该上传的稳定任务键。

```sh
huaqing schema oa.file.upload --format json
huaqing oa file upload --input - --idempotency-key STABLE_UPLOAD_KEY --yes --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

核对 `data.uploaded:true`、`data.fileId` 和 `data.receipt`。这些是上传回执，挂载表单需相应业务步骤。结果未决时沿原操作和执行 ID 查询本地执行，保留原 PDF 和输入，用于回查已保存的上传回执。`receipt:"cached"` 表示取回已有回执。缺少回执时报告未决，保留原执行及已知证据，等待核实。

## 查询与下载

用当前 OA profile 处理已知的附件 ID。`oa.file.info` 通过 `input.fileIds` 接收 ID 数组，并返回实际可见的 `items` 和未返回的 `missingFileIds`。下载通过 CLI 指定 `fileId` 和本机绝对 `targetPath`，目标路径须尚未存在。返回的 `bytes` 和 `sha256` 可供后续核对。服务端文件名只用于展示，落盘位置取本次调用指定的路径。

```sh
huaqing oa file info --input - --format json --non-interactive
huaqing oa file download --file-id FILE_ID --target-path '/absolute/path/attachment.pdf' --format json --non-interactive
```
