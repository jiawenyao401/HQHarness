---
name: oa-auth
description: OA OpenAPI 应用会话。用于配置 OA 连接和凭据存储、查看登录状态、建立应用会话、单独取授权码或兑换 access token、续期或退出。
---

# OA 应用会话

先加载 [`huaqing-shared`](../huaqing-shared/SKILL.md) Skill，按其中的共用规则固定目标 OA 连接、配置文件、profile 和凭据存储。应用会话与 OA 操作者分别核验。核对某位员工或当前操作者时使用 `oa-person`。

| 想做什么 | CLI 子命令 | 按需读 |
| --- | --- | --- |
| OA profile 尚未配置，或需要为测试或生产配置独立连接 | `profile show` 核对配置 | [`references/connection-setup.md`](references/connection-setup.md) |
| 查看当前 profile 是否已有 OA 会话 | `auth status --provider oa` | [`references/session.md`](references/session.md#查看状态) 的「查看状态」 |
| 为当前 profile 建立会话 | `auth login --provider oa` | [`references/session.md`](references/session.md#建立会话) 的「建立会话」 |
| 单独获取一次性授权码 | `oa auth get-code` | [`references/session.md`](references/session.md#分步取码和换票) 的「分步取码和换票」 |
| 消费已缓存的授权码来兑换 OA 应用 token | `oa auth token` | [`references/session.md`](references/session.md#分步取码和换票) 的「分步取码和换票」 |
| 检查并按需续期已有会话 | `oa auth refresh` | [`references/session.md`](references/session.md#续期) 的「续期」 |
| 退出当前 profile 的 OA 会话 | `auth logout --provider oa` | [`references/session.md`](references/session.md#退出) 的「退出」 |

用户只要求查看状态时，执行状态查询。已有应用会话的业务命令会按需续期。认证命令的返回值用于判断状态，授权码、应用秘密和原始令牌保留在受保护的存储。
