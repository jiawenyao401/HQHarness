# 应用会话命令

各命令沿用 [`oa-auth`](../SKILL.md) Skill 固定的配置与 profile。将示例路径和 `PROFILE` 换成部署中的实际值。建立、续期或退出会话前确认已获授权。共享应用的换票可能影响使用同一应用的其他实例。

## 查看状态

```sh
huaqing auth status --provider oa --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

报告 `data.status`、`data.accessExpiresAt` 和 `data.cleanupPending`。这是本地会话记录。人员权限以 OA 对具体操作的结果为准。

## 建立会话

```sh
huaqing auth login --provider oa --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

准备该 OA 连接已经授权的应用凭据引用。根据 `data.status` 判断会话结果。需要分别执行取码和换票时使用下节。

## 分步取码和换票

先取码并核对 `data.codeIssued:true` 和 `data.expiresAt`。用户只要求取码时，到这里即可。

```sh
huaqing oa auth get-code --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

换票消费同一 profile 下有效的缓存码，保留 `data.status` 和 `data.accessExpiresAt`。授权码仅可消费一次。兑换结果未决时先查看原会话状态。

```sh
huaqing oa auth token --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

## 续期

```sh
huaqing oa auth refresh --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

`data.renewed:true` 表示本次实际续期，`false` 表示复用尚可用的缓存。续期未决时先查看原会话状态。

## 退出

```sh
huaqing auth logout --provider oa --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

`data.status:"logged-out"` 表示该 profile 已解除本地会话绑定。其他有绑定的 profile 可以继续共享应用会话。退出结果未决时先查看原会话状态。
