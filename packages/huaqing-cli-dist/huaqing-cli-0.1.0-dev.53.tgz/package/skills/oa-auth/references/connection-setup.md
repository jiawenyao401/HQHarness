# 配置 OA 连接和凭据存储

确认目标 OA 环境及获准应用。用宿主给定的配置路径和 profile。配置只保存凭据引用，秘密由部署方通过进程环境、受限文件或钥匙串注入。下列占位值替换为实际部署值。

```json
{
  "schemaVersion": 1,
  "defaultProfile": "oa-test",
  "profiles": { "oa-test": { "connections": { "oa": "oa-test" } } },
  "connections": {
    "oa-test": {
      "provider": "oa",
      "environment": "test",
      "baseUrl": "https://oa.example.invalid/papi/openapi",
      "tenantKey": "TEST_TENANT",
      "corpId": "TEST_CORP",
      "appKeyRef": "env:HUAQING_OA_TEST_APP_KEY",
      "appSecretRef": "env:HUAQING_OA_TEST_APP_SECRET"
    }
  }
}
```

使用 `env:` 引用时，确保变量在宿主实际启动 CLI 的进程环境中。应用凭据也可用 `file:绝对路径` 或 `keyring:服务/条目` 引用。需要以 OA 人员身份调用时，在连接填写获准的 `operatorId`，保留 OA 人员记录 ID 的原始字符串。`baseUrl` 保留真实 OpenAPI 前缀。已获准且仅提供私网 HTTP 的部署，在对应连接显式设 `allowPrivateHttp:true`，地址使用规范点分的 RFC1918 IPv4。

无系统钥匙串的宿主可配置 `HUAQING_CREDENTIAL_STORE=encrypted-file`，再用 `HUAQING_CREDENTIAL_MASTER_KEY_FILE` 指向绝对密钥文件，或用 `HUAQING_CREDENTIAL_MASTER_KEY` 注入密钥，二选一。密钥内容是标准 Base64 编码的随机 32 字节，独立于保存密文的状态目录。后续登录、业务操作和回查沿用相同的存储后端、密钥及状态目录。

```sh
huaqing profile show --config '/absolute/path/config.json' --profile PROFILE --format json --non-interactive
```

先用本地输出核对环境、连接和引用。部署缺失时报告具体缺项。配置核对通过且已授权建立应用会话后，按 [`references/session.md`](session.md) 登录。共享应用换票可能影响其他使用同一应用的实例。
