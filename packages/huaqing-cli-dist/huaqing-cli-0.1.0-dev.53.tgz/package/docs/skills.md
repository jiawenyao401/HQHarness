# Skills 分发与使用

Skills 是随 CLI 固定版本交付的任务指导。业务参数、认证、操作者校验、分页和错误处理由 CLI 的 operation 定义及执行器负责；调用方从 `huaqing schema OPERATION_ID` 或 MCP 的实际工具目录取得参数定义。

## 发现与导出

```sh
huaqing skills list --format json
huaqing schema skills.export --format json
huaqing skills export oa-auth --target-dir '/absolute/path/oa-auth-skills' --format json --non-interactive
huaqing skills export oa-workflow --target-dir '/absolute/path/oa-workflow-skills' --format json --non-interactive
huaqing skills export oa-workflow-expense --target-dir '/absolute/path/oa-expense-skills' --format json --non-interactive
huaqing skills export oa-workflow-travel-application --target-dir '/absolute/path/oa-travel-application-skills' --format json --non-interactive
```

`shared` 提供身份、权限、调用与恢复指导。`skills list` 的 `operations` 给出每个 OA Skill 负责的命令 ID。每个领域 Skill 按用户目的选择命令，报销 Workflow 按任务选择分支并引用领域 Skill。`knowledge` 和 `qcc` 分别提供 A 知识库和企查查指导。导出包括依赖及声明的 `references/`，列出和导出均可离线执行。

| Skill ID | 何时选用 |
| --- | --- |
| `oa-auth` | 获取或续期 OA 应用令牌，查看会话状态或退出 |
| `oa-person` | 按姓名或人员记录 ID 查员工，查看或核验当前 OA 操作者 |
| `oa-file` | 读取原件摘要，或上传一份普通 PDF 并获取文件回执 |
| `oa-invoice` | 上传发票原件获取文件回执，按票号或票据实体 ID 查询 |
| `oa-workflow` | OA 流程公共契约。按关键词找可发起流程并查表单，查审批待办、指定单据或字段，创建和填写已配置流程的通用草稿 |
| `oa-workflow-expense` | 办理差旅或往返居住地报销，进行差旅票据入库、验真、关联及受控提交 |
| `oa-workflow-travel-application` | 填写普通出差申请并保存草稿 |

每个 `oa-workflow-*` 业务 Skill 直接依赖 `oa-workflow`，统一从父 Skill 取得执行上下文、授权、通用流程操作和未决回查规则。业务 Skill 只定义自身模板、事实和办理步骤，可另声明直接使用的领域依赖。报销 Workflow 另引用 `oa-invoice` 和 `oa-file`。

旧的单命令选择器（例如 `oa-auth-token` 和 `oa-invoice-upload`）导出所属领域。`oa-approval` 导出 `oa-workflow` 和它的依赖。`oa` 导出五个 OA 领域及共享规则，`workflow-expense` 导出 `oa-workflow-expense` 和它的依赖。返回的 `skills` 和文件路径使用规范目录，宿主按导出结果加载。

`--target-dir` 是新的导出目录，其父目录必须已经存在。相对路径按调用 cwd 解析。已有目录、文件或符号链接均拒绝覆盖，不合并到已安装的 Skills 中。目录名可包含空格和中文；导出结果返回绝对目标路径及文件摘要，用于核对实际内容。

父目录会解析为真实路径，因此 `/tmp` 等父级符号链接可正常使用，结果返回解析后的路径。目标父目录应由调用方控制；同一目标上的并发导出只允许一个成功，不提供针对恶意进程持续替换祖先目录的隔离。

创建目标前会先读取并校验所有源文件。创建后若写入或取消中断，返回 `SKILLS_EXPORT_PARTIAL`、退出码 11，保留已创建内容供检查；不会递归删除可能被其他进程添加的文件。先核对本次指定的目标，再选择新目录重试。全部文件成功写入后不因迟到取消改写成功；POSIX 目录持久化确认失败返回 `SKILLS_EXPORT_COMMIT_UNCERTAIN`、退出码 11。强杀或断电可能没有 envelope，重启后同样先检查目标，不以无输出判断未写入。Windows 按平台能力确认文件落盘，跨平台验收情况以里程碑为准。

这两个命令也可经 `api call skills.list` / `api call skills.export` 调用，参数以各自 schema 为准。导出会写本地文件，因而拒绝 `--output`；结果直接通过 stdout envelope 返回。MCP 默认提供已登记只读工具，写入需显式 opt-in；本地 Skills 导出不投影为 MCP 工具。

## 接入 Harness

导出目录中的能力、工作流及 `huaqing-shared/` 互为同级。让宿主加载完整的导出根目录并保留相对位置。CLI 不扫描或修改宿主全局配置，不替宿主选择安装位置。

跨 Skill 读取时，先用目标 Skill 的 `name` 定位，再读取它目录内的 reference。只有文件读取工具时，从宿主提供的 Skill 目录定位文件，也可按 Markdown 链接相对于当前文件的位置解析。`manifest.json` 用于 CLI 组装导出文件。是否加载以及何时读取取决于宿主和 Agent。

宿主仍需能够启动已安装的 `huaqing`，或持有指定 profile 的 MCP stdio 连接。Skills 本身不携带连接配置、秘密或业务数据。纯进程调用方无需安装 Skills，见 [进程接入指南](harness-process.md)；MCP 的启动与工具约束见 [MCP stdio 契约](mcp-stdio.md)。具体产品兼容结论以源码仓库的开发里程碑为准。

升级时使用新的目标目录导出，在核对版本、摘要和相对引用后切换宿主加载位置。回退使用对应 CLI 版本重新导出的 Skills，避免指导与实际可用命令不一致。

### AgentOS 报销 Skill 安装

在目标实例中以运行 Agent 的用户执行。以下使用 AgentOS 的持久目录，适用于新建的 `huaqing` Skill 组：

```sh
/opt/data/huaqing skills export oa-workflow-expense --target-dir /opt/data/skills/huaqing --format json --non-interactive
```

使用导出结果中的 `files` 校验全部文件摘要，保留 `oa-workflow-expense`、`oa-workflow` 以及导出包含的其他依赖。已有 Skill 组升级时，先导出到新目录并核对版本和文件，再切换整个目录。验收时分别核对差旅、往返居住地、单纯查票和审批待办的 Skill 选择、reference 与 CLI 版本。

验收报销依赖时，用 `skill_view` 打开 `name: "oa-workflow"`，再在同一 Skill 读取 `file_path: "references/execution.md"`。该工具将文件读取限制在所选 Skill 内。若宿主报告重名，按它返回的分类路径定位当前导出包，核对当前目录的 reference，再继续验收。

实例若要求只使用华清处理 OA，验收还须检查同一 Agent 终端能否执行旧 `oa` 或读取镜像中的旧 XASP 路径。Skill 搜索根管理 `skill_view` 的发现范围，终端路径由 AgentOS 的工具策略和镜像决定。用无网络的路径、权限或命令拦截探针验证终端，再用 `/opt/data/huaqing info` 验证华清入口。

### AgentOS 直接调用验收

为受控的差旅草稿会话配置原生 stdio MCP。宿主启动固定入口 `/opt/data/huaqing`，将以下参数按数组传入，并把配置路径、测试 profile 及材料根替换为已核实的部署值。材料根仅覆盖本次附件目录。身份、会话和状态目录沿用同一部署上下文。

```sh
/opt/data/huaqing mcp serve --stdio --config /absolute/config.json --profile oa-test --allow-write --file-root /absolute/task-attachments --tools oa.person.resolve,oa.file.inspect,oa.invoice.materials.check,oa.invoice.recognize,oa.expense.invoice.preflight,oa.invoice.match,oa.expense.draft,oa.expense.inspect,oa.expense.invoice.save,oa.expense.invoice.link,operations.status,operations.reconcile
```

草稿专用配置使用各写工具的结构化 `input`、`execution.dryRun`、`execution.confirm` 和稳定 `execution.idempotencyKey`。只在授权范围内调用对应写工具。通用 `operations.prepare` 和 `operations.apply` 可路由多种写操作，草稿专用工具集合应排除两者。进程调用也可使用固定入口和结构化参数的宿主工具。

实例承担 OA 待办查询时，白名单分别登记 `oa.workflow.todo` 和 `oa.workflow.todo.count`。前者返回待办列表和分页，后者返回数量。部署后在新会话分别发现两个工具，并至少调用一次 `oa.workflow.todo`，以 `data.items` 和 `data.pagination` 验证列表入口。

验收先在专用会话仅开放华清工具、Skill 读取及已批准的材料读取能力，关闭 `execute_code`、通用终端和可执行脚本的替代工具。检查实际工具目录中的只读 `oa.person.resolve`。用替身验证精确查人、草稿写后回读、人员未找到及配置参考单被拒。明确的派发前失败须零上传、零创建。实际 AgentOS 会话另行留证，验证缺被报销人且无明确申请单时首轮只提问，人员查找失败时结束本轮且无整批材料读取或写入。

在运行中的 AgentOS 实例安装或更新 `hqoa` 后，用该实例的桌面网关建立新会话并检查 `tools.show`。目录缺少 `mcp__hqoa__` 工具时，使用宿主的 `reload.mcp` 并在另一新会话复核。验收至少保留一个真实模型调用原生只读工具的回执。独立 stdio 探针只验证制品和连接，桌面会话工具由网关单独加载。

## 维护与校验

`skills/manifest.json` 声明 Skill ID、目录、依赖和可选的 `references` Markdown 文件名。OA Skill 的 `operations` 列出它负责的命令，每个命令只归属一个 Skill。领域 Skill 提供意图到命令的路由表和结果判定。业务 Workflow 的依赖声明和正文直接引用 `oa-workflow`，其他链接与其声明的依赖一致。名称和触发场景从 `SKILL.md` frontmatter 读取，参数和校验以 CLI 为准。

可执行引用统一写成内联 `huaqing ...`，或代码围栏中以 `huaqing` 开头的完整单行命令。校验格式只支持字面参数和简单引号，不接受管道、重定向、变量展开或续行；自然语言提及不作为可执行引用校验。文件链接的可见文字写准确的 Skill 名（指向 `SKILL.md` 时）或文件路径。同一 Skill 从其根目录算起，如 `references/session.md`。跨 Skill 从导出根目录算起，如 `oa-workflow/references/execution.md`，并说明何时加载和要读取的 Skill 内路径。

每份在 manifest 登记的 reference 都从所属 `SKILL.md` 直接链接，并写明读取它的任务分支。`npm run skills:check` 校验 frontmatter、依赖、命令、引用入口和文件路径，并纳入完整检查及打包前检查。安装包验收从空目录安装制品后运行真实 `skills list/export`，核对导出文件与原包一致。真实 Harness 加载与 OA 业务另行验收。
