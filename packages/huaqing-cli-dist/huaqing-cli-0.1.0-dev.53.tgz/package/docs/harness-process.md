# 通用 Harness 进程接入

本指南对应 M4.1，适用于能够启动子进程、传入 stdin 并收集退出状态的宿主。示例随 npm 包发布，不依赖 A 端、旧 xasp、Python 或 Harness 私有目录。业务命令和 schema 仍以 `commands list` / `schema ID` 为准。

## Node 参数数组调用

在安装了固定版本 `@huaqing/cli` 的项目中：

```js
import { runOperation } from '@huaqing/cli/examples/node-process.mjs';

const result = await runOperation({
  operation: 'system.info',
  input: {},
  timeoutMs: 30_000,
});

if (result.issue !== null) {
  // 进程或输出协议失败。不要据此认定业务没有发生，不自动重试。
  console.error({ issue: result.issue, started: result.started,
    exitCode: result.exitCode, signal: result.signal });
  process.exitCode = 1;
} else if (result.exitCode !== 0) {
  // 保留结构化失败，尤其是退出码 11；交给下方恢复规则处理。
  console.error({ exitCode: result.exitCode, error: result.envelope.error,
    requestId: result.envelope.meta.requestId });
  process.exitCode = result.exitCode;
} else {
  console.log(result.envelope.data);
}
```

`runOperation` 固定使用当前 Node 可执行文件、绝对 CLI 路径和 `shell: false`。默认入口为安装包自己的 `dist/cli.js`；`cliPath` 可指定另一个已核验安装的绝对入口。业务参数通过 JSON stdin 发送，写完立即关闭 stdin，避免子进程等待 EOF。它不接收任意 CLI flags，不生成 shell 命令字符串，不在外层重试。

配置示例：

```js
const result = await runOperation({
  operation: 'oa.workflow.todo',
  input: { page: 1, pageSize: 20 },
  configPath: '/absolute/受控配置/production.json',
  profile: 'zhang-zike-production',
  env: process.env,
  timeoutMs: 30_000,
  graceMs: 1_000,
});
```

`env` 默认继承当前进程环境；宿主可以传入专用环境对象，但需保留本次调用所需的配置、状态目录和凭据引用。密钥不要放进 `input`、argv、诊断日志或调用记录。示例不会自动记录 stdout/stderr；成功的业务结果仍可能含敏感内容，由宿主控制存储及展示。

输入须为可 JSON 序列化的对象，ID 和精确小数使用字符串。输入上限 8 MiB，stdout 上限 16 MiB，stderr 上限 64 KiB，均按字节计数。超量输出会终止进程并报告协议问题，不能当作成功或再次执行写操作。业务读取本身另有各自分页/响应上限。

写入通过单独execution显式授权，不把确认塞入业务JSON，也不允许任意CLI flags：

```js
const result = await runOperation({
  operation: 'oa.expense.amend', input: amendmentInput,
  configPath: '/absolute/config.json', profile: 'oa-profile',
  execution: { confirm: true, idempotencyKey: 'task-amend-001' },
});
```

execution仅接受confirm:true、dryRun:true和有效的idempotencyKey；它们映射为--yes、--dry-run和字面键参数。省略不需要的布尔授权，显式false/未知项由Adapter在启动前拒绝。prepare可传稳定键，apply在业务input中传executionId和原输入并确认；确认、键和作用域仍由CLI共同执行器检查，不在Adapter复制业务规则。

返回结构固定为 `{ exitCode, signal, envelope, issue, started }`：

- `issue === null`：收到与进程退出状态一致的完整 CLI envelope；`exitCode` 可以非零。业务错误保留在 `envelope.error`。
- `issue !== null`：启动、进程或输出协议未成功完成；不得把返回值当作有效业务结果。issue 是固定诊断代码，不附带原始输入、stdout、stderr 或底层异常。
- `started` 表示子进程是否启动，不表示请求是否已经发到 OA，也不表示业务是否成功。
- `signal` 保留子进程最终被信号终止的情况。宿主请求过取消，不代表子进程一定以信号结束；CLI 可能已确认成功或返回未决结果。

Adapter 验证一份 UTF-8 JSON envelope 的公共字段、operation 和退出状态一致性；业务 data 的字段由 CLI 的统一执行器校验。未知 operation 的合法拒绝使用 `operation="api.call"`、`CAPABILITY_UNAVAILABLE`、退出码 6。多份 JSON、缺失结果、无效 UTF-8 或其他 operation 不匹配均不能成为正常结果。

## 取消和超时

```js
const controller = new AbortController();
const pending = runOperation({
  operation: 'system.info', input: {}, signal: controller.signal,
});
// 宿主实际收到用户取消时调用 controller.abort()。
const result = await pending;
```

`timeoutMs`（1–300000，默认 30000）传给 CLI。调用方 watchdog 为启动留出 `graceMs`（默认 1000）；CLI 超时优先获得生成最终 envelope 的机会。宿主取消或 watchdog 触发后，Adapter 尝试 SIGTERM，再经过宽限期才强制终止；等待流关闭后再判定结果，最终清理计时器和监听器。

在支持信号处理的 POSIX 环境，CLI 受控取消通常返回 130。若收到完整、可信的成功或退出码 11 结果，必须保留，不能被“用户按过取消”或外层超时覆盖。取消不撤销已发送的请求。Windows 的进程终止不承诺具有 POSIX 的宽限效果；缺少最终 envelope 时按结果未知处理，实际支持平台以里程碑的实测证据为准。

调用前已取消或输入无法序列化时，不启动 CLI。启动后强杀、进程崩溃、丢失输出都不能证明远端未执行。不要使用会在超时/取消时直接丢弃 stdout 的封装替换这些判断。

## POSIX shell 调用

```sh
printf '%s\n' '{}' | sh /安装位置/examples/shell-process.sh system.info

sh /安装位置/examples/shell-process.sh oa.workflow.todo \
  '/absolute/受控配置/production.json' 'zhang-zike-production' < todo-input.json
```

`todo-input.json`：

```json
{"page":1,"pageSize":20}
```

接口保留`OPERATION [CONFIG_FILE [PROFILE]]`；执行授权可在分隔符`--`后追加--yes、--idempotency-key KEY、--dry-run，除此不接受任意flags。`HUAQING_NODE`可指定一个Node可执行文件路径，`HUAQING_CLI_ENTRY`可指定绝对入口。路径和键作为单个字面参数传递。脚本最终exec CLI，stdin/stdout/stderr与退出状态直接交给宿主，不缓存结果，不引入第二层错误envelope或自动重试。

```sh
sh /安装位置/examples/shell-process.sh operations.apply \
  /absolute/config.json oa-profile -- --yes < original-apply-input.json
```

宿主负责保留非零退出时的 stdout、限制输出量并处理信号。脚本参数错误和无法启动 Node 时可能只有 stderr，仍须检查进程状态和 envelope。若启用 `set -e`，应把命令放进 `if` 等可捕获失败的分支，不能在读取结构化错误前直接退出。此脚本仅面向 POSIX shell，不宣称 Windows shell 兼容。

## 错误与恢复

以下查询都必须使用原调用的显式 config/profile、相同凭据后端和持久状态目录。不要在恢复途中依赖可能已被其他进程修改的 defaultProfile。

| 结果 | 调用方处理 |
| --- | --- |
| 0 + 完整成功 envelope | 使用 data；保存必要的追踪信息 |
| 2 / 3 / 4 / 6 / 10 | 按 error.code / hint 修正输入、配置、认证、权限或确认；不循环重放 |
| 5 / 130 | 保留错误与 requestId；检查操作效果，取消/超时不证明请求未发送；Adapter 不自动重试 |
| 11 + `CONFIG_COMMIT_UNCERTAIN` | 先调用 `profile.list` 核对实际 `isDefault`，再决定是否需要新的配置修改 |
| 11 + `AUTH_SESSION_UNCERTAIN` / `AUTH_COMMIT_UNCERTAIN` | 先调用 `auth.status`；按返回状态和 hint 恢复。需要登录时使用已授权的显式 `auth.login`，不得重放旧 refresh token |
| 11 + `IDENTITY_COMMIT_UNCERTAIN` | 先调用 `oa.identity.show`，核对记录后再决定是否重新 verify |
| 其他退出码 11 | 保留原 envelope 和 hint，不猜测完成状态；使用对应 operation 已公开的恢复机制 |
| 70，或 Adapter issue、被信号强杀、缺失/损坏输出 | 记录进程状态；若已启动，按可能已派发处理。先核实实际状态，不自动重放 |

`meta.requestId`是本次CLI调用的追踪ID；data.requestId/targetRequestId是OA对象ID；业务executionId来自成功data.execution或退出11的受控执行摘要，三者不能互换。prepare/apply/status/reconcile使用同一业务实现：状态查询不重放，reconcile只读核实；未知新建ID不能猜一个，amend等输入已知目标的操作则可按其已派发资格读取原目标。无最终输出时保留原键/输入，先查执行状态，不换键重试。具体动作的真实恢复验收继续由里程碑记录。

接入标准进程只证明协议能力。具体 Agent Harness 产品、版本及 MCP 宿主必须按 M4.4 分别实测，不能因为 Node 示例成功就宣称全部 Harness 已兼容。
