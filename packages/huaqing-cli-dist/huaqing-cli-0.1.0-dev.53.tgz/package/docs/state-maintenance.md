# 本地状态备份与迁移

这些命令服务于 M6.3 的升级与回退准备，操作 `HUAQING_STATE_HOME` 对应的 `state.sqlite3`。无需业务 profile、应用凭据或联网，不操作 OA、A、QCC 或远端单据。

```sh
huaqing state inspect --format json
huaqing state backup --json '{"targetPath":"/absolute/backups/huaqing-before-upgrade.sqlite3"}' --format json
huaqing state migrate --json '{"backupPath":"/absolute/backups/huaqing-before-schema5.sqlite3"}' --format json
```

父目录必须已存在，目标必须不存在；文件、目录及悬空符号链接均拒绝覆盖。实际路径解析父目录后返回，备份文件权限为 `0600`。状态目录、主库及已有 WAL/SHM/journal 文件必须满足现有私有文件权限规则；状态目录或主库本身为符号链接时拒绝读取。命令不会为了检查而创建空状态库。

`state inspect` 只读 `user_version`，返回 `schemaVersion/currentSchemaVersion/path/supported/upgradeRequired`。当前版本为 5；旧版 1–4 能报告需要升级，未来未知版本能报告不支持，两者都不暗中升级。版本 0 仅在空 SQLite 库时支持初始化迁移；不将未知应用表认作华清旧状态。

`state backup` 使用 SQLite 原生在线 backup，包含已提交到 WAL 的记录，不直接复制正在使用的主文件。先写同目录随机 `.partial`，校验 SQLite 完整性，转成不依赖 WAL/SHM 的单文件快照，计算 SHA-256 并同步文件，再用独占链接发布最终路径和同步目录。只有完成的快照才出现最终名称。返回 `schemaVersion/path/bytes/sha256`；可用系统 SHA-256 工具独立核对。超时或取消时清理本次临时文件；若文件发布或清理无法确认，明确返回退出码 11，不伪报完成。崩溃遗留的 `.partial` 不是可用备份，不用作回退输入。

快照完整保留数据库里的执行 ID、幂等键、对象 ID、人员 ID、认证绑定、秘密版本引用及恢复状态等信息，应按敏感文件保管。当前状态库不保存 token 或完整业务表单；备份命令不读取钥匙串、`credentials/` 密文、主密钥或应用密码，也不把这些内容打入快照。一个数据库快照不是整机凭据备份，不能承诺把它复制到另一目录后原会话仍可用。

`state migrate` 必须先成功完成一份新的独立一致备份，再使用既有事务迁移到 schema 5。即使已是版本 5，仍先备份，再返回 `changed:false`。备份失败、目标已存在、取消或未知 schema 时不会执行迁移；备份已完成而迁移因锁等原因失败时保留备份。输出包含迁移前版本、当前版本、实际状态路径和备份摘要。v1 的未知认证与旧租约按既有规则转为 uncertain；v2–v4 的原有认证、执行及恢复记录保留，v5 增加本机报销目标/发票资源声明表。只读命令继续不会替用户迁移。

升级前应停止使用该状态根目录的 CLI/MCP/Harness 写进程，确认没有在途认证刷新或业务派发，再运行迁移。在线 backup 可生成一致快照，但不能把快照之后的新业务写入纳入过去的快照。SQLite 事务保证本机迁移原子性，不能撤销远端已经执行的操作。

回退时固定已验收的旧 CLI 和 Skills 版本，保留升级前快照，在独立 `HUAQING_STATE_HOME` 中检查和演练。旧程序遇到新版 schema 应明确拒绝，禁止伪造 `user_version`、删除表或让旧程序直接打开升级后的活动库。本批没有自动恢复、覆盖活动库或降级命令。

独立目录中的历史快照用于核对执行与对象记录；认证引用仍受原凭据存储和作用域限制。钥匙串引用及加密文件存储不能仅靠复制 SQLite 自动迁移，尤其加密文件存储身份绑定原密文目录及主密钥。缺少相应受支持的凭据恢复步骤时，使用新的独立状态根显式重新认证，并保留历史快照只读核对，不改写引用或假定旧 refresh token 可重放。原状态与回退状态不得并行轮换同一远端应用会话。

软件回退不会撤销已经创建、保存或提交的远端单据。未决执行先保留原 execution ID、幂等键和已知对象 ID，按原版本支持的 status/reconcile 读取核实；不得因为换版本、换目录或看到旧快照里尚无结果而自动重放写请求。
