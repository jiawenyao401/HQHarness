# 差旅费报销：不完整草稿与源码契约

首个模板为**差旅费报销**。用户已明确通过新华清 CLI 推进实际差旅报销；本文件记录材料草稿基础协议、生产只读核实结果和完整报销的源码候选规则。已另行授权的[往返居住地第二模板](home-travel-expense.md)使用独立入口与绑定。

报销 Workflow Skill 使用本文件的基础差旅草稿操作，传入普通支持材料或空 `materials`。发票走独立匹配、保存与关联步骤。混合材料输入及历史缓存和只读恢复另见[差旅材料流程契约](expense-workflow.md)。Harness 负责多模态材料识别，CLI 核对原件与结构化事实。[材料事实契约](material-facts.md)

支持材料可携带已核对的 64 位小写 SHA-256 `sha256`，准备和应用都按本次文件快照校验。提供摘要且实际字节不同会在访问 OA 前返回 `OA_MATERIAL_SOURCE_MISMATCH`。离线 dry-run 只核对输入结构和路径格式。

新建待补草稿可省略 `travelDates`，事由只写已经确认的内容。住宿日期和开票日期各自保留原义。可用 `confirmedNotes` 保存已确认的餐补标准和费用归属等说明，限单行、77 个 UTF-16 单元。特殊说明字段 `tssm` 写入该文本并附加不完整草稿声明，实时回读核对原文。说明中的信息不计入财务字段或报销金额。原来只传日期和其他基础字段的输入沿用原渲染与摘要。

## 生产字段与当前材料草稿

2026-11-07，已授权实例的 OA 真实读取取得 49 字段（全部 required=false/delete=false）。41 个源码候选字段 ID 均存在，但生产 `sqdw.componentKey=Subcompany`、主表 `xglc.componentKey=Workflow`，不与源码描述大小写/名称强行等同。见 [生产字段](../reports/m3-form-production.json)。

同一 form 的可见单据 `1331809581316030465` 回查得到 workflowId=`1302769933046546435`、workflowName=` 差旅费报销`、formData.form.id=`1253299138274254854`；因此本次部署显式绑定该已观察流程，不使用旧源码 `1279393955010846720` 作为默认值。见 [绑定核对](../reports/m3-template-binding.json)。可创建列表本次为空，queryFlowInfoByFlowIds 返回业务失败；不把这些读取结果解释为已验证创建权限。实际创建仍须生产调用及同对象回查确认。

基础 incomplete 材料草稿七个字段为sqr/sqrq/ccsy/mdd/fj/ccr/tssm，支持材料PDF作为普通附件，`materials:[]`时省略fj。新写入的invoice须提供默认流程规定的结构化事实；只有path/kind的发票输入仍返回OA_EXPENSE_INVOICE_ROUTE_REQUIRED，不能退回普通附件。基础步骤不写金额、银行、小时、补贴或提交；默认混合材料流程另以专用协议保存和关联发票，未知申领额省略。完整财务保存、独立票据实体/验真与首提使用[完整差旅契约](expense-complete.md)的对应operation，不把材料附件当票据infoId。材料草稿首次prepare和apply核对完整实时元数据须允许省略、七字段准确；相同成功/未决执行仅返回本地状态。参考单据只证明workflow/form对应，不复制其业务内容。

专栏预检核对票据字段，草稿 dry-run 核对离线输入。默认在线准备要求本次 OA 应用及操作者可读取 `travelExpense.bindingRequestId`，用参考单核对精确的 `workflowId` 和 `formId`。OA 业务拒绝读取时返回 `OA_EXPENSE_BINDING_UNREADABLE`、退出 6，保留业务码和 `workflow-detail` 阶段，停止在附件上传及草稿创建之前。已核实配对的测试部署可采用下述固定绑定方式。

support-only基础流程每件材料先记录步骤再上传，随后仅一次带已知六至七字段的创建（isnextflow=0）及同对象回查，不额外调用save。混合材料流程在该创建之后继续专用票据处理与发票栏保存，全部步骤由同一执行记录追踪。结果固定 businessComplete=false；服务器明确的数值零默认仅报告 serverDefaultsPresent，不解释为已确认金额。已派发后失败保留退出 11、executionId 和已知文件/草稿 ID；reconcile 只读观察已知草稿，不重放未知步骤、不改写历史 uncertain。新执行的本地 status 使用 v4 恢复绑定，保持同一配置、profile、连接上下文及操作者时 logout 后仍可查询；远端回查和 apply 仍要求原应用会话。基础流程和旧v1/v2历史见 [CLI 执行契约](cli.md#不完整草稿执行dev13)，新混合流程见[默认流程契约](expense-workflow.md)。

完整差旅报销仍需以下源码规则与真实费用政策、OA 发票实体入库、完整字段和提交验收。待补材料草稿不替代这些门槛，也不等于 verifiedForWrite 已覆盖完整报销流程。

## 配置测试差旅的固定流程与表单

部署方从目标环境的 OA 流程设计器核对已发布流程的 `workflowId` 和关联原生表单的 `formId`，再按目标租户配置。下例为已核实的测试差旅配对，放在 `environment: "test"` 的 OA 连接下。

```json
{
  "travelExpense": {
    "workflowId": "1302769933046546435",
    "formId": "1253299138274254854",
    "bindingVerification": "creatable-workflow"
  }
}
```

每次准备和派发前，CLI 用配置的 OA 操作者精确核对团队可发起列表中的流程 ID，并验证配置表单的实时字段。列表若给出表单 ID，其值必须与配置一致。列表只返回流程 ID 时，配对依据是部署方在同一环境核实的配置。流程改版或重新绑定表单时，由部署方重新核实配对。运行时直接使用这组 ID 保存草稿，随后按新 `requestId` 回读流程、表单和草稿状态。

已有执行记录的部署须保留原 `bindingRequestId`，并可切换到上述核验方式。保留该字段可继续按原摘要恢复执行和保护参考单；固定绑定模式的在线核验只读取可发起列表和表单字段。配置缺少可用配对时，先由部署方核实再重试。生产差旅和往返居住地继续使用参考单核验。

## 来源与版本

固定 xasp Git 提交为 `e5ece871ea88789e4dc5779931810244beb117bb`（2026-11-05）。仅读取当前提交，不采用 `archive/branches`、兼容平铺 Skill 或旧实例业务数据。字段权威源为 `skill/oa/oa-travel-expense/references/travel-expense-schema.md`，SHA-256 为 `d46b5952abf83984c791624b30166132219f907f9bee6b759e2f017cdbcc7190`。

[源码候选 fixture](../../tests/fixtures/oa/travel-expense.json) 保存 30 份 Git blob 路径与 SHA-256、41 个字段、3 个子表及合成线协议样例。`kind=source-derived`、`liveCapture=false`、`candidateOnly=true`、`verifiedForWrite=false`；样例的人、账户、文件和业务对象均为合成值，`samplesDispatchable=false`。来源摘要在写入 fixture 时与本地同名源码逐字节核对一致。

主要依据：[字段 schema](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-travel-expense/references/travel-expense-schema.md:11)、[独立草稿执行路径](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/travel_expense.py:901)、[OA 环境绑定](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/travel_complete.py:75)、[SDK 上传/OCR](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/invoice/service.py:54)、[SDK workflow](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/service.py:277)。当前平台 wrapper 最终仍调用同一个差旅执行器；新华清只复用已确认的协议与业务含义，不依赖其 Python、AgentOS 私有上下文或 USER.md。

## 完整报销的源码模板与字段

- 源码候选 `workflowId`: `1279393955010846720`（当前部署使用上文已回查绑定的流程，不以此值为默认）
- `formId`: `1253299138274254854`
- `formName`: `差旅费报销`
- `module`: `workflow`

以下“业务必填/条件必填/默认省略”来自完整报销的源码业务 schema，不代表目标 OA 当前 `required` 配置或本版七字段材料草稿。已取得的生产差异见上文；每次实际派发仍核对实时字段映射、删除状态与必填性。

### 主表

| 名称 | dataKey | fieldId | OA 类型 / 编码 | 源码业务状态 |
| --- | --- | --- | --- | --- |
| 申请人 | `sqr` | `1253299610586439685` | Employee / `dataOptions` | 业务必填 |
| 申请部门 | `sqbm` | `1253299610586439686` | Department / `dataOptions` | 业务必填 |
| 申请日期 | `sqrq` | `1253299610586439687` | DateComponent / `content` | 业务必填 |
| 出差事由 | `ccsy` | `1253299610586439688` | Text / `content` | 业务必填 |
| 报销总额 | `bxze` | `1253299610586439689` | Money / `content` | 业务必填 |
| 目的地 | `mdd` | `1302769739714297858` | Text / `content` | 业务必填 |
| 附件 | `fj` | `1253299885531455490` | FileComponent / `dataOptions` | 条件必填 |
| 申请单位 | `sqdw` | `1261248478487396357` | SubCompany / `dataOptions` | 业务必填 |
| 项目名称 | `xmmc` | `1276692845840220160` | Text / `content` | 默认省略 |
| 相关申请流程 | `xglc` | `1274903884402851842` | Flow / `dataOptions` | 默认省略 |
| 预算科目 | `yskm` | `1257755944102051841` | RelateBrowser / `dataOptions` | 默认省略 |
| 费用承担主体 | `fycdzt` | `1257756446579671040` | Text / `content` | 默认省略 |

### 收款账户信息

子表 ID：`1266384292806893591`。

| 名称 | dataKey | fieldId | OA 类型 / 编码 | 源码业务状态 |
| --- | --- | --- | --- | --- |
| 收款人 | 未在 schema 定义 | `1266384292806893592` | Text / `content` | 业务必填 |
| 开户银行 | 未在 schema 定义 | `1266384292806893593` | Text / `content` | 业务必填 |
| 银行账号 | 未在 schema 定义 | `1266384292806893594` | Text / `content` | 业务必填 |
| 付款金额 | 未在 schema 定义 | `1266384292806893595` | Money / `content` | 业务必填 |

### 出差报销明细

子表 ID：`1253299885531455491`。

| 名称 | dataKey | fieldId | OA 类型 / 编码 | 源码业务状态 |
| --- | --- | --- | --- | --- |
| 出差人 | `ccr` | `1253299885531455493` | Employee / `dataOptions` | 业务必填 |
| 出发时间 | `cfsj` | `1253300757384650752` | DateComponent / `content` | 业务必填 |
| 出发地点 | `cfdd` | `1253300757384650753` | City / `dataOptions` | 业务必填 |
| 到达时间 | `ddsj` | `1253300757384650754` | DateComponent / `content` | 业务必填 |
| 到达地点 | `dddd` | `1253300757384650755` | City / `dataOptions` | 业务必填 |
| 交通工具 | `jtgj` | `1253300757384650756` | Text / `content` | 业务必填 |
| 单据张数 | `djzs` | `1253300877710843914` | NumberComponent / `content` | 业务必填 |
| 金额 | `je` | `1253300877710843915` | Money / `content` | 业务必填 |
| 出差天数 | `ccts` | `1253300877710843916` | NumberComponent / `content` | 业务必填 |
| 每天补贴 | `mtbt` | `1253300877710843917` | Money / `content` | 业务必填 |
| 补贴金额 | `btje` | `1253300877710843918` | Money / `content` | 业务必填 |
| 住宿费 | `zsf` | `1253301307157241864` | Money / `content` | 条件必填 |
| 市内交通费 | `snjtf` | `1253301307157241865` | Money / `content` | 业务必填 |
| 其他金额 | `qtje` | `1253301307157241866` | Money / `content` | 条件必填 |
| 合计 | `hj` | `1253301307157241867` | Money / `content` | 业务必填 |
| 特殊说明 | `tssm` | `1253301307157241868` | Text / `content` | 条件必填 |
| 出差地点新 | `ccddx` | `1271135965534199813` | City / `dataOptions` | 默认省略 |
| 到达地点新 | `ddddx` | `1271135965534199814` | City / `dataOptions` | 默认省略 |

### 发票明细

子表 ID：`1261248478487396359`。

| 名称 | dataKey | fieldId | OA 类型 / 编码 | 源码业务状态 |
| --- | --- | --- | --- | --- |
| 上传发票 | 未在 schema 定义 | `1261248478487396360` | EinvoiceComponent / `dataOptions` | 业务必填 |
| 发票日期 | 未在 schema 定义 | `1261248478487396361` | DateComponent / `content` | 业务必填 |
| 发票金额 | 未在 schema 定义 | `1261249637910462469` | Money / `content` | 业务必填 |
| 购买方 | 未在 schema 定义 | `1297967841852219392` | Text / `content` | 业务必填 |
| 费用说明 | 未在 schema 定义 | `1261490955110727680` | Text / `content` | 业务必填 |
| 相关流程 | 未在 schema 定义 | `1261490955110727681` | Workflow / `dataOptions` | 默认省略 |
| 相关附件 | 未在 schema 定义 | `1261490955110727682` | FileComponent / `dataOptions` | 默认省略 |

### 编码及金额闭环

内层表单只含 `{formId,module,dataDetails}`。主表字段不带 `dataIndex`；子表按各自逻辑行使用从 1 开始的正整数，不能把三个子表连成一个公共行号。`fieldId` 与 `dataIndex` 不得重复；不生成子表容器项。使用 `fieldId` 时不额外添加 `subFormId`。`content` 与 `dataOptions` 二选一，不生成未经确认的空值。

ID 在领域模型和表单选项中保持原始字符串。JSON 数字型 `userid/requestId` 必须由受信运行时无损编码，不经 JavaScript Number。Money 使用精确十进制字符串、两位小数；日期为 `YYYY-MM-DD`，行程时间为 `YYYY-MM-DD HH`。源码的 `Decimal.quantize` 没有显式财务舍入模式，不能直接继承其运行时默认值；实际舍入、负值及超精度输入处理需在目标字段契约中冻结。

单人候选至少一个付款行、至少一个逐日行。每个自然日一行、`ccts=1`；每行 `hj=je+zsf+snjtf+qtje+btje`，`bxze=sum(hj)=sum(付款金额)`，`btje=ccts×mtbt`。同日多段、跨午夜、多人及票据费用分摊未形成可核实规则时保留未决，不用样例算法猜选。

一张确定纳入报销的发票对应一行发票明细；没有发票时可以有 0 行发票明细，但不能据此忽略已收到或未处理的发票。发票金额合计不必等于包含补贴的报销总额。银行账号始终是字符串，只进入必要的受控输入与 payload，不进入普通日志或公开结果。

`xglc` 当前候选固定省略，不自动查询或绑定申请单流程；申请单文件可以作为普通支持材料，不能据此认定申请行程已实际发生。`ccddx/ddddx` 是遗留字段，当前不与 `cfdd/dddd` 双写。项目、预算科目及费用承担主体不因存在字段而自动填入。

## 人员、组织与选项

新华清使用连接中明确配置并核验的 OA `operatorId`；A 账号、AgentOS 实例所有者、材料姓名都不自动成为该值。所有 workflow、上传、OCR、验真的 `userid` 仍为同一操作者的 `queryEmployee.id`。表单申请人 `sqr` 也为该操作者。xasp 旧托管身份工具/独立 USER.md 分支仅作为来源背景，不进入新 CLI 的运行依赖。

`ccr` 是被报销人，逐行写入其独立人员 option。当前用户明确指定的被报销人优先于低优先级材料人名，但票据使用人与指定人不同仍是材料归属冲突，不能因此默许该票可报销。采用现有完整分页与原始候选唯一性门禁解析 `queryEmployee.id`，不取 `userId/user_id`，不复用旧执行器“按 ID 去重后唯一”的捷径。操作者与被报销人不同不更换 `userid`、申请人、部门或单位；收款人是另一个独立业务角色。

草稿在线准备沿用 `OA_OPERATOR_NOT_FOUND` 和 `OA_OPERATOR_AMBIGUOUS`，由 `error.hint` 指向配置操作者或被报销人，提示不带姓名和 ID。固定模板核验通过后，先解析被报销人，再查询申请人组织和字段。新建直接调用的明确人员失败在登记执行及上传前返回。回执不明或已派发未决时，沿用原执行的只读恢复。

完整报销源码的人员 option 使用 `{optionId,type:"user",content?}`。材料草稿的人员字段使用已唯一核验的 `{optionId}`。新任务传 `fillApplicantOrganization:true` 时，CLI 从申请人的 `queryEmployee.department` 精确查询部门，再按 `queryOrg.subcompanyid` 精确查询所属单位。部门与单位分别按 `department` 和 `subcompany` option 写入主表 `sqbm` 与 `sqdw`，两个 ID 进入计划指纹并逐项回读。关联缺失或组织响应不可靠时停在上传和创建之前。旧输入省略该开关，沿用原字段和执行摘要。

City 使用同一目录记录的 `optionId=国家ID,省份ID,城市ID` 和 `content=国家/省份/城市`。不能用行政区划代码、区县 ID 或 cityLevelId 替代。源码采用离线精确目录；零个或多个候选均不能机械选首条，损坏目录不联网静默兜底。目录 SHA 与深圳/成都的固定候选已列入 fixture，但尚未证明目标环境沿用这些 IDs。城市目录的等级不用于住宿政策分类。

## 已确认的源码协议

`path` 均相对于选定 OA OpenAPI base URL，保留 `/papi/openapi` 前缀；应用 token 由既有运行时注入，业务输入不能提供或覆盖。下表确认的是固定源码行为，不是目标生产抓包。

| 子步骤 | 方法与路径 | 关键线协议与结果 |
| --- | --- | --- |
| 普通附件上传 | POST `/api/file/v2/common/upload` | query `access_token`；multipart `module=document,name,userid,file`；可配置 `tenantKey` header。响应 `data.fileid/name/extName`。源码的 `ocr=0` 选择这个独立端点，不是在此请求再发一个 ocr part |
| 发票上传 | POST `/api/inc/file/v1/uploadFileSpilit` | multipart `access_token,userid,ocr=1,file`，header `tenantKey`；取同次响应的 `data.id/ids,fileType,ocrMap`，关键字段缺失停止 |
| 保存型 OCR | POST `/api/inc/biz/v1/ocr` | JSON `access_token,userid,image_index,fileTypeStr,ocrMap,operate_type=0,is_save=0,flag`；header `tenantKey`。`is_save=0` 保存识别实体，不能按只读动作重试 |
| 发票验真 | POST `/sapi/inc/biz/v1/valid` | JSON 含 `userid,access_token,info:{id},flag=100,is_cut=0,is_save=0,operate_type=0` 及源码 req_base；header `tenantKey`。HTTP/ret 成功不等于真票，目标副作用与分类另验 |
| 完整草稿创建 | POST `/api/workflow/core/paService/v1/doCreateRequest` | query token；JSON `userid,workflowId,isnextflow=0,isNewFormData=true,formData`，workflowId 为字符串。源码取 `message.requestId`；首次创建已携带完整表单，不自动再保存相同行 |
| 空白草稿首次保存 | POST `/api/workflow/core/paService/v1/saveRequest` | query token；JSON `userid,requestId,isNewFormData,formData`。源码指导仅用于已确认的空白待提交草稿，不用来盲重写已落库完整草稿 |
| 既有草稿 patch | POST `/api/workflow/core/paService/v1/saveFormData` | query token；JSON `userid,requestId,formData`，userid/requestId保留精确整数词法；只发送受控patch。`oa.expense.amend`仅开放reason/destination两个主表Text，完整业务快照保全见[修订契约](expense-amend.md) |
| 正式提交 | POST `/api/workflow/core/paService/v1/submitRequest` | query token；JSON `userid,requestId,remark?`。该通用端点也能执行审批，新 CLI 必须限制为本模板已核验的待提交草稿，不能把用户的正式提交授权扩展为审批 |
| 同对象回查 | GET `/api/fna/workflow/core/paService/v1/getWorkflowRequest` | query `userid,requestId,access_token`；核对同一对象、workflow、form、操作者、全部字段/行/option/材料和实际状态，不只看 accepted |

普通附件 `FileComponent` 使用远端文件 ID；发票 `EinvoiceComponent` 使用 OCR 返回的 `infoId`，不能拿 `fileId` 替换。`ocrMap` 原样来自同一次上传，不能自行构造。购买方使用本张票的 `buyer.company` 或已核实原件事实，不使用销售方、申请单位或另一张票的购买方。

必须区分三类标志：上传的 `ocr=1`、OCR 的业务来源 `flag`、验真的固定 `flag=100`。差旅表单本身的来源码仍未确认；本 fixture 不迁移另一模板或 TEST 的默认码。独立个人文件保存路径已按参考插件固定来源13实现，必须先取得本次匹配预览，具体适用边界见 [票据保存契约](invoice-save.md)；它不替代表单关联协议。仅真实上游 `1674` 在旧代码中可归类为草稿 `not_applicable/valid=null`；它不证明真票，也不满足正式提交条件。

回查须校验 request/workflow/form 与主体，按字段 ID、各子表 dataIndex 和 option ID 比较完整目标，发现重复/额外有效行、漏附件、票据集合或金额差异即不宣称完成。源码草稿验收识别状态 `0/6` 与待提交标签、并排除 SUBMIT 日志，这些只是候选语义；生产状态码及提交后的节点、状态和日志证据尚待核实。submit 的成功响应不能代替提交结果回查。

新 CLI 已为材料草稿实现准备、确认、持久化子步骤、幂等与已知对象回查，使用自己的 SQLite 执行记录，不依赖旧 job/creation_pending 文件。上传或创建结果未知时不因超时、取消或缺 ID 盲重放；未来 OCR、保存和提交同样受此规则约束。源码未证明这些远端接口具备幂等键或按客户端键定位创建结果的能力，未知创建 ID 不自动查找最近单据。

## 旧规则冲突与当前处理

| 源码情况 | M3.1 处理 |
| --- | --- |
| travel_expense.py、policy.md 载有默认 180/半天 130/不领 0；当前 SKILL 又要求补贴口径不明时未决 | 记录这些历史值，不把它们当作当前人员/日期的生产默认。核实适用政策与用户真实领取事实后再冻结补贴规则 |
| 公共 form-data-contract、travel-detail-generation、travel-specific-verification 允许估算到达小时，甚至不标注预估；当前 SKILL 禁止猜航空到达时间，执行器对缺失小时记未决 | 不估算航空时长，不用申请计划替代实际到达事实；需要真实时间或可信核实来源。铁路既有查证能力是否纳入本轮需另按实际材料决定，不自动建设时刻平台 |
| 逐日算法以 Intake.days 生成；用户目前提供的出差申请不是票据，也不证明实际行程/实付金额 | 申请单仅作为材料与事实来源候选；实际日期、返程、交通、住宿、金额、费用归属及发票均需直接证据，不自动补返程或认定申请行程已执行 |
| 表单 schema 的业务必填可严于远端 required，当前 SKILL 与旧执行器对部分草稿有不同表述 | 首轮区分 payload 合法、业务完整、草稿落库和可提交。未核实远端 required/允许状态前，不利用“可选”放过必需业务事实，不宣称部分草稿已完整 |
| 历史人员/组织工具可有 ID 回退或去重；旧 write summary 缺成功码时可默认 accepted | 继续使用新 CLI 已有的严格人员规则与显式成功标记；不继承丢精度、ID 回退、缺标记成功或任意 raw 输出 |

这些是源码差异及本轮保守门槛，不是新增业务领域。政策与材料未核实的条目保持 pending，不以通用样例通过替代。

## M3.1 目标环境完成条件

1. 固定获准连接、独立 OA 操作者，以及唯一核实的被报销人；记录组织选项来源和代办关系，不根据 AgentOS 所有者或材料姓名自动改操作者。
2. 获得实际发票原件、实际差旅事实、收款与适用费用政策；本地按内容分类，支持材料不得冒充发票。补贴、到达时刻、票据归属和金额冲突均有可核实决议。
3. 在获准操作者视角确认该 workflow 可创建及正确 form；只读取得完整字段元数据，逐项核对 41 个候选字段、3 个子表、component/dataKey、required/delete、精度、长度、行数和选项范围，新增必填或差异显式处理。
4. 字段读取已核实为 `/workflow/v2/getFieldById`，query 为 `userid,id=formId`，仅接受顶层 formFields；SDK 的 `/form/v2/getFieldById` 不能替代它。保留完整去敏字段快照、来源摘要和标准化版本，不只替换两个 ID。
5. 验证目标城市级联与人员/部门/单位选项，核实发票上传、OCR 来源 flag、验真适用性、重复/占用判定及可观测回查能力。SDK 环境登记目前没有 travel_expense 的 production/test 写入绑定；不能凭源码常量设置 verifiedForWrite=true。
6. 明确草稿创建、保存/patch、提交各自允许状态、成功/拒绝响应及状态迁移；确定同对象回查和创建/提交未决的定位方法。没有可证实的远端幂等/定位能力时如实保留限制并阻止盲重放。

上述条件保留为完整差旅报销的验收要求。当前字段及流程绑定已经核对，不完整材料草稿已经生产创建并回查；完整票据实体、费用和提交仍须各自验收。源码 fixture、本机替身验证与生产验收分别记录，不能相互替代，也不据此勾选整个 M3。

## dev.14 生产文本差异与恢复

本次 dev.13 已创建草稿，事由返回 100 字，而发送为 182 字；原始事实全部保留，省略部分仅为重复待补声明，独立特殊说明 95 字完整。最初严格回查正确返回 uncertain，保留单号和六个文件 ID，不重复创建。证据见 [回读诊断](../reports/m3-draft-readback-diagnostic.json)。

新版事由仅含日期范围与用户事由，声明只在特殊说明中保存；成品事由/目的地使用保守 100 UTF-16 单元上限，超长明确拒绝。旧 v1 仅只读 reconcile 对上述严格条件允许重复声明截断并显式返回 `repeatedNoticeTruncated: true`；不放宽真实事实、人员、材料、金额或状态比较，不编辑生产单据。v2 与 v1 计划/输入摘要分离，旧 prepared 不在新版套用新序列化。

## 票据状态读取的固定来源

xasp保留分支eaf6428已实现版本化 `/api/inc/biz/v1/get` 与 `/api/inc/biz/v1/sync`；当前另一个分支SDK缺少方法不代表原协议不存在。新华清按 [票据读取契约](invoice-read.md) 对接，模型票号与OA业务ID保持区分，状态/已用金额未知时不推断可报销。当前操作者可见池结果不取代全租户防重或原子占用约束。
