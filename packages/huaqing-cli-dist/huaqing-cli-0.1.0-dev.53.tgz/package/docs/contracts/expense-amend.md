# 既有差旅草稿文本修订

`oa.expense.amend`（`oa expense amend`）属于M3.2，只更新已有差旅草稿的reason/事由和destination/目的地主表文本，不创建、上传、关联票据或填写财务/提交。CLI/API/MCP及operations包装共用执行器；MCP须显式allow-write，文本修订不需要材料根。

## 输入与调用

```json
{
  "targetRequestId": "9007199254740993123",
  "updates": {
    "reason": {"expected": "原事由", "value": "修订后的已知事由"}
  }
}
```

targetRequestId为正十进制字符串。updates至少一项，恰好允许reason/destination；每项必须同时提供expected和value。expected是从同一获准单据读取的精确旧文本，最多4096个UTF-16单元；不trim、折叠空白或NFC替换。value必须非空白、无控制字符、有效Unicode，最多100个UTF-16单元。每项expected必须不同于value，无效no-op在本地拒绝。只把value发送给OA，输入不覆盖凭据、操作者、字段ID或流程。

先按实际schema构造文件，使用同一配置、profile、操作者和状态目录：

```sh
huaqing schema oa.expense.amend --format json
huaqing operations prepare oa.expense.amend --input amend.json --idempotency-key TASK_AMEND_KEY --format json --non-interactive
huaqing operations apply EXECUTION_ID --input amend.json --yes --format json --non-interactive
huaqing operations status EXECUTION_ID --format json --non-interactive
huaqing operations reconcile EXECUTION_ID --input amend.json --format json --non-interactive
```

已经获准的具体任务也可使用`oa expense amend --input amend.json --yes --idempotency-key TASK_AMEND_KEY`。direct要求确认和稳定键，apply消费原executionId并要求原输入。dry-run仅作离线输入检查，未打开配置/状态或发请求，不证明旧值、目标或权限已经有效。写入口拒绝--output。

## 预检与稀疏写入

准备和认领后的派发前均实时核对：明确OA操作者、已配置的workflow/form、目标ID和创建人、可编辑/待提交且无SUBMIT记录，以及完整实时字段元数据。复用不完整材料草稿的七项映射和全字段明确可省略约束；出现新必填、删除或类型冲突时停止，不补造缺失事实。

本协议固定取自xasp提交`e5ece871ea88789e4dc5779931810244beb117bb`的SDK与实际CLI。详情GET `/api/fna/workflow/core/paService/v1/getWorkflowRequest`，保存POST `/api/workflow/core/paService/v1/saveFormData`；不自动切fna写域。来源与参考代码的证据限制见[固定来源](../reports/m3-amend-protocol-sources.json)。

保存请求由运行时在query注入应用access_token，无tenantKey header：

```text
{userid:精确JSON整数,requestId:精确JSON整数,
 formData:{formId:已核实表单,module:"workflow",
           dataDetails:[{fieldId:固定主表字段,content:新文本}]}}
```

大整数直接保留词法，不经Number舍入。只发送选定的1–2个fieldId/content，不重放完整原表单；无isNewFormData、isnextflow、删除或提交字段。空草稿saveRequest不是既有草稿编辑路径。

只接受运行时规范明确errcode=0；参考SDK某mock的200不是生产成功码。响应不必回新业务ID，message.requestId的tracking语义不能代替输入目标，也不被用于新建/所有权证明。最终必须读取原目标并验证全部业务值。

## 完整字段保全与恢复

prepare绑定完整dataDetails业务投影：字段及子表位置、所有content、完整有界dataOptions（含未知optionObj和附加属性）、未知字段值和未触行的物理身份。读取alias有冲突、重复字段/行、不支持结构或超界时明确失败。表单标题、UI权限和创建/更新时间不是业务值；独立metadata指纹仍校验字段结构。字段行返回顺序差异不产生假冲突，实际内容、附件列表/顺序和子表行变化都会拒绝或使回读失败。

原始正文和银行信息不写执行库。operationVersion只保存计划hash，inputHash绑定原输入与原计划。回查先验证修改字段为value，再将这些字段逆置为输入expected，重算原完整快照指纹；只有与原计划一致才返回preservedFieldsMatched=true。

派发前先持久执行/步骤。解码成功响应后，原目标ID先进入步骤和主回执，再检查取消和全量回读；这表示已知目标，不表示新建单据。丢响应时主ID可以仍为null，原输入已经明确目标，因此amend的reconcile允许读取它，但必须属于原operation/输入且保存步骤已经派发。prepared或派发前失败的执行不能被reconcile伪装成保存成功。

保存后取消、断线、状态提交或回读失败保持11、不重放；受控failureCode保留故障类别。status不加载凭据或联网，reconcile只读且不改历史uncertain。后续目标已提交或不可编辑时，reconcile仍可核对同目标身份和完整业务值；amendmentObserved仅表示内容已观察到，不宣称当前仍草稿、已经报销或正式提交由本操作执行。新写入及首次成功回读仍要求可编辑草稿。

输出包含targetRequestId、execution、changedFields、amendmentObserved、preservedFieldsMatched、readback、businessComplete=false及dryRun。prepare/dry-run未保存；cached表示历史结果，不是实时回查，preservedFieldsMatched=null。原创建计划描述旧版本内容，后续修订由新的amend执行记录追踪，不改写创建历史。

## 并发边界

同一本地状态的同一执行由CAS认领一次；同键同输入复用原执行，输入变更报冲突，未决不续写。上游接口没有已证实的原子版本条件，派发前完整读取与写入之间仍存在外部并发窗口。不同键、状态根目录、机器或OA网页上的编辑不由此CAS协调。调用方应给同一单据安排一个明确写入者；本协议不承诺全局条件更新或跨系统恰好一次，也不会把未触字段全量写回来覆盖其他编辑。
