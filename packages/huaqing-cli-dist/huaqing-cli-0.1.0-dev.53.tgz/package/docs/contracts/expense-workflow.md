# 差旅材料草稿流程

默认 Agent 流程由 `oa-workflow-expense` 的差旅 reference 编排。公共身份、流程命令和执行规则由 `oa-workflow` 提供。CLI、API 与 MCP 共用公开操作。既有 `oa.expense.draft` 混合材料调用继续按原执行契约工作。开发状态和真实验收见[里程碑](../development-milestones.md)。

## Skill 使用的公开操作

| 阶段 | 接口和通过条件 |
| --- | --- |
| 核对被报销人 | 用户明确确认或本次申请单明确标注后，使用宿主已开放的 `oa.person.resolve` 在同一 profile 精确查询。查无唯一人员时先报告需核实的信息，整批材料和票据步骤等人员确认后再开始。草稿写入仍执行自身的人员核验。 |
| 核对材料、表单及票池 | `oa.invoice.materials.check` 核对整批原件摘要与已提取事实。`oa.expense.invoice.preflight` 只读检查配置表单的实时发票专栏字段，返回 `formId`、`workflowId` 和 `invoiceFieldsVerified:true`。`oa.invoice.match` 在当前操作者可见池核对票号、日期、购买方、票面金额、占用和删除状态，完整查询且无匹配时返回 `absent`，歧义或不合格实体则失败。 |
| 创建草稿 | `oa.expense.draft` 接收已知差旅事实与普通支持材料，允许空 `materials`。已确认说明和待核实日期按[待补草稿契约](travel-expense.md)传入。Skill 携带支持材料的 `sha256`，草稿操作在访问 OA 前按本次快照校验。返回草稿 ID 和实时回读后，`oa.expense.inspect` 读取目标版本 `revision`。 |
| 获取票据实体 | `matched` 使用匹配得到的 `infoId`；`absent` 调用 `oa.expense.invoice.save`，绑定同一草稿和原件摘要，保存后回读真实 `infoId`。 |
| 关联与回读 | `oa.expense.invoice.link` 接收同一草稿 ID、`expectedRevision`、全部发票事实及实体 ID。只有 `linkedToDraft:true`、`readback:"live"` 且 `preservedFieldsMatched:true` 才证明专栏已写入。草稿保持 `businessComplete:false`。 |

每个写入使用独立稳定键并保存原输入与执行 ID。MCP 调用已开放的原生业务写工具，CLI 可使用 `operations prepare` 和 `apply`。各阶段沿用同一配置、profile 和状态库。草稿返回明确的派发前人员失败时，根据角色提示结束该分支。已派发且未决的步骤使用 `operations status`、`reconcile` 只读回查。基于现场结果报告已知草稿、已确认票据和待办阶段。草稿创建的回读只证明创建，发票专栏以关联操作的回读为准。

## 兼容调用的混合输入与事实边界

顶层沿用[差旅材料草稿](travel-expense.md)的已知业务事实。`materials` 可混合以下两类 PDF，合计最多 10 件，单件 16 MiB、总计 32 MiB，使用获准文件根下的绝对路径：

- support：`{path,kind:"support"}`，如出差申请单，进入普通 `FileComponent` 附件。
- invoice：`{path,kind:"invoice",sha256,invoice,description?,claimedAmount?}`，进入专用票据通道。`invoice` 使用[材料事实契约](material-facts.md)的结构；当前仅支持人民币、20 位票号。票号、开票日期、购买方、票面总额须非 null，逐项提供原件页码与摘录。其余票面事实按 schema 提供，净额与税额成对核对。

SHA-256 由原件字节计算；模型不生成摘要或 OA 实体 ID。每张发票须有完整必需事实，重复原件、票号、错误日期或金额及来源变化均明确拒绝。支持材料与发票分类按原件含义确定；结构化发票校验失败不会回退到普通附件。离线材料核对可处理图片，但本流程的专用入库材料限定 PDF。

`description` 是已确认的费用说明，省略时使用本次 `reason`，最多 100 个 UTF-16 单元。`claimedAmount` 仅在实际申领额已确认时提供：人民币两位小数字符串，须为正且不超过票面总额。未知时省略，代码不使用票面总额或零替代。银行、完整逐日行程、补贴及费用分摊缺失不会被猜填。

公开 schema 明确核心事实非 null、证据非空及规范 value。原文标签、中文日期和货币符号放入 quote，不能原样当作 value。航空行程单中的票价、基金、燃油与税额分别理解，只有事实支持时提供可选 netAmount/taxAmount，不把票价硬映射为净额。OFD 当前不原生支持；可靠转换须保留完整页面内容、图像及版式，文字重绘不构成原件转换。无法取得合格材料时报告格式缺口。

以下仅为结构示例，姓名、路径、摘要及票面事实均须替换为本次授权原件的真实值；示例摘要不可直接使用：

```json
{
  "mode": "incomplete",
  "travelerName": "测试员工",
  "applicationDate": "2026-11-08",
  "reason": "客户拜访",
  "destination": "深圳",
  "travelDates": { "start": "2026-11-01", "end": "2026-11-02" },
  "materials": [
    { "path": "/absolute/materials/travel-application.pdf", "kind": "support" },
    {
      "path": "/absolute/materials/invoice.pdf",
      "kind": "invoice",
      "sha256": "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      "invoice": {
        "format": "cn-20-digit",
        "currency": "CNY",
        "number": { "value": "12345678901234567890", "evidence": [{ "page": 1, "quote": "发票号码：12345678901234567890" }] },
        "date": { "value": "2026-11-01", "evidence": [{ "page": 1, "quote": "开票日期：2026-11-01" }] },
        "buyer": { "value": "测试购买方", "evidence": [{ "page": 1, "quote": "购买方：测试购买方" }] },
        "totalAmount": { "value": "123.45", "evidence": [{ "page": 1, "quote": "价税合计：123.45" }] }
      }
    }
  ]
}
```

## 兼容调用的一次执行

先用 `schema oa.expense.draft` 查询当前 schema。已取得具体草稿任务授权的调用方可一次执行：

```sh
huaqing oa expense draft --input '/absolute/intake.json' --yes --idempotency-key TASK_DRAFT_KEY --format json --non-interactive
```

需要先展示计划时，使用同一输入和任务键 `operations prepare oa.expense.draft`，再 `operations apply EXECUTION_ID --input ... --yes`。两者共用相同流程，一次确认覆盖本任务必要的 support 上传、建草稿、专用发票处理、专栏保存和回查。MCP 另须显式 `--allow-write` 与 `--file-root`。配置固定独立 OA 应用会话、授权操作者与已核实的 `travelExpense` 绑定；用户名不映射 OA 身份。

执行器依次完成：

1. 冻结全部原件快照，核对摘要、页码摘录与声明事实的一致性和同批重复；准备阶段只读核对模板、人员、发票元数据与可见票池，绑定计划摘要。
2. 将 support 原件上传到普通附件，以已知事实创建一张 `isnextflow=0` 的不完整草稿，并回读记录完整业务快照。只有发票时此步骤创建无普通附件草稿，由执行器继续后续步骤。
3. 按每张原件票号重新解析当前操作者可见票池。完整查询仅有一个事实一致、明确未占用且未删除的实体时复用；完整查询无匹配时沿[专用入库协议](invoice-save.md)上传，直接保存一次，严格核对回执并回读真实 infoId。歧义、范围不完整、事实或状态不符均停止，不另建实体绕过。
4. 再核对目标草稿及元数据未变化，以真实 infoId 写入专用发票子表。`EinvoiceComponent` 仅发实体引用，日期、购买方和说明按已核对事实写入；申领额未知时省略该格。关联协议复用[发票专栏关联](invoice-link.md)，保全其他字段、附件、子表、未知数据和物理行身份。
5. 完整回读同一草稿，核对本次专栏实体与明细，以及全部未触业务数据均被保全。只有通过该回读，才返回默认材料流程完成。

取得草稿 ID 后、任何票据入库前，先在同一本地状态库的 OA 应用作用域原子占用目标和全部票号，阻止不同任务键并发重复入库。该保护不替代 OA 对其他机器或客户端的服务端去重。尚未派发专栏关联且票据上传/保存状态均已明确时，可释放本执行的预留并保留历史；未知上传、未知保存、未经回查的保存或任何关联派发记录都会保留占用，不能靠换键或等待绕过。

该流程不提供通用工作流引擎，不新增模型或 OCR 服务。OA 自身命名为 `ocr` 的专用接口承担票据实体保存，不能用普通附件上传回执代替。历史预览 ID、附件 fileId、失败行 ID 均不能当作已保存 infoId。

## 输出与完成条件

`mode` 固定 `incomplete`，`businessComplete` 恒为 `false`。主要结果字段含义：

| 字段 | 含义 |
| --- | --- |
| `workflowComplete` / `invoicesLinkedToDraft` | 默认材料任务的发票入库或复用、专栏关联及保全回读均已确认；准备或 dry-run 为 false。 |
| `requestId` / `invoiceInfoIds` | 已记录的草稿 ID 与受信票据实体 ID；不能据此跳过完成判定。 |
| `readback` | `live` 为本次远端回读，`cached` 为同一原执行的历史成功，`not-run` 为尚未回读。 |
| `pendingClaimCount` / `claimAmountsConfirmed` | 本次未提供申领额的张数及是否全部明确；未知额保持待补。 |
| `missingFacts` | 仍待核实的财务事实、验真或最终报销资格；材料流程完成不等于费用齐备。 |
| `oaContext` | 新结果的环境、origin、操作者与 `uiVisibilityVerified:false`；dry-run 为 null，旧结果可缺失。API 回查不证明网页草稿箱可见。 |

新执行须同时满足 `workflowComplete:true`、`invoicesLinkedToDraft:true`、`readback:"live"` 才能报告本次默认材料流程完成。同键历史成功返回 `cached`，明确说明没有发起新回读。票据验真、完整财务与首提另按[完整差旅契约](expense-complete.md)及当前授权执行。

`oaContext` 含 `environment:test|production`、脱敏连接 origin、`operatorId` 和固定 `uiVisibilityVerified:false`。调用方先展示 API 观测所属的环境和身份；若用户要求页面可见，另在同环境、同 OA 登录人员的页面定位同一单据 ID。其他环境的列表、待办列表或 API 待提交状态，都不能直接等同于该用户的完整草稿箱验收，也不据列表未命中认定单据不存在。环境不一致时保留原配置，报告差异后复核入口。

## 幂等与未决恢复

整条默认任务使用一个稳定幂等键和执行记录，各远端写步骤先落账再派发。原件字节、路径、事实、模板、人员或配置上下文变化会拒绝旧计划；同键成功执行返回原结果。此保证依赖同一私有状态库，不扩展为跨机器或跨状态库去重。

退出 11、丢失最终输出或回查失败时，保留原输入、任务键、executionId 及已知对象 ID。先 `operations status`，再以原输入 `operations reconcile` 只读核对已知对象；未获受信回执的实体不按“最新一条”猜测。恢复不会自动重放上传、保存或关联，也不会将 uncertain 历史自动改成 succeeded。部分成功须报告具体已确认步骤与未决范围，不能换键创建另一张草稿掩盖失败。

输入错误的 `error.details.issues` 保留有界索引/字段路径、固定 code/expected，材料冲突沿同一结构报告。OA 拒绝可带 `upstreamError:{code,stage}`，供定位创建、票据保存或回查阶段，不包含上游正文。诊断信息不授权重放；默认流程未决继续用原 operation 回查，不能转到独立入库或关联入口再试。

独立 `oa.expense.invoice.save`、`oa.expense.invoice.link` 保留各自输入、确认、revision 与执行记录。混合调用未决时沿原 operation 恢复，已知目标的分步办理按上文公开操作执行。

## 兼容与范围

`oa.expense.draft` 的 support-only 或 `materials:[]` 输入沿原材料草稿流程。混合执行 v1/v2 仍使用各自的历史缓存与只读恢复规则。

[往返居住地草稿](home-travel-expense.md)继续使用独立 operation、输入与模板绑定。本次默认差旅流程不扩大 home 的财务、票据关联或提交范围。
