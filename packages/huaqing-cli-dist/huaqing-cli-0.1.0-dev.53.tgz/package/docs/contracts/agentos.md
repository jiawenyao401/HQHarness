# A 与知识库契约

固定源码 `agentos-mvp@3b1fa5c965a2df79f7d3172d580eabc5e407a289`。开发及真实部署验收状态见[里程碑](../development-milestones.md)。A为独立可选provider；移除A连接不影响OA认证、操作者或执行。

## 配置与认证

连接声明 provider=agentos、明确environment/baseUrl、usernameRef/passwordRef及必要的allowPrivateHttp。仅凭据引用，不保存明文密码。HTTPS/受控内网HTTP规则与公共配置一致。`auth login/status/logout --provider agentos` 使用独立A会话，默认provider仍为oa。

GET `/auth/login-options` 必须明确password_login_enabled；然后无浏览器Origin地POST `/auth/login`，凭据仅在JSON body，接收受支持token返回方式。只启用SSO的部署拒绝此路径，不造设备授权服务或擅改Desktop回跳。`agentos.me`通过Bearer访问 `/auth/me`。

access/refresh/session及身份保存在既有CredentialStore的新加密版本中；SQLite仅保存scope/hash、到期及引用。scope绑定profile、配置真实路径、连接环境/地址、凭据引用及解析后用户名摘要；同一引用换账号时拒绝复用旧会话，应先退出原会话。logout沿已绑定scope清理，无需重新解析用户名/密码。A profiles不共享会被远端logout撤销的session。令牌轮换使用原生 `/auth/refresh`，本地租约/generation协调；首次业务读取不隐式登录，已登录会话按期限刷新。

认证派发先持久化标记；失去回执后不重放旧refresh。已解码会话先保存再暴露迟到取消。status不解析秘密、打开凭据后端或联网，active只表示本地期限。logout通过原生 `/auth/logout`撤销session；远端确认以加密tombstone持久化，后续本地清理失败/取消不会再撤销或刷新，重复logout只完成清理。

## 知识库

`knowledge.context`访问 `/knowledge/context`，仅返回userId/tenantId/tenantName/role。其他操作经过现有 `/knowledge/api/...` 白名单代理，使用员工Bearer，不读取管理员密钥或下游委托APIkey。

- search：显式knowledgeBaseId，POST `knowledge-bases/{id}/hybrid-search`，query_text、match_count和vector_threshold按固定契约；结果保留命中内容及可用文档/片段来源，最多100条。
- get：GET `knowledge/{id}`，校验目标ID并投影已知字段；实际内容/文件元数据缺失时不补造。
- download：GET `knowledge/{id}/download`，同源代理的有界字节流；不追随供应商URL或重定向。显式绝对targetPath，父目录必须存在，上限以当前schema为准。同目录0600临时文件写入后以独占link发布，已有目标/符号链接/竞争拒绝覆盖，失败或取消清理本次临时文件。

跨Agent共享资源的scope必须同时包含agentId与sourceTenantId，映射为既有agent_id/agent_source_tenant_id；资源可见性仍由服务端实时ACL判断。401/403与协议、限流、超时分开报告，不切换账户绕过。MCP开放已登记读取操作，下载保留标准进程入口。

真实部署的登录开关、会话撤销、租户、合法知识库、共享资源和附件拒绝需要统一验收；本机HTTP替身通过仅证明协议与故障行为。文档正文/命中内容及链接作为业务数据处理。
