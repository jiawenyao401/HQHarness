# Harness 多模态材料事实

`oa.invoice.materials.check` 对应 `oa invoice materials check`，离线核对 Harness 提取的事实、原件摘要和确定性规则。CLI、API 和 MCP 共用执行器，MCP 在启动时配置文件根。旧 `oa.expense.materials.check` 使用同一实现。

输入每件原件的绝对路径、字节 SHA-256 和分类。支持 PDF/PNG/JPEG，最多10件、单件16MiB、总计32MiB；扩展名与签名必须相符，拒绝符号链接及读取中变化。签名检查不等于完整文件解码。当前普通 OA 附件上传仍只接受 PDF。

分类为 invoice/support/unknown。发票当前支持 `format: cn-20-digit`、CNY，20位票号保留字符串及前导零；不支持的票制需另行核实，不能猜格式。核心事实为 number/date/buyer/totalAmount，各值为 null（未知）或 `{value,evidence:[{page,quote}]}`。seller 可省略；netAmount/taxAmount 可同时省略，如提供其中之一，另一项也须提供并核对净额加税额等于价税合计。

`value` 为规范事实，`quote` 为原文摘录；票号不带标签，日期使用 ISO，金额不带 ¥/CNY 前缀。航空行程单的票价与净额不自动等同，基金、燃油等项目不能遗漏后硬凑净税合计；不适用的可选净额/税额可省略，已声明而矛盾的事实须回原件核实。

日期取开票日期，严格合法日历 `YYYY-MM-DD`。金额为非负、固定两位小数字符串，单票金额最多12位整数，总额大于零；使用整数分运算，不舍入模型结果。每个已声明事实需要摘录及页码，日期和金额按完整 token 比较，支持中文日期和规范千分分组。单张图片的页码为1；PDF 页码仅校验为正整数，不解析或证明该页存在。

返回 `consistent` 或 `needs-review`。缺事实/证据、非法日期/金额、摘录不匹配、净税不等、重复字节或重复票号均为 review issue，不猜值。原件摘要不符是退出6，结构/文件输入错误为2；needs-review 是一次成功的检查，不是写入授权。只有至少一张发票且全部材料无 issue 时返回票面 `totalAmount`，否则为 null。支持材料不计金额，unknown 保持待核实。查重只覆盖本次输入，不查 OA 或历史报销。

结果包含逐件原件摘要、事实摘要及字段级 issue，不回显票号、姓名、原文摘录或路径，不持久化输入。事实摘要绑定当前协议、原件、分类和规范化事实/证据，不能充当 OA 发票 ID。

默认草稿的公开 schema 进一步要求核心事实非 null、规范格式及非空证据；输入失败提供品牌化 `error.details.issues`，仅包含有界材料索引/字段路径、固定问题码和 expected。默认流程中的 needs-review 保留同一安全问题投影，例如 `/materials/1/invoice/totalAmount` 与 `AMOUNT_MISMATCH`，不丢弃原因后要求盲试。通用材料检查仍允许 null/非规范事实并返回 review issues，不改变其图片支持。

OFD 当前没有原生读取或入库支持。专用写入须提供原 PDF，或经完整视觉核对、保留页面内容及版式的可靠转换；文字抽取后重绘的文件不能冒充原件。扩展名或分类变化不会扩大支持范围。

固定 assessment 声明：extractedBy=harness、sourceBytesMatched=true、visualContentVerified=false、authenticityVerified=false、oaRegistered=false、reimbursementEligibilityVerified=false。摘录一致仅检查调用方提交的文本，不证明图像中的实际内容；票面合计也不是最终可报金额。

## 与 OA 发票业务的关系

用户明确由多模态模型读取材料，因此不建设独立本地 OCR/模型服务。当前核实的旧定制协议中，`/api/inc/biz/v1/ocr` 还承担发票实体保存，并返回 `infoId`；报销 `EinvoiceComponent` 使用该 ID，普通附件 `fileId` 不能代替。旧源码没有已实现的手工入库或有效远端查重接口，不把传递模型 JSON 给未知字段当作替代协议。

OA 发票入库、验真及占用状态仍是后续业务契约：若目标提供受支持的非识别入库接口则对接该接口；若目标必须调用其保存型接口，则仅作为 OA 业务步骤核实和记录。材料读取路径已经独立，不依赖它完成图文识别。来源核对与开发状态登记在开发里程碑。
