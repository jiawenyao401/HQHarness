# OA 单票保存契约

独立 `oa invoice upload` 只返回发票原件 `fileId`。当前完整入库入口 `oa expense invoice save` 自行执行上传和票据保存，保留防重与回读边界。需要完成入库时直接选择该入口，避免先单独上传同一原件。

`oa.expense.invoice.save`（`oa expense invoice save`）属于M3.2：为当前操作者明确的待提交差旅草稿上传单份PDF，直接保存个人票夹实体一次，再严格核对回执和实体回读。CLI/API/MCP使用同一目录和执行器；MCP须显式allow-write和file-root，所有材料读取受同一授权约束。

本操作只保存票据实体。`targetRequestId` 绑定目标草稿及任务上下文，不写 `EinvoiceComponent`、不修改或新建草稿，不正式提交。成功结果固定 `linkedToDraft=false`；后续关联使用独立的[`oa.expense.invoice.link`草稿专栏关联契约](invoice-link.md)，不必等待银行或完整行程资料，不能从本操作成功推断已经报销。

## 输入、前置条件与命令

输入恰好包含 `targetRequestId` 和 `material`。targetRequestId 为 1–128 位正十进制字符串，无前导零。material 使用[材料事实契约](material-facts.md)的 invoice 结构：绝对路径、原件 SHA-256、`kind:"invoice"`、`format:"cn-20-digit"`、CNY，以及 number/date/buyer/totalAmount 四项带页码摘录的事实。

本切片只接受一份 PDF、一个票据实体，单件最多 16 MiB。结构化材料检查必须为 consistent；四项核心事实都必须已知。票号为20位非全零字符串，日期为合法日历 `YYYY-MM-DD`，购买方明确，合计大于零且固定两位小数。不接受用 null、文件名、申请计划或默认值补足事实。Harness 用自身 PDF/多模态能力读取原件；CLI 不新增模型账户、本地 OCR 引擎或独立识别服务。

原件经文件类型、签名、摘要和稳定读取检查后形成不可变快照；后续上传只使用这份快照字节。材料事实校验不证明模型真正看到了对应页面，也不证明发票真实有效。图片材料仍可进入本地材料检查，但不进入本切片的 PDF 保存入口。

连接必须已登录独立 OA 应用，配置明确 OA 操作者及已核实的差旅 workflow/form 绑定。不能从 A 端用户名或票据姓名选择员工。派发前重新读取目标，要求请求 ID、workflow、form、创建人一致，可编辑，状态明确为草稿/待提交，且日志没有提交记录；缺字段或冲突即停止。

业务输入文件 `invoice-save.json` 只放上述业务对象，凭据保持在本机配置引用中。推荐先准备再执行：

```sh
huaqing operations prepare oa.expense.invoice.save --input invoice-save.json --idempotency-key TASK_INVOICE_KEY --format json --non-interactive
huaqing operations apply EXECUTION_ID --input invoice-save.json --yes --format json --non-interactive
huaqing operations status EXECUTION_ID --format json --non-interactive
huaqing operations reconcile EXECUTION_ID --input invoice-save.json --format json --non-interactive
```

已获具体任务授权的调用方也可直接执行：

```sh
huaqing oa expense invoice save --input invoice-save.json --yes --idempotency-key TASK_INVOICE_KEY --format json --non-interactive
```

prepare 可核验身份、读取目标和查询当前操作者的票夹，但不上传、不保存、不修改 OA 业务；它创建默认10分钟有效的本地执行记录。apply 必须再次提供原输入并确认，重新核对原件、目标和票号。直接执行必须有稳定幂等键和确认，与 prepare/apply 使用相同闭环。`--dry-run` 只适用于直接 operation，离线返回未运行结果；它不证明材料、配置或目标已通过真实预检。所有写入效果入口拒绝 `--output`。

## 协议来源与来源码边界

版本化 OpenAPI 上传和保存协议来自 xasp 固定提交 `eaf64280a69e0f1889c44cb52d077faf045d7152` 的 invoice SDK、transport 和实际调用代码。后续分支用于核对 source 配置语义。当前另一分支缺少旧方法，不能据此否定固定提交的协议。文件摘要及可复查步骤见[来源报告](../reports/m3-invoice-save-protocol-sources.json)。交付实现不依赖 xasp 代码、Python 进程或参考插件。

本操作来源固定为 **personal-file**，`flag=13,operate_type=0`。13 的来源依据保留原核查；版本化路径、OpenAPI 认证及 userid 编码按 xasp 定制协议。当前写入链按 xasp 正常调用直接使用 `is_save=0`，不先调用 `is_save=1`，也不发送插件附带的 `is_sync`。调用方不能覆盖来源、token、tenant 或 userid，来源拒绝时保留原错误和执行记录。

领域版本 `travel-invoice-personal-file-v2` 固定上传、单次保存和严格回读。兼容混合材料调用使用 `travel-invoice-workflow-v2` 并绑定同一协议摘要。旧 v1 的成功缓存及按原摘要的只读恢复仍可用，旧 prepared 在派发前报告计划变化。真实正例和拒绝路径分别验收。

旧源码没有找到已实现的、可直接提交任意模型 JSON 的手工结构化入库协议；这不等于断言 OA 服务本身没有此能力。当前 `/api/inc/biz/v1/ocr` 同时承担 OA 侧票据实体保存，是必要业务步骤。Harness 事实提取保持独立，不能通过未知 add 路径或 JSON 字段绕过这个契约。

## 固定请求与执行顺序

以下路径追加在已配置的 OpenAPI base 之后。tenantKey 始终来自同一固定连接，以 header 发送；业务不接受任意 header、请求体或路径覆盖。应用 token 仅由运行时注入。

| 阶段 | 请求 | 固定字段及凭据位置 |
| --- | --- | --- |
| 可见票夹检查 | POST `/api/inc/biz/v1/sync` | 按[发票读取契约](invoice-read.md)扫描票号；userid 为 JSON/query 字符串，token 在 query |
| 原件上传 | POST `/api/inc/file/v1/uploadFileSpilit` | multipart：`file`、`userid` 字符串、`ocr="1"`、`access_token`；无 token query |
| 实体保存 | POST `/api/inc/biz/v1/ocr` | JSON：`userid` 字符串、`image_index`、`fileTypeStr="pdf"`、`ocrMap`、`flag=13,operate_type=0,is_save=0`、`access_token`；无 query，无 `is_sync` |
| 持久实体回读 | POST `/api/inc/biz/v1/get` | JSON `ids:[infoId],userid`；userid 同时在 query，token 在 query |
| 精确票号回查 | POST `/api/inc/biz/v1/sync` | 完整扫描后要求票号逐字匹配的实体恰好一个，且 ID 等于本次保存 ID |

prepare 及 apply 派发前都要求当前操作者可见范围的票号查询完整且为空；已有实体时拒绝新增，应先 inspect。该读取不是租户级防重，也不能排除其他操作者持有同票。整个过程不使用 Cookie、ETEAMSID、参考插件 invoice token、Web `/api/inc/ocr` 或未核实的接口回退。

上传响应必须给出合法的 `data.id` 和/或 `data.ids`、PDF fileType 及非空 ocrMap；ocrMap 最多1 MiB，作为不透明字符串原样绑定随后一次保存，不解释或重造。id/ids 去重后必须只有一个，不能机械选第一项。回执数组最多100项，超过边界显式失败，不能截取前100项继续。

保存要求外层明确成功、data 为对象、没有 fail=true、res_base（如出现）明确 ret=0，并且 infos 恰好一项、逐项 ret.ret=0。不能用外层0、存在 ID 或上游成功文案覆盖嵌套失败。1686 对应已添加重复，1705 为另一类重复拒绝，2059 与 2069 为票据规则拒绝。外层和嵌套拒绝统一映射 OA_INVOICE_ALREADY_ADDED、OA_INVOICE_DUPLICATE、OA_INVOICE_POLICY_REJECTED。`fail:true` 与逐票拒绝码同时返回时，保留业务码和阶段，整份回执的受信 ID 为空。具体命中规则由 OA 侧证据确认。重复码不独立证明持有人，不得把失败行返回的 ID 认作本次拥有或创建的票据。

保存返回及完整实体回读逐字段核对 `info.number`、`info.comm_info.pro.date`、`info.comm_info.buyer.company`、`info.comm_info.price.total`。日期当前只接受严格 ISO 日历字符串，不猜时间戳单位或时区；购买方做 NFC/首尾空白规范化后精确比较。金额保留 JSON 数值词法，以整数分作精确等价比较，允许额外尾零，不舍入非零厘位，不经 Number 浮点转换。

## ID、输出与未知状态

上传文件 ID、普通附件 fileId、票据实体 infoId 不可互换。上传回执 ID 只是原件处理标识；历史预览中的 info.id 即使为正值也不是持久入库或所有权证明。保存必须返回明确正十进制 info.id；完整 get 要求唯一项、显式 ret.ret=0、info.id 与请求一致，若 fid 同时存在则必须同值。最终还必须通过精确票号回查。

公开成功输出保留 targetRequestId、infoId、execution、invoiceSaved、linkedToDraft、readback、factsMatched、eligibility、authenticityVerified、dryRun：

| 情形 | invoiceSaved | readback | factsMatched |
| --- | --- | --- | --- |
| prepare 或 dry-run | false | not-run | null |
| 本次保存及双重回读通过 | true | live | true |
| 同一已成功执行的本地缓存 | true | cached | null |
| 已知 ID reconcile 回读通过 | true | live | true |

infoId 在没有持久主对象时为 null；execution 在 dry-run 为 null。cached 仅表示本地已有成功记录，没有本次远端核验。eligibility 恒为 unknown、authenticityVerified 恒为 false、linkedToDraft 恒为 false。找到并保存票据不证明验真、未占用、费用政策、最终可报金额或草稿关联完成；缺失状态不得补零或解释为未报销。公开结果不回显购买方、完整票面、摘录、文件路径、下载链接或上游错误正文。

## 幂等、已知回执及退出11恢复

准备摘要绑定协议来源摘要、固定来源码、操作版本、连接/应用/操作者、目标 workflow/form/requestId、事实及证据、原件路径/文件名/字节数/SHA。输入、原件或上下文变化不能消费原执行。运行时先持久化执行及步骤派发状态，再发请求；本地状态不可写时不开始 OA 写入。

`invoice-upload` 和 `invoice-save` 的受信回执 ID 去重后先作为一个集合原子入账，再做单票数量与事实判断。≤100项合法回执全部保留，多个结果不能自动选一个作为主对象；只有保存回执恰好一个受信实体 ID 时才能作为主对象。OCR 失败行的 ID 不进入成功集合；混合响应只保留明确 ret=0 行的合法 ID，随后仍拒绝整次业务成功。步骤 receipt 的 succeeded 表示 ID 回执已记录，不代表票据事实或整次业务验收通过。

收到已确认回执后，即使随后取消、操作者失效或本地持久化失败，也先保留已知 ID，再停止下一步。已派发后的断线、超时、拒绝、歧义、事实不符、回查失败或取消均按已派发写入处理，返回 `WRITE_EXECUTION_UNCERTAIN`、退出11及受控执行摘要；不能据此断言远端未发生。原件上传也可能已经产生远端文件，不做隐式删除或回滚。

执行摘要可带可选 failureCode，来自 schema 中的闭合枚举，区分重复/策略拒绝、协议、网络、事实不符及回查失败。新错误另可带 `upstreamError:{code,stage}`，只保存可信数值业务码及固定内部阶段，不保存上游原文或任意 details；旧执行没有该证据时保持缺失。步骤状态、已知 ID 与退出11保持原义，不依据新分类改写历史。

退出11后保留原输入及 executionId，先执行 operations.status。已知唯一保存实体 ID 时，可用原输入执行只读 reconcile，完成完整 get 与精确票号回查；它不续传、不保存、不修改草稿、不改写历史 uncertain。只有上传 ID、没有唯一保存 ID 或有多个保存 ID 时，不能自动 reconcile 选一个或重放，应保留所有回执核实实际结果。数据库落盘失败时，错误 envelope 中的受控已知 ID 同样需要保留。

保存阶段有 OA 拒绝码且没有可信实体 ID 时，错误提示指向 `operations status` 和 `oa invoice +match`。后者可按原票面事实只读核对当前可见票夹，结果不归属到原执行，也不解除票据占用。

幂等键相同且摘要相同只复用原执行，摘要不同返回 IDEMPOTENCY_CONFLICT；已派发执行不自动续写。不得换 key、换操作者或删除记录重试。强制终止可能没有最终 envelope，不能解释为没有写入；丢失 executionId 时使用原输入、原幂等键查询原执行。

## 生产并发范围与验收

SQLite 执行认领与新执行的应用作用域目标/票号占用只协调同一本地状态库，阻止改用其他入口或任务键重复入库；既有旧记录不补造归属。不同状态根目录、容器/机器或其他客户端仍可能竞争保存同票，票夹查询与保存之间也不是全局原子事务，本操作没有已验证的上游全局幂等键。

生产调度应让同一发票任务使用一个明确执行者和稳定幂等键；不能把多个独立状态库的并发调用当作已协调。共享应用令牌刷新另受 OA 应用级轮换约束，不能通过切换 profile 绕过。本操作不引入常驻协调服务，也不承诺跨实例恰好一次。

来源核对、替身测试与真实 OA 验收是不同证据。协议实现和故障测试不能代替生产接入成功；当前开发状态、实际生产结果及下一步只登记在[开发里程碑](../development-milestones.md)。
