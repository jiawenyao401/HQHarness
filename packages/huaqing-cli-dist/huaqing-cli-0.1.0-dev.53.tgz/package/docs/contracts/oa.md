# OA 源码契约与脱敏样例

本基线取自 xasp 提交 `e5ece871ea88789e4dc5779931810244beb117bb`。以该提交的 Git blob 为摘要对象，每份 fixture 的 `sources` 保存仓库相对路径和 SHA-256。`kind: source-derived` 与 `liveCapture: false` 表明数据由源码、模型、文档和 mock 测试合成。没有使用真实服务抓包、人员、地址、账户或凭据。表单、流程和字段的固定定义 ID 保留，以便后续核对版本。`FIXTURE_*` 和其余数据 ID 都是合成占位值，禁止传到真实服务。

## Fixture 入口

| 文件 | 内容与用途 |
| --- | --- |
| [auth.json](../../tests/fixtures/oa/auth.json) | 取码、换票、刷新、历史拼写、嵌套业务错误、成功标记但关键字段缺失 |
| [person.json](../../tests/fixtures/oa/person.json) | 按 OA ID 与正式姓名查询、完整分页、模糊结果、空结果、重复人员和无效 ID |
| [workflow-read.json](../../tests/fixtures/oa/workflow-read.json) | 待办、空页、详情、拒绝、异常结构与大整数精度 |
| [home-travel-expense.json](../../tests/fixtures/oa/home-travel-expense.json) | 候选模板和字段字典、两类上传、保存型 OCR、草稿创建与修订、提交及回查 |
| [travel-expense.json](../../tests/fixtures/oa/travel-expense.json) | 用户指定实际差旅报销后的首模板源码候选；41 字段、3 子表、30 份来源摘要及独立协议样例，尚非目标生产核验 |

`request.path` 相对于 profile 的 OA OpenAPI base URL，保留其 `/papi/openapi` 等前缀。`request.json` 描述 JSON 对象；`request.jsonText` 是必须保持的 JSON 文本，用于验证上游要求数字且超出 JavaScript 安全范围的字段。`request.multipart` 用结构描述应发送的表单 part，文件对象只是名称、媒体类型及 fixture 标记。`response.httpStatus`、`response.body` 供测试服务器返回；样例中的 `expect` 是验证场景名称，公开错误码以华清运行时契约为准。

在固定来源的检出目录核对单项摘要时可运行 `git show COMMIT:PATH | shasum -a 256`。按 fixture 逐项验证摘要、HTTP 方法、路径前缀、字段类型、认证注入位置、请求次数及输出脱敏。源码 fixture 通过后再单独记录真实环境验收。

## 认证与应用会话

| 动作 | 线协议 | 成功与安全条件 |
| --- | --- | --- |
| 取授权码 | `GET /oauth2/authorize`，query `corpid`、`response_type=code`、`state` | JSON `code` 非空、600 秒且一次性。`state` 为不超过 128 位的 ASCII 字母数字；xasp 响应模型无已核验回显 |
| 换票 | `POST /oauth2/access_token`，JSON `app_key`、`app_secret`、`grant_type=authorization_code`、`code` | `accessToken` 或旧拼写 `acessToken`、`refreshToken`、`expires_in`。换票不确定后弃用旧 code |
| 刷新 | `POST /oauth2/refresh_token`，JSON `grant_type=refresh_token`、`refresh_token` | 支持 access/refresh 轮换。缓存作用域隔离，跨进程锁内重读并更新。响应不明时不覆盖新会话 |
| 调用 | M2 业务用 query `access_token`；M3 两个发票端点分别在 multipart、JSON body 注入同名字段 | 不允许业务输入提供或覆盖凭据，取得有效凭据后再发送，重定向不转移凭据 |

xasp 默认 access 7200 秒、refresh 本地估计 86400 秒，提前 60 秒视为待续期。真实续期与共享应用跨机器行为待 M2.2/M2.5 验证。应用认证响应不包含人员主体。华清 `auth status` 默认只读缓存，`remoteVerified: false`；`doctor --provider oa --live` 可用已配置操作者的待办首页一条记录作最小探针，单次成功只证明该调用成功。退出解除本地引用，远端撤销能力另验。错误解析识别 HTTP 错误、顶层和嵌套 `message.errcode`、字符串或数字零、关键字段缺失；按端点另验允许的差异。反向代理、客户端日志和错误 URL 不留 token、授权码、应用秘密及敏感表单。

[认证源码](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/auth/service.py:50) [本地缓存](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/_token_store.py:160) [状态契约](/Users/jiawy/Documents/xasp/xasp/docs/reference/cli/auth.md:23)

### 独立认证模块契约

`src/providers/oa/auth.ts` 实现 `OaAuth.getCode/exchangeCode/login/refresh`。取码与令牌响应均交给受保护的凭据存储。`src/providers/oa/transport.ts` 集中处理固定认证端点及带凭据的业务请求。业务入口取得有效应用令牌后才能发送。认证模块独立于 A 用户、OA 操作者和 Harness 文件。

| 原子命令 | 操作 ID | 执行边界 |
| --- | --- | --- |
| `oa auth get-code` | `oa.auth.code.issue` | 调用取码端点，保存选定 profile 的一次性授权码，仅返回状态及本地到期时间。 |
| `oa auth token` | `oa.auth.token` | 消费同一 profile 的有效码后调用换票端点。并发或丢回执时旧码不会重放。只返回应用会话状态。 |
| `oa auth refresh` | `oa.auth.refresh` | 仅在应用会话临近到期时发起续期，`renewed` 表示本次调用完成实际续期。业务请求也使用同一会话管理器自动续期。 |

`auth login` 仍提供组合入口。三个认证动作均只通过 CLI 调用，授权码和原始令牌留在凭据存储内。`auth logout` 也清除选定 profile 的待兑换授权码。

默认 HTTPS，test 环境允许既有 localhost/127.0.0.1/[::1] HTTP 测试入口。对已经授权的内网 HTTP 部署，连接必须显式声明 allowPrivateHttp=true，且原始 authority 的主机部分必须是标准点分 RFC1918 IPv4，和 URL 解析后的 hostname 一致；整数/十六进制/八进制/短写/编码主机、DNS、公网和 IPv6 均不进入该例外。开关严格为布尔值，默认 false；不自动换协议或环境。固定 origin/前缀、禁止 URL 内凭据和全部重定向的规则保持不变。HTTP 中的应用秘密、令牌和业务数据不加密，网络保护属于部署条件，地址范围检查不能替代它。

- code、应用凭据与 token 必须非空、不含空白/控制符且不超过 16384 字符。标准与旧 access 拼写均非空时必须相同；标准字段缺失/空字符串可回退旧拼写。
- `expires_in` 必须显式返回正的安全整数秒数，不接受数字字符串；缺失不采用旧 SDK 的 7200 秒默认值。到期时间从换票/刷新发起时刻计算，超过安全整数或接收时已耗尽均失败。refresh 必须返回完整令牌对，可原样返回也可轮换，不猜测缺失的 refresh 值。
- 成功必须有顶层 `errcode` 或 `message.errcode`，只接受数值 `0` / 字符串 `"0"` 为成功；两个同时存在时须一致。缺失、类型错误或冲突为协议错误，非零为认证/业务拒绝。数字文本下溢不能伪装成零。
- 内部业务输入不允许在 query/JSON（包括嵌套字段）携带 access/refresh、app key/secret 或 authorization。参数在等待凭据前快照；认证动作限制固定字段和 grant 类型。没有可指定任意 URL/header 的公共命令。
- 默认 30 秒总 deadline，认证两阶段共用预算；包含取得凭据、响应头、流读取与解析完成核验。外部取消不发送后续请求。默认响应上限 4 MiB，最大可配置 16 MiB，UTF-8/JSON/根对象异常拒绝，超限及取消关闭流。所有 3xx 拒绝，不自动重试或自动刷新。
- 接收超长 JSON 整数时使用 Node 24 的原始数字文本保留为字符串；非有限、不安全指数数值拒绝。业务输入中的不安全 JS 整数拒绝发送。需要数字线协议的 operator ID 由 M2.3 的字段编码实现，不允许先转为有损 Number。

| 错误 | 退出码 | 含义 |
| --- | --- | --- |
| `OA_REQUEST_INVALID` / `OA_AUTH_CONFIG_INVALID` | 2 | 连接、路径、参数或应用凭据结构无效 |
| `OA_AUTH_FAILED` / `OA_REFRESH_TOKEN_INVALID` | 3 | HTTP 401、认证业务拒绝、未取得会话或无效刷新输入 |
| `OA_PERMISSION_DENIED` | 4 | HTTP 403 |
| `OA_HTTP_ERROR` / `OA_RATE_LIMITED` / `OA_TIMEOUT` | 5 | 网络、HTTP/重定向、流中断、HTTP 429 或总时限 |
| `OA_PROTOCOL_ERROR` / `OA_AUTH_RESPONSE_INVALID` / `OA_BUSINESS_ERROR` | 6 | 格式、认证必需字段或业务拒绝 |
| `CANCELLED` | 130 | 调用方取消 |

上述传输错误均不标记可重放，不附带原始 URL、响应、异常 cause 或上游错误文本。凭据回调的失败固定为 `OA_AUTH_FAILED`，具体凭据诊断在登录/引用解析入口处理。测试用公开模块接口、来源 fixture 和本机 loopback HTTP 服务；它们不证明真实 OA 的认证及权限可用。

### 持久化应用会话

`OaSessionManager` 的 login/getToken/logout/status 集中管理共享应用缓存；CLI 生命周期经 `runOaAuth` 接入同一运行时和目录。标准调用输出、配置与存储选项见 [CLI 契约](cli.md) 和 [使用说明](../../README.md)。

| 行为 | 本地保证 |
| --- | --- |
| 登录 | 解析显式引用；相同应用复用有效缓存、临近到期串行刷新；首次派发前即登记 profile 绑定，使请求中断可被 status/logout 找到 |
| 业务取票 | profile 必须已登录；等待锁后重读版本；提前 60 秒续期；uncertain、缺失槽、后端不符及绑定冲突均拒绝，不自动新取 code |
| 轮换 | 先记录派发，再调用；新秘密以 UUID 槽持久化，generation 条件发布；旧版本入持久清理队列；租约失效的响应不能覆盖后继版本 |
| 状态 | 只读 SQLite，无网络/秘密解析。显示缓存期限、配置的 operatorId 和 cleanupPending，remoteVerified 固定 false；不据此声称人员或权限已认证 |
| 退出 | 非最后绑定只解绑；最后绑定在持久删除意图之后清除当前及旧槽，再原子解绑。失败保留恢复状态；迟到删除仅影响旧 UUID，不影响新建版本 |
| 恢复 | 丢失响应、失效派发租约、保存结果不明均阻止旧 refresh 重放；显式 login 申请新 code，明确退出失败可修复存储后再 logout |

`AUTH_SESSION_UNCERTAIN` / `AUTH_COMMIT_UNCERTAIN` 为退出 11，外部超时不能盖掉未决状态。已知 OA_AUTH_FAILED/权限/限流错误保留原退出码。`OA_LOGIN_REQUIRED`、`AUTH_STORE_MISMATCH`、`AUTH_SESSION_CHANGED` 为退出 3；`AUTH_BINDING_CONFLICT`、`AUTH_ENVIRONMENT_CONFLICT` 为退出 2。所有会话变更失败均不承诺安全重放。

连接的应用作用域包含环境、origin/路径、tenant、corpid 和实际应用凭据版本；引用名称和 operatorId 不参与应用会话身份。profile 绑定按配置 realpath/profile/provider 识别，改名的引用仍可找到旧会话；换应用必须先退出。同一状态根目录登记实际应用凭据的测试/生产归属，跨机器隔离属于真实部署验收。

认证预算覆盖锁等待、存储操作及网络；租约长于预算 5 秒，不通过延长租约允许已过期执行发布。SQLite 使用 WAL/FULL，状态读取不创建库或隐式迁移；schema 1/2/3→4 的写入口事务迁移保留业务执行、认证及人员核验证据。v4 为新执行增加只读恢复绑定，不为历史执行补造绑定。主密钥不可用时拒绝解密或降级，令牌与应用秘密不写入 SQLite、日志和公共输出。多存储之间没有原子提交：写槽完成但还未登记引用时发生硬杀可能遗留密文；该残留不是可用会话，不能凭它继续刷新。

本地进程与 loopback 验证只覆盖协议和协调行为；目标 OA 的应用实际 TTL、共享凭据跨机器轮换、人员权限和 live 探针依赖 E1/E2 及 M2.3–M2.5。

## 人员、待办与详情

| 操作 | 请求 | 响应与处理 |
| --- | --- | --- |
| `oa.person.resolve` | `POST /api/hrm/restful/queryEmployee`，body `ids[]` 或 `nameLikeList[]`、`current`、`pageSize`；按 ID 可用 `returnFieldList` 取 `id/username/department` | `message`、`data.{current,total,pageSize,data[]}`；人员标识只取原始 `id`，不取 `user_id` / `userId`，查询只验证记录存在 |
| `oa.workflow.todo` | `POST /api/workflow/list/paService/v1/getToDoWorkflowRequestList`，body `userid`、`pageNo`、`pageSize`；`userid` 为 OA 人员 ID 的 JSON 整数 | `message`、`data[]`；保留有界结果。xasp 的此响应模型无总数或下一页字段，满页可按页预算再请求一页，短页结束；不能凭满页声称一定还有记录 |
| `oa.workflow.detail` | `GET /api/fna/workflow/core/paService/v1/getWorkflowRequest`，query `userid`、`requestId` 字符串 | `message`、可随模板变化的 `data`。最小输出识别 `workflowBaseInfo` 或已核验顶层请求标识、流程、状态；`formData.dataDetails` 是细节来源，不能凭状态猜业务动作是否成功 |

按姓名查询时，完整读取服务端分页，拒绝页失败、总数漂移或返回数不足。对全量原始条目先按正式姓名 NFC 规范化、去首尾及折叠空白后做完全相等判断。必须恰好一个原始候选，再验证该候选 `id` 是合法非空十进制字符串、没有首尾空白，且全量原始结果中该 ID 不重复。拒绝拿相似姓名、A 用户名、材料姓名或表单字段选择操作者。按 ID 核验同样要求唯一且原始值一致。CLI 公开 ID 用字符串，线协议明确要求 JSON 数字时须无损发出十进制数值，不用普通 `Number` 对超长 ID 往返转换。

[人员查询源码](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/person/service.py:119) [人员字段依据](/Users/jiawy/Documents/xasp/xasp/skill/common/oa-shared/references/identity.md:12) [待办源码](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/service.py:1328) [详情源码](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/service.py:1623)

### 人员解析和操作者核验实现契约

`OaPersonResolver` 只依赖所属 OA 请求接口。公共调用固定每页 100 条，最多 100 页 / 10000 条；每页 current/pageSize 必须对应请求，total 为稳定的非负安全整数，返回条目数须等于该页应有数量。超限、缺页、总数漂移及中途错误均失败，不根据已读部分选择人员。姓名输入最多 256 个 Unicode 字符，规范化后完全相等；只返回 operatorId 和规范化姓名。

人员 ID 必须来自原始 JSON 字符串 id，是 1–128 位无前导零的正十进制数。数字类型（包括看似可安全转换的数字）、空白、符号、指数和其他人员字段都不作为候选 ID；相同 ID 在其他原始结果中出现也拒绝。人员调用使用严格数字解析，超长数字响应直接报协议错误，避免通用传输的无损转字符串行为掩盖原始字段类型。

`withOaClient` 固定一次 profile/config/env，复用会话管理器；未登录、应用错绑、缺秘密和 uncertain 均在人员 HTTP 前失败。每页取票及全部分页共享总预算，不自动重新登录。认证明确错误与退出 11 不被同步发生的取消覆盖；本地 deadline 为退出 5，调用方取消为 130。

`verifyOaOperator` 只按配置 operatorId 重新请求人员，成功保存 profile binding、应用 scope、连接上下文摘要、operatorId、起止时间及来源，不保存姓名和通讯录。上下文包含连接标签、环境、规范化目标、tenant、corpId 和凭据引用；改变引用也要求重新核验。核验窗口从请求前开始计时，固定 15 分钟；时钟倒退或响应超过窗口拒绝。

核验尝试在网络请求前以事务记录。一个 binding 只有最新、active 的尝试可提交和读取成功记录，起点必须严格晚于上一轮；同毫秒并发请求会明确拒绝。开始新核验立即使旧成功证据不可用，较新失败不会让迟到旧响应恢复证据。退出与尝试失效在同一事务内提交，保留时间戳防止相同应用重登后旧结果复活；保留的历史元数据不作为当前证明。不同 profile 分别保存证据，共享应用 token 不共享操作者核验。

已核验操作者的 query/json helper 在注入前复查期限、绑定和当前成功证据。query 注入字符串 userid，JSON 注入 Node 24 原始十进制数字 token，支持 19 位及更长 ID，不经过 Number。普通顶层 userid/userId/operatorId 等覆盖字段被拒绝；业务使用这两个 helper，后续待办/详情仍归 M2.4。show 的 verified 只是本地历史证据，verify 与注入均不证明使用者拥有员工权限，权限标志固定 false。

| 错误 | 退出码 | 含义 |
| --- | --- | --- |
| `OA_PERSON_INPUT_INVALID` / `OA_OPERATOR_REQUIRED` / `OA_OPERATOR_INVALID` / `OA_OPERATOR_OVERRIDE` | 2 | 选择器或显式操作者无效、试图覆盖 |
| `OA_OPERATOR_NOT_FOUND` / `OA_OPERATOR_AMBIGUOUS` / `OA_OPERATOR_ID_INVALID` | 6 | 无精确候选、多个原始候选或非法/重复 ID |
| `OA_PERSON_RESPONSE_INVALID` / `OA_PERSON_PAGINATION_INCOMPLETE` / `OA_PERSON_LIMIT_EXCEEDED` | 6 | 响应结构、分页完整性或边界失败 |
| `OA_IDENTITY_CLOCK_INVALID` / `OA_IDENTITY_CHANGED` / `OA_OPERATOR_VERIFICATION_STALE` | 6 | 时间、并发/会话变更或注入前证据已失效 |
| `IDENTITY_COMMIT_UNCERTAIN` | 11 | 本地尝试/成功记录保存结果不明，先读取 show |

以上保证由公开模块测试、原生 SQLite、多连接竞争及合成本机 HTTP 证明。目标 OA 的具体人员分页结构和人员级访问控制仍需 M2.5 真实验证。

### 待办与详情实现契约

`OaWorkflowReader` 统一处理两项读取的分页、投影、重试和操作者检查。CLI 与 API 都经 `withOaClient` 及 `verifyOaOperator`，每次调用重新人员核验；人员响应按原始字符串 ID 严格解析，两类业务响应均开启数字原文保留，申请单 ID 只接受规范十进制表示，避免小数 ID 或金额内容在 JSON.parse 时舍入。人员核验的本地保存不作为业务读取成功。

待办页码为 1–1000000，默认 1；pageSize 为 1–100，默认 20。默认读一页；all=true 时最多 100 页 / 10000 条，默认 10 页 / 1000 条。每页 data 必须是数组且长度不超过请求页大小；requestId 必须可无损解释为正十进制 ID，名称和 workflowId 可缺失，不回传其他字段。同一次聚合重复 ID 拒绝，不能去重后隐瞒页漂移。单页和聚合遇短页/空页才证明自然结束。条数预算只在完整页间生效，容不下完整下一页即停止；累计投影最多 8 MiB。

2026-11-07 目标生产环境核实：待办行使用 `requestid`、`requestname`、`workflowid` 全小写字段。读取器同时兼容此前源码 fixture 的 `requestId`、`requestName`、`workflowId`，公开输出保持后者。只接受这三组已核实的别名；双方非空值须经各自类型/精度/长度校验后相等，冲突或任一非法值拒绝，不能用另一字段掩盖非法响应。缺少合法 request ID 仍失败。详情继续使用已有 camelCase 契约，未扩大为任意大小写兼容。

游标是有界 base64url 编码，包含版本、下一页、页大小和固定 profile/连接上下文/应用 scope/operator 的指纹；这些信息必须匹配当前调用。它只提供受条件约束的页位置，不授予权限、不承诺实时列表的快照一致性。游标与显式页码/页大小互斥。分页结果为 data.pagination；满页停止返回 hasMore=null、truncated=true、nextCursor，短页结束返回 false/false/null。网络失败和超时整体报错，不返回成功的部分列表。

详情只从 `data.workflowBaseInfo.requestId` 或 `data.requestId` 取申请单 ID；同时存在必须一致，且等于请求值，不取 message 内追踪字段。workflowId、requestName、flowStatus 只取 workflowBaseInfo；缺失不猜测。flowStatus 为对象时读取 code/desc，为字符串时作为 label，数值 0 不丢失。formData 未提供 dataDetails 时输出 null，显式空数组保留空数组。

每个详情字段投影 detailId、rowId、fieldId、subFormId、dataIndex、dataKey、title、type、content、options；支持 formField.id/fieldId、subForm.id/subFormId，双来源冲突拒绝。字段/选项 ID 可为供应商字符串编码；申请单/流程 ID 则为正十进制。dataIndex 只能为正安全整数或空；没有子表索引时不自行推导。dataOptions 支持数组及旧单对象，投影 optionId/content/type。content 只支持字符串、布尔、空或数值原文，拒绝嵌套对象/数组；每份详情最多 1000 字段，每字段 1000 选项，文本 content 最多 65536 个 UTF-16 单元，其他展示文本最多 4096。未知字段不透传，单响应仍受 4 MiB 上限约束。这是读取投影，未复制旧项目的报销合计和主子表业务诊断。

只有业务待办 POST 和详情 GET 属于可自动重试读取；每页/详情最多 3 次（初始加两次），默认等待至少 100/200ms。内部 `OaHttpError` 只携带 transient 和可选 retryAfterMs，不含 URL/正文；网络连接/断流及 HTTP 408/429/500/502/503/504 可重试，重定向、其他 HTTP、认证、权限、业务/协议、取消和 uncertain 不重试。Retry-After 合法秒数或 HTTP-date 与默认等待取较大值，不截短；剩余预算不足以等待则返回当前错误。传输本身不重试，认证和人员查询不被此策略重放。公共 retryable 仍保守为 false，调用方不得据此恢复写入。

读取错误另包括 `OA_WORKFLOW_INPUT_INVALID` / `OA_WORKFLOW_CURSOR_INVALID`（2），`OA_WORKFLOW_RESPONSE_INVALID` / `OA_WORKFLOW_PAGE_CHANGED` / `OA_WORKFLOW_LIMIT_EXCEEDED`（6）。HTTP 401/403 与非零业务码保持既有映射；成功标记下的空/不明详情是协议错误，目标不存在的真实码仍待联调。

### 显式 live 诊断

`doctor --provider oa --live` / `api call system.doctor` 的 live=true 分支复用同一 workflow 编排：固定一次连接/环境/应用/操作者，稳定已登录应用会话，重新人员核验，再执行 todo({page:1,pageSize:1})。没有第二次读取默认 profile 或重新加载连接来拼报告，不另外实现认证、HTTP 或重试。成功后的 checkedAt 和作用域信息来自这次调用；人员核验提交不代表探针成功。

探针只取待办首页，空页和一条合法记录均通过；满页的未知 hasMore 不导致再翻页。最多 3 次安全业务尝试，人员及认证仍保持原策略，所有步骤/等待共用总预算。报告丢弃读取数据，保留操作、页参数、检查时间和固定 profile/connection/operatorId；remoteVerified=true 限于此次读取，permissionsVerified 恒为 false。没有把成功写成持久的“系统健康”状态，auth status 的 remoteVerified 仍为 false。

无 live 时保持本地诊断，不读秘密/状态库或发送请求。未登录、缺少操作者、人员异常、权限拒绝、错误结构、超时/取消及 uncertain 均原样失败，不把诊断失败降级成成功。补充的修复提示使用固定安全文本；不会为了探测而换协议、换操作者、自动重新登录或读取更多业务内容。

### Workflow 字段元数据

`oa workflow fields --form-id ID` / `oa.workflow.fields` 通过 `GET /workflow/v2/getFieldById` 读取指定表单，query 为 `id`、已核验的 `userid`、运行时注入的 token。只接受顶层 `formFields` 数组，返回 `fieldId/dataKey/componentKey/required/deleted/subFormId`；最多 1000 项，无自动重试。主表 subFormId=-1，子表为正十进制 ID，缺失为 null；布尔字段只接受布尔或缺失。无损保留原始数字 ID，拒绝重复或非法 ID，不从嵌套 `subForm` 猜测。

2026-11-07 生产 A/B 诊断确认：该端点返回 `text/json;charset=UTF-8`，`Accept: application/json` 导致 -10 / Could not find acceptable representation；按源 httpx 默认改为 `Accept: */*` 后取得 49 个字段。中央传输采用此兼容头，仍只解析有界 UTF-8 JSON，不接受 HTML、非 JSON 或任意响应透传。见 [实际诊断](../reports/m3-form-diagnostic.json)。字段查询成功不等于 workflow/form 绑定、写权限或业务完整性验证。

### 搜索可发起流程

`oa workflow search --keyword '差旅' [--limit N] [--resolve-form]` 对应只读操作 `oa.workflow.search`。输入为 `{keyword,limit?,resolveForm?}`，默认返回 20 条，最多 50 条。默认输出为 `{items,matchCount,truncated}`。每条候选包含流程全名、精确 `workflowId` 及列表直接提供的 `formId`。列表未提供表单 ID 时，该值为 `null`。

OA 的“前台可发起工作流列表”（文档 `840714112855539713`）提供个人和团队范围。CLI 在返回的流程名称上做 Unicode NFKC、去首尾空白、不区分大小写的子串匹配。按流程 ID 去重，完整名称匹配优先，其余按归一化全名和 ID 排序。不同 ID 的同名候选分别保留。`matchCount` 是截断前的匹配总数，零匹配返回空列表。OA 的“所有流程列表”（文档 `840713485857423360`）中 `condition.requestname` 搜索申请单标题，供实例查询使用。

启用 `--resolve-form` 或传入 `resolveForm:true` 时，唯一命中会在同一次调用里返回 `resolvedForm`，结构与 `oa.workflow.form.resolve` 相同。解析沿用本次已核验的操作者与可发起列表，复用下文的表单证据及冲突规则。列表或配置已有表单 ID 时，正常会话的读取链包含一次人员核验、两个范围的流程列表和一次字段读取。表单绑定无法核实时返回解析错误。

零条或多条匹配时，`resolvedForm` 为 `null`，回执仍保留搜索结果。唯一性的判定使用截断前的 `matchCount`，即使 `--limit 1` 也要由用户从多条候选中选定。选定后按 `workflowId` 调用 `oa workflow resolve-form`，比较多个流程时分别按 ID 读取。省略 `resolveForm` 或传入 `false` 时只返回原搜索结果。

### 解析流程表单

`oa workflow resolve-form --workflow-name NAME` 或 `oa workflow resolve-form --workflow-id ID` 对应只读操作 `oa.workflow.form.resolve`。输入为 `{workflowName}` 或 `{workflowId}`，返回 `{workflowId,workflowName,formId,source,fields}`，其中 `workflowName` 可为空，`fields` 使用同一字段元数据契约。所有步骤固定同一 OA 连接和已核验操作者。

1. 通过 `POST /api/workflow/list/paService/v1/getCreateWorkflowList` 查询 OA 原生个人及团队可发起流程，`wfpCode` 分别为 `0` 和 `1`，均设 `loadOfsFlow:0`。按完整名称或精确 ID 选定唯一流程。
2. 使用可发起列表直接返回的 `formId`，校验与已配置的绑定一致，来源为 `creatable-list`。列表未给出表单 ID 时，使用当前连接里该流程唯一一致的绑定，来源为 `configured`。部署方负责核实配置中的流程与表单对应关系。
3. 前两种来源缺失时，通过 `POST /api/workflow/list/paService/v1/getAllWorkflowRequestList` 有界读取当前操作者可见的申请单。`condition.workflowid` 固定为所选流程 ID，`condition.resultDataParam` 请求 `needSpecificWfIds:true` 和 `needFormId:true`。详情需确认申请单、流程和表单的对应关系，来源为 `workflow-instance`。零条可见记录时仍需明确的绑定证据。
4. 使用同一个 `OaFormReader` 读取 `formId` 的实时字段定义。遇到流程歧义、证据冲突或无法核实表单时返回错误。草稿写入另按对应操作核验授权、模板及字段约束。

## 独立流程草稿操作

在当前 OA 连接的 `workflowDrafts` 声明已获准的模板。每项配置由 `workflowId`、`formId`、`bindingRequestId` 和 `fields:[{fieldId,componentKey}]` 组成。连接最多配置 32 个流程，每流程最多 32 个字段。ID 为精确十进制字符串。当前允许主表 `Text` 和 `DateComponent`，字段值分别使用非空文本和 `YYYY-MM-DD`。部署方按实际 OA 权限维护这些配置。

`oa workflow draft create` 对应 `oa.workflow.draft.create`。输入为 `{workflowId,fields:[{fieldId,value}]}`，可先用 `operations prepare`，再以原输入及执行 ID `operations apply --yes`。校验绑定参考单据、操作者、全部已配置字段及现场必填项后，固定使用 `isnextflow=0` 保存。只发送明确指定的字段值，遇到不支持的必填控件时停止。`--dry-run` 核对输入结构，实时模板以 prepare 和 apply 的校验为准。

返回 `requestId`、`draftSaved`、`readback`、`execution`、`dryRun` 和 `oaContext`。`live` 核对同一 OA 单据的 ID、流程、表单、操作者、草稿状态及已写入值。同键已有成功记录返回 `cached`。派发后结果未决时沿原执行查状态和回读，未知单号的执行保留未决。该能力支持两个不同模拟表单的同一入口验证，真实 OA 验收见里程碑。

`oa workflow form fill`（`oa.workflow.form.fill`）更新已有可编辑草稿的主表文本或日期。输入 `{workflowId,requestId,fields:[{fieldId,expected,value}]}`，`expected:null` 匹配已读回的空值。操作复核绑定、草稿属主、字段类型及原值，向 `saveFormData` 提交指定字段，再回读同一单据核对目标值和其余已读字段。丢回执时可按原执行和单据 ID 只读回查。上游无已核实的条件写入保证，同一单据需安排一个写入者。

### 普通出差申请草稿

`oa workflow travel-application draft` 对应 `oa.workflow.travel.application.draft`。启用时在目标 OA 连接配置 `travelApplication`，含 `workflowId:"1252645225185501195"`、`formId:"1252645220705984513"` 和该连接下经部署方核实且操作者有权读取的 `bindingRequestId`。这些 ID 均为十进制字符串。参考单只用于校验流程与表单关系。携程、产研院和差旅报销有各自模板。

输入为 `applicantName`、`applyDate`、`reason` 和 `entries`。每行需要 `startDate`、`endDate`、`headcount`、`destination`。日期采用 `YYYY-MM-DD`，行程按日期排序且互不重叠。出差天数由各行自然日（含起止日）相加。目的城市从现有 OA 城市目录精确匹配，可选 `itinerary` 记录行程和出发地。申请人与当前配置的已核验 OA 操作者须一致，申请部门和单位由 OA 组织接口取得。主表和行程均可按 OA 正式姓名填写 `companions`。经授权的支持 PDF 使用 `materials:[{path,sha256?}]`，MCP 调用时文件须位于宿主已配置的材料根。

| 用途 | OA 接口 |
| --- | --- |
| 绑定与保存回读 | GET `/api/fna/workflow/core/paService/v1/getWorkflowRequest`，按参考单或本次回执 ID 读取 |
| 实时字段 | GET `/workflow/v2/getFieldById`，按精确表单 ID 校验字段类型及归属 |
| 创建草稿 | POST `/api/workflow/core/paService/v1/doCreateRequest`，固定 `isnextflow:0`、`isNewFormData:true`、`isVerifyPer:1`，单次保存 `formData` 并要求 OA 核验发起权限 |

主表的人员、组织和明细目的城市使用 `dataOptions`。文本、日期及天数使用 `content`。明细子表 `1252645762056413187` 每行字段共用从 `1` 起的 `dataIndex`。返回 `draftSaved`、`requestId`、`readback`、`execution`、`dryRun` 和 `oaContext`，草稿状态及已写值验证通过后才返回 `readback:live`。确认、幂等、未决回查沿用上节契约。 [供应方新增流程 v1](http://192.168.70.15:20600/sp/opendoc/10.0.2606.01/zh_cn//840714220321120257)

部署前可用 `oa workflow form info --workflow-id 1252645225185501195` 核对流程关联的主表与明细表。张易的 `oa-test` 已通过这项只读核对。 [供应方流程关联表单文档](http://192.168.70.15:20600/sp/opendoc/10.0.2606.01/zh_cn//370433517147914240)

## 供应方 OpenAPI 只读补充

接口依据为 `a_kxy/interface` 中的 OA 文档。路径相对于 profile 的 OA OpenAPI 地址。认证、待办列表及按表单 ID 查字段沿用现有命令。文档中的 core 流程详情使用独立 operation，`oa workflow +detail` 沿用已验证的 FNA 接口及原输出。

| CLI | operation | 路径及行为 |
| --- | --- | --- |
| `oa workflow todo-count` | `oa.workflow.todo.count` | POST `/api/workflow/list/paService/v1/getToDoWorkflowRequestCount`，返回无损十进制 `count`。可传 `mergeShow`、`disturbDataType`，并按 `workflowId`、`requestName`、`requestIds` 筛选。数量来自服务端。 |
| `oa workflow request get` | `oa.workflow.request.get` | GET `/api/workflow/core/paService/v1/getWorkflowRequest`，核对返回单号并读取状态及表单。`includeLogs:true` 时返回当前单据的签字意见，`logLimit` 默认为 50，上限 100。默认省略签字意见。 |
| `oa workflow form info` | `oa.workflow.form.info` | POST `/api/workflow/pathdef/openapi/getFormInfo`，按精确 `workflowId` 获取关联主表、明细表和字段。业务 ID 按文档 JSON 示例作为字符串，传输层在请求体注入令牌。默认请求四段。提供 `need*Info` 开关时只请求设为 `true` 的段，其余段返回 `null`。适用于文档所述内部或 EB 表单。 |
| `oa file info` | `oa.file.info` | POST `/api/file/v2/common/file/queryFileInfo`，传明确的 `fileIds` 及可选 `module`。操作者和租户由当前连接固定，远程用户授权校验保持开启。输出区分返回的元数据和未返回的 ID。 |
| `oa file download` | `oa.file.download` | GET `/api/file/v2/common/download/{fileId}`，下载指定附件至显式绝对 `targetPath`。大小有上限，目标文件独占发布，返回实际字节数和 SHA-256。下载可经 CLI 或 `api call` 调用，本地落盘入口不向 MCP 开放。 |

除关联表单接口外，表中新增操作沿用 query 令牌。所有 OA 请求使用当前应用会话和已核验操作者。服务端拒绝、响应不一致或未完成下载均返回错误。草稿写入仍执行原绑定和授权校验。

## 独立上传操作

| 命令 | 操作 ID | 输入与回执 |
| --- | --- | --- |
| `oa file upload` | `oa.file.upload` | 一份绝对路径的普通 PDF，可提供 `sha256`。使用 `/api/file/v2/common/upload`，应用令牌在 query，`userid`、`module=document`、名称与文件在 multipart，`tenantKey` 在请求头。返回普通附件 `fileId` 回执。 |
| `oa invoice upload` | `oa.invoice.upload` | `{kind:"invoice",path,sha256}`，上传一份原始 PDF。使用 `/api/inc/file/v1/uploadFileSpilit`，应用令牌、`userid`、`ocr=1` 与文件在 multipart，`tenantKey` 在请求头。返回发票原件的 `fileId` 回执。 |
| `oa invoice recognize` | `oa.invoice.recognize` | `{path,sha256?}`，上传一份原始 PDF 并把同一回执交给 `POST /api/inc/biz/v1/ocr`。使用 `is_save=1,is_sync=1,operate_type=0,flag=13` 请求个人票面识别，可能消耗 OA 识别额度。 |

两条上传命令使用配置好的 OA 应用会话。调用前分别核验同一连接中绑定的 OA 操作者，`userid` 取 `queryEmployee.id`。OA 人员的 `user_id`、A 端账号标识和报销人分别属于不同字段。xasp 的网关身份到 OA 人员的绑定发生在调用前，上传请求只接收核验后的 OA 人员 ID。[xasp 发票 CLI](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/invoice.py:64) · [xasp 发票 SDK](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/invoice/service.py:53) · [xasp 身份绑定](/Users/jiawy/Documents/xasp/xasp/docs/reference/oa-mcp.md:11)

上传支持确认、幂等和账本回查。回执说明上传端点已确认 `fileId`，丢回执按未决处理。单独上传后的发票 `fileId` 仍需经过票据保存才有票据实体 `infoId`。当前完整报销使用 [单票保存契约](invoice-save.md) 接续发票原件与服务端识别结果，然后通过专栏操作关联草稿。

识别使用同一应用和已核验的 OA 操作者，无需报销单或模板绑定。直接运行需明确确认和稳定任务键。首次成功返回 `fileId`、原件 `sha256`、`facts:{number,date,buyer,totalAmount}` 和 `invoiceSaved:false`，核对单张成功回执并保留金额两位精度。预览 ID、上传中的 `ocrMap` 和完整上游正文留在调用内部。账本只保留执行及文件回执，重用原任务键或回查返回 `facts:null`，无需再次发送原件或识别请求。调用方须保留首次成功输出。超时、业务拒绝或响应歧义保持原执行未决并保留已取得的文件回执。识别结果可供报销 Workflow 核对票面，票夹保存与发票专栏关联仍分别执行。

## 当前首个模板与历史候选

用户在 2026-11-07 明确办理实际差旅报销并通过新华清 CLI 推进 M3，首个模板相应改为**差旅费报销**。源码候选 workflowId=`1279393955010846720`；目标实例的只读回查实际绑定 workflowId=`1302769933046546435`、formId=`1253299138274254854`，并取得 49 项字段元数据。dev.13 已实现普通 PDF 附件的不完整材料草稿及执行恢复接口，生产上传、创建与回查尚待验收，完整费用政策、OCR 和正式提交仍未完成。详细证据与边界见 [差旅契约](travel-expense.md)。旧候选不并行实现，源码 ID 和合成 fixture 不赋予 verifiedForWrite。

以下保留 M0 提取的往返居住地模板作为历史来源记录，其字段与 `hj=je+qtje` 公式不适用于当前差旅模板。

### 历史：往返居住地费用报销

M0 曾采用 xasp `oa home-travel check/draft` 对应的**往返居住地费用报销**作为源码基线。历史候选 `workflowId=1290510326722355255`、`formId=1253331513746121491`、`module=workflow`。它未取得目标写入核验，不能向当前差旅任务派发。不同环境的标识从已核验连接配置取得，样例模板 ID 不作为无条件默认值。

| 子步骤 | 线协议、关键字段 | 回查及效果 |
| --- | --- | --- |
| 申请人、部门和单位 | `GET /user/v3/get`，query `userid` 与 `access_token`；需要组织选项时 `POST /api/hrm/restful/queryOrg`，body `ids`、`containExtend`、`loadAllChilds`、`current`、`pageSize` | `user.department` 定位部门，查组织得到 `subcompanyid`，再取单位信息。始终核对已配置的操作者；`read`。M3 验证目标部署是否保留这些端点及字段 |
| 普通附件 | `POST /api/file/v2/common/upload`，query `access_token`，multipart `module=document`、`name`、`userid`、`file`；有 `tenantKey` 时作为 header | `data.fileid/name/extName` 归一成文件 ID、名称、扩展名；`upload` |
| 发票上传 | `POST /api/inc/file/v1/uploadFileSpilit`，multipart `access_token`、`userid`、`ocr=1`、`file`，header `tenantKey` | `data.id` 或可验证的 `data.ids`、`fileType`、`ocrMap`；空 ID 停止；`upload` |
| 保存型 OCR | `POST /api/inc/biz/v1/ocr`，JSON `access_token`、`userid`、`image_index`、`fileTypeStr`、`ocrMap`、`operate_type=0`、`is_save=0`、`flag`，header `tenantKey` | 验证 `data.infos[].ret` 与 `info.id`；金额、日期、买方来自结构化结果。`is_save=0` 会保存，属 `create`；`flag` 从已核验业务配置取得 |
| 创建完整草稿 | `POST /api/workflow/core/paService/v1/doCreateRequest`，query `access_token`，JSON `userid`、字符串 `workflowId`、`isnextflow=0`、`isNewFormData=true`、`formData` | `message.requestId`，随后只读详情回查。该调用已携带完整表单，不重复保存以免追加重复行；`create` |
| 修订既有草稿 | `POST /api/workflow/core/paService/v1/saveRequest`，query `access_token`，JSON `userid`、`requestId`、`isNewFormData`、`formData` | 只在已确认的目标草稿及修订范围内调用，字段版本、既有物理行和写后回查是 M3 门槛；`update` |
| 提交 | `POST /api/workflow/core/paService/v1/submitRequest`，query `access_token`，JSON `userid`、`requestId`、可选 `remark` | 单独授权，回查同一申请单及实际状态。响应成功但回查失败不能重发；`submit` |

模板字典完整列在 fixture。主表无 `dataIndex`，子表内以同一正整数 `dataIndex` 绑定一条逻辑行。人员、部门、单位、城市、发票和附件用 `dataOptions` 数组。城市 `optionId` 与完整 `content` 必须来自同一选项。xasp 当前通过本地城市目录解析，华清需用目标已核验的选项输入或目录处理，不提前开放城市业务命令。普通附件指向文件 ID，发票字段 `scfp` 指向 OCR 返回的发票信息 ID。文本、日期和金额用 `content`。申请日期 `YYYY-MM-DD`，模板出发/到达用 `YYYY-MM-DD HH`。金额用十进制定点计算并按已核验的两位小数规则编码，满足 `hj=je+qtje`、`bxze=sum(hj)`、发票 `fpje/sbje` 和付款 `fkje` 对应关系。操作者、申请人与被报销人分别建模，材料与 OCR 不改变操作者。目标系统对表单强制/可选项及草稿可保存状态的实际判断需重新验证。

回查比较同一对象、表单标识、关键字段、option ID、子表逻辑与物理行、总额及状态。上传、保存型 OCR、建草稿、修订和提交均应先记录步骤再发送。已发送但结果未知时保留已知的附件或申请单 ID，仅回查，不因当前请求缺 ID 就新建。源码示例中的状态 `6` 和 `1` 仅作为样例；真实目标应用对应的状态及允许迁移由 M3.1/M3.5 记录。

[表单字段](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md) [编码与闭环规则](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data.md) [上传和 OCR](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/invoice/service.py:54) [草稿写入和回查](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_flow.py:96)

## 外部验收边界

- **E1 / M2.5**。已获准的共享生产应用完成真实登录及单操作者读取链，详见里程碑及真实 OA 报告；不能据此推定跨机器轮换、第二操作者权限或业务写入已通过。xasp 的 `.env.example` 与 SDK 环境文件仍只作为来源参考。
- **E2 / M2.2–M2.5**。从 OA 侧提供两个可测试操作者及相互不可访问资源，验证应用能否被服务端约束、profile 错配拒绝、跨进程及跨机器 token 轮换。若同一广域凭据可跨人员，则受控运行条件是交付限制。
- **E3 / M3.1–M3.5**。目标环境字段和流程绑定已有只读证据；本轮用户要求先保存不完整材料草稿，生产写入结果仍需单独验收。完整费用事实、OCR `flag`、附件/发票策略、精度及正式提交状态继续按 M3 核实，不把草稿实现或已获授权当作完整报销验收。
- **E4/E5 / M5**。QCC 可用服务/工具/费用及 A 端测试会话/知识库 ACL 均待独立确认；OA fixture 不代表任一外部系统契约。基金同理留待 E6/M7。

### M3 发票只读来源补充

query/inspect 采用 xasp eaf64280a69e0f1889c44cb52d077faf045d7152，而非缺失这两个SDK方法的当前分支。版本化路径、字符串操作者、连接tenantKey及严格分页/逐项成功回执见 [票据读取契约](invoice-read.md)。tenantKey内部请求字段仅允许该两个POST+JSON路径，等待凭据前已快照；没有任意header或业务参数覆盖入口。生产空结果的 `{total:0}` 可据明确零总数归一空页，不把其他失败解释为空。
