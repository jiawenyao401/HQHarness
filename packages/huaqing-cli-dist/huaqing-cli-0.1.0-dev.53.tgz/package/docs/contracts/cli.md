# CLI 公共契约 v1

归属 M0.3 / M1。实现代码中的 operation 目录是已实现命令/schema 的来源，本文定义跨命令行为。业务计划见首批能力清单，未实现 operation 不注册可用命令。

## 输入与发现

- `commands list [--provider oa|agentos|qcc]` 和 `schema ID` 无需配置、凭据或网络，仅显示已实现能力；provider筛选保留所选provider与公共生命周期命令。未实现能力返回CAPABILITY_UNAVAILABLE，不返回示例业务数据。
- 通用调用为 `api call ID`。命令入口与 API 调用经过同一个 execute 和输入/输出 schema。
- `api.raw`只允许schema登记的六条OA只读路由，以 `{provider,method,path,input}`唯一匹配原operation，业务input复用其schema/身份/执行器。CLI的api raw可用三个路由flag加业务JSON，也可传完整wrapper；混用同名路由字段拒绝。未知路由UNSUPPORTED_ENDPOINT/6，写入或计费动作、绝对URL/认证header/token/操作者覆盖均不进入Raw许可集。
- `--input FILE`、`--input -`、`--json JSON` 互斥；一份 UTF-8 JSON 对象，允许 BOM，最大 8 MiB。命令位置参数与 JSON 中同名字段冲突时拒绝，不悄悄覆盖。
- `--config FILE` 优先，默认使用操作系统配置目录，可由 `HUAQING_CONFIG_HOME` 指定。`--profile` 优先于 `HUAQING_PROFILE` 和配置中的 defaultProfile，不猜测唯一 profile。
- stdin 等待受 `--timeout` 限制，范围 1–300000 毫秒，默认 30000。`--non-interactive` 不产生提示或登录弹窗。
- `--output FILE` 仅用于非metered读取，将成功data保存到新文件，stdout返回路径/字节/SHA-256；已有文件或符号链接拒绝覆盖。写入及可能计费查询在派发前拒绝该选项。普通路径相对cwd；输入文件须普通文件，流式输入用stdin。

## 输出

`--format json` 成功和失败均在 stdout 输出一份 envelope，stderr 只承载诊断，默认无诊断。envelope 固定为 schemaVersion、ok、operation、data、error、meta、warnings。meta 包含 requestId 和 status；error 包含 code、message、retryable，可附 hint。错误不回显原输入、原始 HTTP 内容、内部异常或秘密。

输入失败可附品牌化的 `error.details:{issues,truncated}`：最多20个问题，每个只含 schema 字段/有界索引组成的 path、固定 code 和 expected，排除实际值、未知属性名、原件路径及摘录。公开默认发票 schema 表达规范票号、日期、金额和 PDF 限制；一般材料检查仍可返回 needs-review。OA 错误另可附 `error.upstreamError:{code,stage}`，code 仅为可信数值业务码的字符串，stage 来自固定阶段枚举。执行恢复摘要可保留相同机器诊断；普通任意 details、上游消息和内部异常始终不透传。

成功 meta.status 为 complete，普通失败为 failed。配置已替换但持久化确认失败时返回 CONFIG_COMMIT_UNCERTAIN、status=uncertain、退出码 11，调用方先读取实际配置，不假定修改未发生。OA 会话结果或本地提交不明分别返回 AUTH_SESSION_UNCERTAIN / AUTH_COMMIT_UNCERTAIN，同样为退出码 11、status=uncertain，外部超时不覆盖这些结果。材料草稿的已派发失败返回 WRITE_EXECUTION_UNCERTAIN（11）及受控执行摘要，见下文。强制杀进程可能没有最终输出，认证与业务派发记录分别阻止盲目重放。

退出码：0 成功，2 输入/配置，3 凭据/认证，4 权限，5 网络/超时/限流，6 不可用能力或业务/协议错误，10 需要确认，11 部分完成/不确定，70 内部错误，130 受处理的取消。

## Harness 进程调用

随包提供 `examples/node-process.mjs` 和 POSIX `examples/shell-process.sh`，使用固定参数数组、JSON stdin 及非交互调用；完整用法与恢复步骤见 [进程接入指南](../harness-process.md)。Node Adapter 的返回值区分完整 CLI envelope 与启动/进程/输出协议问题，收集非零退出的 stdout、等待 stdin EOF/输出流结束并限制输入和两个输出流；不会在外围自动重试。

完整且与退出状态一致的成功或未决结果不能被调用方取消标记覆盖。受控取消为 130，强制终止可能缺少 envelope；后者不能解释为远端没有发生操作。未知 operation 的拒绝 envelope 使用 `operation="api.call"` 和 `CAPABILITY_UNAVAILABLE`（6），不回显未受信任的 operation ID。

`meta.requestId` 仅追踪本次调用，不是 OA 申请单 `data.requestId` 或业务执行 `executionId`。配置、认证和身份异常分别通过 profile.list/auth.status/oa.identity.show 核对；材料草稿退出 11 使用返回的 executionId 调用 operations.status，再按已知对象执行 operations.reconcile。实现及本机替身验证不替代生产写入和具体 Harness 的写入恢复验收。

## 身份与写入约束

配置只存凭据引用。OA 应用凭据与操作者独立，业务 userid 使用已核验的 OA 人员 ID。会话及写入状态作用域、幂等和 prepare/apply 规则以实施方案第 7–10 节为准。

`oa.invoice.materials.check` 是本地只读操作，接收 Harness 提取的材料事实。MCP 需配置文件根。旧报销命令继续使用同一实现。[材料事实契约](material-facts.md)

OA 连接可选 `allowPrivateHttp: boolean`，默认 false。true 仅允许标准点分 RFC1918 IPv4 的 HTTP 目标，配置校验和传输使用同一规则；公网、DNS、IPv6及非标准 IPv4 表示不因该标记获得 HTTP 许可。它是单连接部署参数，不是通用 --insecure 开关，不替代权限或 TLS。profile 的脱敏输出保留显式设置的标记；省略与 false 的核验上下文一致，标记变化使旧人员证明 stale，但不创建新的 OA 应用身份。省略/false 保留已有上下文与应用会话；显式启用该策略才引入新的核验上下文。

profile.use更新默认配置，auth.login/logout管理所选provider会话，oa.identity.verify更新本地核验，均不是OA审批业务写入。所有写入拒绝--output。差旅草稿、单票保存/验真、文本修订、完整财务与首提各有独立operation和统一执行记录，见[完整差旅](expense-complete.md)。MCP默认显式允许的只读集合，写入须启动allow-write，材料另须file-root，见[MCP契约](../mcp-stdio.md)。代码可用不等于目标环境已验收。

## Skills 命令

`skills list` / `skills export` 对应 `skills.list` / `skills.export`，与 api call 使用同一 schema 和执行器。list 离线返回随包版本及规范 Skills，OA 条目的 `operations` 列出该 Skill 负责的命令。export 接收规范 ID 或兼容选择器和显式目标目录，包含所选目录及声明依赖。OA 业务 Workflow 导出自动包含 `oa-workflow` 和其传递依赖。旧 `oa-approval` 选择器映射到 `oa-workflow`。返回的 `skill` 为调用者传入的选择器，`skills` 为实际导出的规范 ID。二者均不读业务配置、不读取凭据、不访问网络。

export 效果为 local-file-write，拒绝 --output；目标必须不存在，父目录已经存在，已有文件、目录或符号链接均不覆盖。它不写 Harness 全局配置，也不自动发现 Skills 安装位置。结果含实际导出文件及 SHA-256，调用方按 [Skills 指南](../skills.md) 加载与切换版本。参数及输出结构以 `schema skills.list` / `schema skills.export` 为准。

目标创建前取消返回 130；创建后中断返回 `SKILLS_EXPORT_PARTIAL`、退出码 11，保留目标内容，调用方先核对后选新目录重试。全部文件写入后取消不能抹掉成功；POSIX 目录持久化确认失败为 `SKILLS_EXPORT_COMMIT_UNCERTAIN`（11）。父目录解析为真实路径，导出结果返回 canonical targetDir；本地部分结果不触发 OA 写入，也不复用业务 executionId。

## OA 认证命令

唯一operation为auth.login/status/logout，CLI/API共用；可选provider为oa或agentos，省略仍为oa。同名CLI/JSON字段冲突拒绝。凭据仅由所选连接引用解析，不接受token、密码或操作者覆盖。以下OA应用共享语义只适用oa，A原生独立会话见[A契约](agentos.md)。

OA输出provider/profile/connection/status/accessExpiresAt/operatorId/remoteVerified/cleanupPending；A分支没有operatorId。status为logged-out/active/refresh-required/expired/authenticating/uncertain，毫秒时间或null。remoteVerified固定false，无token/摘要/版本引用；status不创建或迁移库、不访问网络/秘密，本地active不等于远端有效。

login 会复用同应用的有效缓存或串行刷新，明确登录可恢复 uncertain；自动取票不能恢复 uncertain、不能给已退出的 profile 自动登录。logout 只解绑当前 profile，最后一个绑定必须删除当前和待清理版本后才完成。AUTH_STORE_MISMATCH、AUTH_BINDING_CONFLICT、AUTH_SESSION_CHANGED 和 OA_LOGIN_REQUIRED 均明确失败，不静默选择其他应用或存储。认证写动作超时不标记可重试；明确的 OA 认证/权限/限流拒绝保留对应退出码，未决令牌仍不能自动重放。

## OA 人员与核验命令

`oa person resolve` 对应 `oa.person.resolve`，输入恰好一个 `id` 或 `name`；支持目录投影的 `--id` / `--name` 以及通用 JSON 输入。同字段来自多个入口仍拒绝。输出只有 `{operatorId,name}`；全量分页无法完成或候选不唯一时返回错误，不输出部分人员结果，不修改 profile 或核验证据。输入不是用于切换操作者的参数。

`oa identity show/verify` 对应 `oa.identity.show/verify`，输入均为空对象。show 不读取秘密、不联网、不创建或迁移数据库。verify 只能核验选定连接的显式 operatorId，需要已登录应用，效果为 `read` + `local-state-write`，没有配置写入或审批写入。

两者输出 provider、profile、connection、operatorId、verificationStatus、verifiedAt、expiresAt、source、permissionsVerified。verificationStatus 为 not-configured / unverified / verified / expired / stale；时间为整数毫秒或 null，source 为 `oa.queryEmployee.id` 或 null，permissionsVerified 固定 false。verified 只表示本地保存的记录核验仍在 15 分钟窗口内，不代表当前使用者的权限。配置/作用域不一致为 stale；最新核验尚未成功或退出后为 unverified。

保存核验尝试或成功记录结果不明返回 `IDENTITY_COMMIT_UNCERTAIN`，退出 11、status=uncertain，先 show 再决定是否重新核验。较新核验、退出或会话变更导致条件保存失败返回 `OA_IDENTITY_CHANGED`（6）。明确成功提交后，不以尾部超时改写已知结果。人员/身份错误详见 [OA 契约](oa.md)；应用取票的明确错误和 uncertain 保持原语义。

## 本地与 live 诊断

唯一 operation 为 `system.doctor`，CLI 为 `doctor`。输入只允许可选 provider（当前仅 oa）和 boolean live；省略 live 或显式 false 均保持旧本地行为和旧输出字段，即 version、node、paths、configuration、profiles、remoteVerified=false。即使指定 provider=oa，也不会读取秘密、状态库或远端。配置不存在仍成功报告 configuration=missing；配置无效保留错误。

只有 live=true 才运行 OA 探针，省略 provider 时默认 OA。命令中的 --live 是无值开关，通用 JSON 必须为原生布尔；不接受 page、pageSize、userid、token 等覆盖参数。live 失败不得回退成本地成功或 remoteVerified=false 的成功报告，错误/退出码沿用各步骤，尤其 uncertain=11。已有修复 hint 保留；常见 OA 失败可补固定安全提示，不回显上游正文。

live 成功为独立的封闭输出：version、node、provider=oa、profile、connection、operatorId、remoteVerified=true、permissionsVerified=false、probe。probe 固定 operation=oa.workflow.todo、page=1、pageSize=1，checkedAt 为成功后的非负整数毫秒时间戳。输出不包含本地 profiles/paths，不混入人员姓名、业务条目/计数/游标。默认本地与 live 两种 schema 以 remoteVerified 区分；调用方不能把一次成功推断为系统整体健康或员工权限已认证。

两种形式都支持 --output；live 复用公共会话/核验/读取执行，可更新本地认证及核验元数据，远端仅做本次人员及待办读取。所有步骤在同一配置快照和总预算内完成。默认 doctor 的离线性质不因新增入口改变。

## OA 待办与详情命令

`oa workflow +todo` / `+detail` 对应 `oa.workflow.todo/detail`，与 api call 共用 schema、执行器及结果。命令参数名由目录属性的 camelCase 投影为 kebab-case；integer 参数严格解析为整数，boolean 使用无值开关，JSON 输入仍要求原生 number/boolean，字符串 ID 保持字符串。公开参数、类型和上下限以离线 schema 为准。

待办输入 page、pageSize、all、maxPages、maxItems、cursor；默认单页 20 条，all 默认为 false。maxPages/maxItems 仅允许 all=true 时提供，cursor 与 page/pageSize 互斥。输出 items 只含 requestId、requestName、workflowId，缺失的可选名称/流程为 null；pagination 位于 data 内，字段为 page、pageSize、pagesRead、hasMore、nextCursor、truncated。hasMore=false 表示遇到短页/空页，null 表示尚未确认；不根据满页返回 true。truncated=true 表示有续查位置且未确认自然结束，包括默认的一页查询。条数上限只在完整页之间执行；超时、取消和后续页错误整体失败，data=null，不把局部结果当成成功。

详情输入仅 requestId（1–128 位正十进制字符串）。输出 requestId、workflowId、requestName、status.{code,label}、formData；缺失可选值为 null。formData 非 null 时仅含 dataDetails，字段/选项采用目录中的封闭投影，所有 ID 为字符串，数值 content 保留原文本为字符串。原始状态不推导业务动作。返回申请单与请求不一致、无法识别、已知字段结构错误均为 `OA_WORKFLOW_RESPONSE_INVALID`（6）；没有未经验证的 not-found 映射。

两操作效果均为 read，可用 --output；内部先稳定应用会话，再重新核验人员并保存本地证明，证明的提交不代表业务读取完成，不抹掉后续超时/失败。每次业务尝试前及响应后核对证明，输入不允许 userid/operatorId/token 覆盖。总预算包含配置、秘密、认证、人员、分页、重试等待和响应读取。

## 验收映射

| 契约 | 可复现检查 |
| --- | --- |
| 无账号离线发现，未实现能力拒绝 | tests/cli.test.ts 的 discovery/schema/unimplemented 用例 |
| 参数错误/帮助/版本均为单份 JSON | tests/cli.test.ts 的 parser/help 用例 |
| stdin、BOM、大小/编码和超时 | tests/cli.test.ts、tests/io.test.ts |
| 无 shell Harness、EOF、取消/超时/未决结果、流上限与故障清理 | tests/harness-process.test.ts |
| POSIX shell、含空格参数路径、JSON stdin 与退出码透传 | tests/harness-shell.test.ts |
| 安装制品包含且可运行两个 Harness 示例与指南 | scripts/package-smoke.ts |
| MCP 命令启动、离线帮助及 stdin/stdout 协议隔离 | tests/mcp-command.test.ts |
| MCP 同目录工具、允许集合、配置快照、封闭 schema 与未决结果 | tests/mcp-operations.test.ts |
| MCP 两代协议、真实进程取消/EOF、字节边界、OA 结果等价 | tests/mcp-stdio.test.ts |
| 独立安装包的现代/旧版 MCP 发现与调用 | scripts/mcp-installed-smoke.mjs、scripts/package-smoke.ts |
| Skills 离线发现、CLI/API 等价及输入冲突、写入前拒绝输出重定向 | tests/skills-cli.test.ts |
| Skills 依赖闭包、文件摘要、不覆盖、并发与中断结果 | tests/skills-bundle.test.ts |
| Skills 命令、frontmatter、依赖和相对链接完整性 | npm run skills:check、tests/skills-references.test.ts |
| 实际安装包的 Skills 发现、导出与文件摘要一致 | scripts/skills-installed-smoke.mjs、scripts/package-smoke.ts |
| profile 选择、引用脱敏与原子更新 | tests/config.test.ts、tests/cli.test.ts |
| 凭据加密、隔离和不可用状态 | tests/credentials.test.ts |
| 本机持久化、并发、失联执行记录 | tests/state.test.ts |
| 引用解析、存储选择与权限 | tests/credential-sources.test.ts |
| 应用协调、迁移、只读状态和清理队列 | tests/auth-state.test.ts、tests/oa-session.test.ts |
| 认证命令与同应用跨进程认证 | tests/cli-auth.test.ts、tests/oa-session-cli.test.ts |
| 唯一人员、完整分页及 ID 精度 | tests/oa-person.test.ts、tests/oa-identity.test.ts |
| 核验持久化、并发及退出失效 | tests/identity-state.test.ts、tests/oa-identity.test.ts |
| 人员命令/API 等价、隔离与本机 HTTP | tests/cli-identity.test.ts、tests/oa-identity-cli.test.ts |
| 待办分页/游标、详情投影及读取重试 | tests/oa-workflow.test.ts、tests/oa-transport.test.ts |
| 待办/详情命令和 API、身份隔离、本机 HTTP | tests/cli-workflow.test.ts、tests/oa-workflow-cli.test.ts |
| doctor 默认离线、live 显式选择及输出分支 | tests/cli-doctor.test.ts |
| live 最小待办、配置固定、错误/未决/超时及无业务内容 | tests/oa-doctor-cli.test.ts |
| 目录和 handler 一致、快照无漂移 | npm run catalog:check |

真实 OA 接入、分页与表单状态的验收保留在 M2/M3，不能由本阶段离线测试替代。

## 不完整草稿执行（dev.13）

`--yes`映射confirm=true，由共同execute校验。稳定键direct写入必填，prepare可省略后按executionId apply。六个受控写operation均支持离线dry-run，不打开材料/配置/状态或联网。status键定位只消费其查找键，不将它解释为写入授权；其他非写命令拒绝写execution选项，MCP serve同样拒绝。

prepare 的参数为目标 operation（oa.expense.draft、oa.expense.invoice.save 或 oa.expense.amend）加原业务输入；apply/reconcile 为 executionId 加同一业务输入。三类业务输入由互斥 schema 校验，执行器核对记录所属 operation，不能跨类型套用。CLI 与 api.call 对应同一 schema，业务输入不能覆盖确认、凭据、操作者或流程。配置 travelExpense 绑定当前流程、固定差旅表单和一个明确可读的参考 requestId；业务数据中的姓名只用于 OA 正式姓名唯一解析，不映射 A 账号。

本地执行作用域绑定配置真实路径、profile/connection、OA 应用及操作者。operationVersion 为本次模板/人员计划指纹，inputHash 另外绑定领域契约版本、规范输入、材料内容/文件名/路径及模板配置；不保存正文、银行账号或凭据。CAS 认领只允许未过期 prepared，已派发不自动重开。每件附件先落步骤再上传；一次 create 直接带全部已知字段，不再重复 save。上传与创建的合法成功响应不因迟到取消丢失，记录 ID 后停止后续步骤。

未知写结果退出 11，data 仅为专用 RecoveryError 的白名单执行摘要；普通错误 data 仍为 null，只有上述封闭诊断可投影。status 不联网或读取凭据。reconcile 仅对记录中已知 create ID 回查，校验同一单据、workflow/form、人员、全部发送字段/行/附件和待提交状态；无法唯一确定时保持未决。不接受人工输入另一个 requestId 去覆盖执行记录，不猜最近单据，不重传附件。

执行摘要仅含 executionId、operation、operationVersion、status、expiresAt、objectId，以及每步的 stepId/status/objectId/errorCode；数据库遗留 dispatching 对外呈 uncertain。无派发的本地失败按原错误返回，记录为 failed 后不能续写。已知草稿的 reconcile 远端读取失败也返回 11 并保留摘要；成功回查返回 readback=live，但不把历史 uncertain 改为 succeeded。

状态库 schema 4 的新执行保存 recovery binding，按配置 realpath、profile、连接上下文和 operatorId 派生。logout 后仍可用相同上下文和精确 executionId 离线读取；不按时间、姓名或最近单据猜测。该绑定不含应用身份，仅用于本地查询；apply、幂等及远端 reconcile 仍使用完整原应用作用域。旧schema1/2/3/4需先备份再经可写入口事务升级至5；历史执行的空 recovery binding 不补造，不能通过新查询入口读取。

成功 data.businessComplete 固定 false。readback=live 表示本次回查，cached 表示重复相同执行返回先前成功记录，并非新鲜 OA 状态。未输入的财务字段可仅识别明确数值控件的服务器零默认，返回 serverDefaultsPresent；不会将零升级为已确认金额。完整保存/首提及MCP写工具沿各自契约；跨state root去重、未知创建ID自动查回和断点续写未作保证。

### dev.14 草稿文本与旧执行兼容

新计划领域版本为 `travel-incomplete-v2`，出差事由采用日期范围加原始事由，不重复声明。成品事由与目的地不超过 100 UTF-16 单元；新计划 dry-run/prepare/apply 在取票和远端派发前检查，超长返回输入错误，不截断。共享原输入 schema 保留以支持旧执行恢复。

执行查找按原始规范输入/材料/绑定/已存计划指纹分别校验 v2 或 v1 摘要，不能给旧记录重写摘要。v1 prepared 的 apply/direct 在 claim 前拒绝；v1 uncertain 不重放。只有已识别 v1 的 reconcile 使用旧 renderer 和严格重复声明兼容：返回必须恰为旧事由前 100 UTF-16 单元、被截部分全部属于固定重复声明、原始事实前缀完整且独立特殊说明精确一致，其他字段/状态仍严格。`repeatedNoticeTruncated` 在实际回查时为布尔值，未回查/缓存为 null；不改变原 uncertain 历史。

### OA 票据读取

`oa.invoice.query`、`oa.invoice.inspect` 与 `oa.invoice.match` 经同一执行器处理。前两项读票据原始状态，`oa invoice +match` 则核对四项票面事实及当前可见池的占用与删除状态，返回唯一可复用实体或完整查询未命中。独立人员核验、字符串 userid、tenantKey 和响应覆盖约束见[票据读取契约](invoice-read.md)。MCP 将这三项作为写入流程配套读取，启动时使用 `--allow-write`。三个 operation 都只读取 OA。

### OA 单票保存

`oa.expense.invoice.save` 接收单张原件事实和明确目标草稿，按 [票据保存契约](invoice-save.md) 上传、直接保存一次与双重回读。prepare 只读，apply 重新核对目标；已知保存 ID 的 reconcile 不再要求草稿仍可编辑。多回执以独立子步骤原子落账；上游失败、取消或事实不符保留可信已知 ID，退出11后禁止自动重放。成功中的 linkedToDraft 固定 false，未知资格和未验真状态不据入库成功改变。v2 新协议不消费旧 v1 prepared，旧成功缓存和按原输入的只读恢复保留。

执行摘要支持可选 failureCode，以 schema 的闭合枚举区分已知故障；旧执行继续显示其原类别。该字段来自现有本地 error_code，该诊断字段不改变旧历史，当前schema5的资源保护另有职责，不包含远端原文或任意错误码。1686 已添加、1705 重复及2059策略拒绝分别分类，均不能用失败响应里的 ID 证明入库或所有权。

### 按稳定键查询执行

operations.status接受executionId，或互斥的 `{operation,idempotencyKey}`；CLI第二种用 `operations status --operation OP --idempotency-key KEY`，MCP放在business input。status只读当前profile/连接/操作者的恢复绑定，不解析凭据、取票、联网或迁移；同一恢复绑定跨旧应用历史匹配多条时拒绝歧义，不选最新或首条。没有匹配不新建记录。稳定键是可保存在私有状态库的业务标识，不能包含秘密；结果不回显键值。

### OA 既有草稿修订

`oa.expense.amend` 使用 [修订契约](expense-amend.md)，只接受事由/目的地的精确旧值和新值，绑定完整业务投影并发送稀疏patch。dry-run离线；prepare只读；apply认领后重读旧值、元数据和全部业务字段，保存后完整核对。执行正文不入库，reconcile逆置expected重建原计划hash。此operation的目标单号在输入中已经明确，故保存丢响应、主ID为null时仍可按原输入只读核实；要求原保存步骤确已派发，不把prepared伪装成完成。不新增、删除单据或提交；MCP写工具须显式allow-write。`amendmentObserved`不宣称当前流程仍为草稿，完整报销状态仍按实际详情判断。
