# 企查查独立 MCP 客户端契约

本连接直接访问已获准使用的供应商 Streamable HTTP MCP，复用现有的固定入口。它不依赖 OA 会话、A 登录、旧 xasp 运行时或管理网关。CLI 和华清自身的 stdio MCP 通过同一 operation 执行器调用本 provider；外部服务目录不会自动变成华清的公开工具。

## 配置与工具批准

Profile 的 `connections.qcc` 指向 `provider:"qcc"` 连接。连接字段为 `environment`、完整 MCP `baseUrl`、`tokenRef`、可选 `allowPrivateHttp` 和可选 `tools`。`tokenRef` 使用现有 env/file/keyring 引用解析器，引用该明确 endpoint 已获授权的 bearer：官方连接使用其官方凭据，代理连接使用 proxy bearer，上游 API Key 留在代理服务端。不同入口的凭据不自动互换。HTTPS 是默认要求；本机测试或显式允许的规范 RFC1918 私网 HTTP 沿用公共连接规则。地址不得含用户信息、查询参数或片段。

首次配置可省略 `tools`，此时仅能发现目录。`qcc.tools.list` 通过真实 MCP 握手读取完整有界远端目录，只返回下列两个业务角色的已核实候选名称、原始 `inputSchema`、`schemaSha256`、`approved`，并报告缺失项和远端工具总数；不保存配置、不批准新工具、不调用付费业务工具。

| 业务 operation | 官方公司 MCP 原名 | 既有聚合代理名称 |
| --- | --- | --- |
| `qcc.company.search` | `get_company_by_query` | `company_get_company_by_query` |
| `qcc.company.detail` | `get_company_registration_info` | `company_get_company_registration_info` |

官方 CLI 的公司入口为 `https://agent.qcc.com/mcp/company/stream`；既有聚合代理由其连接配置提供完整地址。连接地址始终显式配置，不自动拼接模块或改道。两类名称来自官方实际目录及既有聚合器源码，不接受其他别名。若同一目录两类名称并存，最多返回四项，各项保留实际名称并分别显示批准状态，不选择优先项。`missing` 为兼容既有输出，使用表中聚合代理名称表示缺失的业务角色；只有该角色的两种候选都不存在时才列出，不表示另一个命名空间必须存在。

显式批准后，配置 `tools.search`、`tools.detail`，每项包括该角色的一个准确名称、发现的完整 `inputSchema` 及其 `schemaSha256`。两项均须存在，可分别来自两类名称。schema 必须来自获准服务的真实目录，不能用代码测试 fixture 充当供应商契约。哈希是对 schema JSON 递归按对象键排序、保持数组顺序及 JSON 数值/字符串表示后的 SHA256；实现复用公共 canonical JSON 哈希函数，拒绝非 JSON、getter、循环与不安全整数。它不是对格式化 JSON 文本文件求哈希。

每次业务调用先检查配置 schema 自身与批准哈希相符，再读取实际完整目录并按批准的准确名称比对当前 schema 哈希。该名称缺失或变化时，即使同角色另一名称拥有相同 schema，也拒绝执行。重复名称、循环分页、页数/数量超限或目录不完整同样拒绝；重新发现不会自动更新批准。业务参数和完整配置在单次调用中固定，等待目录期间不能更换输入。

## 输入、结果与费用

搜索与详情的业务输入都是封闭对象 `{"arguments":{...}}`；arguments 按已批准的真实供应商 schema 验证，不猜测 `query` 到 `searchKey` 的转换，不补未知分页参数。schema 支持本地 JSON 引用，拒绝外部 `$ref`/`$dynamicRef`/`$recursiveRef`/`$id`、保留原型键、异步校验、超深或超大结构；不下载 schema。JSON Schema 的 format 按注解处理，不增加未声明的自定义业务规则。输入不允许提供 endpoint、token、任意工具名或连接覆盖。

成功收到 MCP tool result 后返回：

```json
{
  "tool": "company_get_company_registration_info",
  "queriedAt": "本地收到响应的 UTC 时间",
  "requestId": "本地生成的关联标识",
  "quotaMayBeConsumed": true,
  "businessStatus": "unclassified",
  "result": {"content": [], "isError": false}
}
```

此处只展示响应结构，不是供应商成功样本。`queriedAt` 不是供应商数据的更新时间，`requestId` 不是供应商回执。HTTP/MCP 传输完成不代表工商、权限、额度或其他供应商业务成功。保留 MCP 原始 `isError`、content、structuredContent 等字段；即使 `isError:false`，仍不把未知业务内容归为“已核验”或“零风险”。`isError:true` 同样保留在原始结果中，`businessStatus` 仍为未分类。结果有界返回，不写入日志或证据文件，不自动读取资源 URL、图片或音频 URL。意外回显的 bearer 值会被抹除。

业务调用可能消耗额度或收费，不提供假定单价。没有实际供应商契约前，不声明免费或估算金额。客户端禁止自动重试业务查询；授权失败、权限不足、限流及重定向也不触发刷新、OAuth 发现、扩大权限或重发。401→退出3，403→退出4，429/其他 HTTP 拒绝→退出5；429 的数字 Retry-After 可作为信息返回，`retryable` 仍为 false。

目录中的两个业务 operation 标记 `metered:true`，仍属于 read，不要求 OA 写确认。CLI/MCP 外层的超时不会把已收到的查询结果覆盖成可重试失败；SDK 因调用方取消而抑制回复时，调用方仍不能据取消断言未消费额度。

在实际tools/call派发后发生取消、超时、断流或无法确认响应时，返回 `QCC_QUERY_UNCERTAIN`、退出11、`retryable:false`，hint明确本次可能消耗额度。公开失败envelope的data为null，保留meta.requestId及原输入；它是CLI追踪ID，不是供应商回执，也不伪造result或额度数据。不得因缺少结果或账单尚未出现而重发。源码没有可用的供应商查询对账接口，不伪造reconcile能力。派发前取消为130；派发前超时/连接问题为普通读错误。

`mcp.servers.list`只读列出配置qcc连接；`mcp.tools.list --server qcc`及`mcp.tools.call --server qcc --tool 准确名称`复用同一provider。通用调用要求请求名称与当前配置批准名称完全一致，同角色另一名称也不能替代。仅支持上述两角色的四个已知名称及原arguments，不扩大到其他服务或远端目录。两种企业入口均标记metered，已知返回不会被迟到外层deadline改写，TIMEOUT不标可重试。CLI拒绝这些入口的--output，在派发前避免已付费结果之后另一次文件发布失败；结果通过stdout返回。

## 协议与资源边界

使用官方 `@modelcontextprotocol/client` 精确2.4.0，与现有 server/core2.4.0 对齐；现有 server 包不导出 outbound Client 或 StreamableHTTPClientTransport，因此需要这一项新增运行依赖。没有新增常驻服务、Python 或插件平台。

兼容已核实的2025 initialize协议、stateless JSON响应和 SSE结果，SDK 处理协议 ID、错误、会话与取消。官方 SDK 的自动分页存在兼容性提前终止分支，因此通过它的公开 request API 逐页验证完整性。每次调用至多64页、2000工具、单响应8MiB、全部响应16MiB、单 schema256KiB/32层、单请求1MiB；整个生命周期共享默认30秒预算，最大300秒。所有网络请求限制为同一个配置 endpoint，禁止跟随重定向；只发送静态 bearer，不配置 OAuth/刷新回调；关闭 SSE 重连，传输层再次观察到 business POST 时拒绝派发。SDK lifecycle 在所有结果上关闭。

实际目录取证只证明连接、名称及 schema，不证明企业业务查询、直接连接授权范围、计费/额度或权限/限流行为。M5 的真实业务验收需要这些独立证据；具体状态与证据统一记录在开发里程碑。
