# 往返居住地费用报销：独立模板与草稿契约

用户于 2026-11-08 明确授权将往返居住地费用报销作为第二个正式模板，保留现有差旅模板。本文件服务于 M3.1–M3.4 的本批实现：`oa.expense.home.draft`，CLI `oa expense home-travel draft`，独立连接配置 `homeTravelExpense`。当前动作仅保存不完整材料草稿及只读恢复；完整财务、票据关联与提交没有因此取得生产验收或执行授权。开发和验收状态以[里程碑](../development-milestones.md)为准。

下文分开记录源码事实与新华清本批契约。新增[去敏草稿 fixture](../../tests/fixtures/oa/home-travel-draft.json)为合成样例，`liveCapture=false`、`candidateOnly=true`、`verifiedForWrite=false`、`samplesDispatchable=false`。原[完整报销候选 fixture](../../tests/fixtures/oa/home-travel-expense.json)保持原件，SHA-256 `abb1eeb2e2773b0dc7c076a002afec488f4d2035364242b19564c63baa72b9ae`；不能将其虚构人员、城市、账户、单号或状态当成生产事实。

## 来源和复核范围

固定一手源码为本机 xasp 提交 `e5ece871ea88789e4dc5779931810244beb117bb`。本研究进程仅读取源码、业务 reference、去敏 fixture 及同批只读报告，核对文件摘要；没有执行旧 CLI、访问网络、读取凭据或用户记忆，也没有上传、创建、修订或提交真实单据。同批任务取得的真实只读证据在下文单独引用。新华清独立实现协议，不依赖旧 Python、托管 wrapper、私有 Harness 文件或旧任务缓存。

| 第一方来源 | SHA-256 | 证据用途 |
| --- | --- | --- |
| [home_travel.py](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:29) | `a8d3353c2e11c58bafe249251ec4b7672c0c6594c810ffaaf8da0b4d9b1442f2` | workflow/form、字段、逐票行、金额与草稿执行入口 |
| [CLI reference](/Users/jiawy/Documents/xasp/xasp/docs/reference/cli/home-travel.md:1) | `6a826bb34d88d99575476654c6dee1c689a0124841e91801eae3dfc9b8b45736` | check/draft 和历史恢复语义 |
| [业务 Skill](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:19) | `ae19045ccc8ebcf9709aa7da44310f616c63bcef93d5a93d040324f1a5a7e5b3` | 人员、材料来源、居住地、未决与仅草稿边界 |
| [字段 schema](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md:1) | `b5f1b52129e09bcb97ac14ce08f36ea225bd9e2c6bf9aad098f1e4347e8d08d8` | 29 字段、3 子表、类型与编码 |
| [场景字段规则](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data.md:5) | `cc98284b209945a35bf2526eacab83af2e1bfa9f4dca0d6e5fde5dbcf384bdcf` | 地点、票据行、费用与收款闭环 |
| [政策 reference](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/policy.md:5) | `44c8f9b663a07f4bb670b02959ffacd41867b5c5a952c1b6ffa2540edccce2b7` | 交通等级、实报金额与附加费；不代表现行政策已核实 |
| [共享草稿流程](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_flow.py:96) | `e637c47cdaf892f4ad12993d6e1fa2232252b8d23ddc5031c7d596b83d868a87` | 一次创建、已知 ID 回读、未决时禁止重建 |
| [共享人员与金额 helper](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/travel_expense.py:510) | `c884adbafecb5228990dc110246601916ecb4e0f84c75004223655b808fd0062` | 独立被报销人 option、精确十进制候选 |
| [字段回读校验](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_verification.py:50) | `cf992b8ecf6f39659b49c1b9aeaf4ae6016e3b987494bc56dedd521c812f711c` | 表单、行键、文本及 option ID 比较 |
| [缺口归类](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/intake_normalize.py:55) | `64744626edc99b0e400567aaf8542b3ffb46307b142afe72865a68ac5aeda7c0` | 到达时间/城市软缺口与旧文档差异 |
| [城市静态目录](/Users/jiawy/Documents/xasp/xasp/skill/common/oa-shared/references/city-options.json:1) | `71c6ecf1773f32cab7303de8acb4718b3458e8f9eba7dbbab4d07c7c03b2e73d` | 1 国家、34 省级地区、369 市级记录；国家/省/市 ID 与 label 配对 |
| [城市读取器](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/cities.py:55) | `6f0a9aacd3c59b0bfa28cc02907708b8efa0e463e5e110dfcad8ed5b20fc6262` | 静态目录校验、本地唯一匹配；不依赖 OA 或 SDK |

## 模板、字段与环境绑定

源码一致给出 `workflowId=1290510326722355255`、`formId=1253331513746121491`、`formName=往返居住地费用报销`、`module=workflow`。它们是独立 home 模板候选，不能通过替换现有差旅配置中的两个 ID 激活。当前连接须显式配置 `homeTravelExpense` 的 workflow、form 和参考单据，实时读取证明这一组合；来源没有真实参考单据 ID。历史 fixture 的 `9007199254740993` 是合成值，不可用于绑定。[源码常量](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:29)、[字段 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md:3)、[原 fixture](../../tests/fixtures/oa/home-travel-expense.json:350)

以下字段表完全按源码 schema 记录。`type` 与 `componentKey` 分列，保留 `SubCompany/Subcompany`、`EInvoice/EinvoiceComponent` 等实际拼写。源码没有提供远端 `required`、删除状态、最大长度、目标版本或实际写权限；它们必须由当前环境核实，不能由 fixture 补造。主表不带 `dataIndex`，各子表行号分别从 1 开始。[字段 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md:16)

| 主表名称 | dataKey | fieldId | type / componentKey | 编码 |
| --- | --- | --- | --- | --- |
| 申请人 | `sqr` | `1253331513746121564` | Employee / Employee | dataOptions |
| 申请单位 | `sqdw` | `1261546892588630022` | SubCompany / Subcompany | dataOptions |
| 申请部门 | `sqbm` | `1253331513746121565` | Department / Department | dataOptions |
| 申请日期 | `sqrq` | `1253331513746121566` | Date / DateComponent | content |
| 报销事由 | `ccsy` | `1253331513746121567` | Text / Text | content |
| 报销总额 | `bxze` | `1253331513746121570` | Money / Money | content |
| 附件 | `fj` | `1253331513746121569` | File / FileComponent | dataOptions |

往返居住地报销明细 `subFormId=1253331513746121563`。[字段 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md:30)

| 明细名称 | dataKey | fieldId | type / componentKey | 编码 |
| --- | --- | --- | --- | --- |
| 报销人 | `ccr` | `1253331513746121586` | Employee / Employee | dataOptions |
| 出发时间 | `cfsj` | `1253331513746121571` | Date / DateComponent | content |
| 出发地点 | `cfdd` | `1253331513746121572` | City / City | dataOptions |
| 到达时间 | `ddsj` | `1253331513746121574` | Date / DateComponent | content |
| 居住地 | `jzd` | `1290510429809958913` | City / City | dataOptions |
| 交通工具 | `jtgj` | `1253331513746121575` | Text / Text | content |
| 单据张数 | `djzs` | `1253331513746121578` | Number / NumberComponent | content |
| 金额 | `je` | `1253331513746121579` | Money / Money | content |
| 其他金额 | `qtje` | `1253331513746121583` | Money / Money | content |
| 合计 | `hj` | `1253331513746121584` | Money / Money | content |
| 附件 | `fj` | `1273440683525996545` | File / FileComponent | dataOptions |
| 特殊说明 | `tssm` | `1253331513746121585` | Text / Text | content |

发票明细 `subFormId=1261538251147984898`。[字段 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md:51)

| 发票名称 | dataKey | fieldId | type / componentKey | 编码 |
| --- | --- | --- | --- | --- |
| 上传发票 | `scfp` | `1261538251147984899` | EInvoice / EinvoiceComponent | dataOptions |
| 购买方 | `gmf` | `1298216086608240642` | Text / Text | content |
| 发票日期 | `fprq` | `1261538251147984900` | Date / DateComponent | content |
| 发票金额 | `fpje` | `1261538251147984901` | Money / Money | content |
| 实报金额 | `sbje` | `1271869477153382401` | Money / Money | content |
| 费用说明 | `fysm` | `1261538324246315034` | Text / Text | content |

收款账户信息 `subFormId=1266387299376275465`，单人候选的四字段统一用 `dataIndex=1`。[字段 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/schema.md:66)

| 收款名称 | dataKey | fieldId | type / componentKey | 编码 |
| --- | --- | --- | --- | --- |
| 收款人 | `skr` | `1266387299376275466` | Text / Text | content |
| 开户银行 | `khyx` | `1266387299376275467` | Text / Text | content |
| 银行账号 | `yxzh` | `1266387299376275468` | Text / Text | content |
| 付款金额 | `fkje` | `1266387299376275469` | Money / Money | content |

2026-11-08 同批任务已取得目标环境真实字段：[只读报告](../reports/home-live-contract.json)返回 **37 字段**，全部 `required=false/deleted=false`，包含上表 29 项及下列 8 项。主表/子表附件实际组件为 `FileComponent`。这份真实字段证据优先于源码的字段缺省，不能因为旧 schema 未列住宿或到达地点，就声称目标表单不支持它们。

| 真实新增 dataKey | fieldId | componentKey | 所属 |
| --- | --- | --- | --- |
| `khyx` | `1253332209522434053` | Text | 主表 |
| `yxzh` | `1253332209522434054` | Text | 主表 |
| `skzhxx` | `1253331513746121568` | Text | 主表 |
| `yscdzt` | `1257760286414651393` | Text | 主表 |
| `yskm` | `1257760286414651394` | RelateBrowser | 主表 |
| `fjml` | `1310208958164459525` | Select | 主表 |
| `zsf` | `1253331513746121582` | Money | 往返明细 `1253331513746121563` |
| `dddd` | `1253331513746121573` | City | 往返明细 `1253331513746121563` |

住宿费 `zsf` 和到达地点 `dddd` 因而是已观察到的真实字段。本批支持将明确的 `destination` City 映射为 `dddd`，不从居住地推导；住宿费的完整业务映射、金额规则与费用资格仍未核实，本批不写。主表银行字段与收款子表有重名 dataKey，不能只按 dataKey 选择字段或把主表账户代替收款子表。逐日补贴、市内交通费、差旅天数和主表目的地没有出现在本次 37 字段中，不能借用差旅 fieldId。参考草稿 `1335418565068587009` 读取返回 `OA_BUSINESS_ERROR`，不能证明其身份、状态、归属或 workflow/form 绑定，也不据此修改、删除或复用；本报告 `productionWrites=0`。[只读证据](../reports/home-live-contract.json)

OA OpenDoc `840712785760100353` 将 `POST /workflow/v2/queryFlowInfoByFlowIds` 的 `flowIds` 定义为审批数据 ID，最多 10 个。官方示例将 `access_token`、`userid`、`flowIds` 放在 query，响应实例标识为 `flowInfos[].flowRequest.id`。旧 XASP SDK 的 `query_flow_info_by_ids` 将 `flowIds` 放在 JSON，方法参数只有 ID 列表。SDK 分页变体同样使用 `flowIds`。要由流程定义 ID 核实所属表单，按 [OA 解析契约](oa.md#解析流程表单) 取得对应证据。[SDK 方法](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/service.py:1693)、[SDK 路径](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/_constants.py:89)、[SDK 响应模型](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/models.py:1102)

同批探针以流程定义 ID 调用该接口，返回 `OA_BUSINESS_ERROR`，未取得绑定证明。[实际摘要](../reports/home-flow-definition-summary.json) 查找本操作者已有实例可用旧 SDK 的只读 `my_list` 和 `all_list`。SDK 对两者使用同一请求模型 `{userid,pageNo,pageSize,formIds?,workflowIds?}`，分别调用 `POST /api/workflow/list/paService/v1/getMyWorkflowRequestList` 和 `POST /api/workflow/list/paService/v1/getAllWorkflowRequestList`。当前 OpenDoc 对所有流程列表的精确过滤条件见 [OA 解析契约](oa.md#解析流程表单)。往返居住地写入仍按本契约核实当前操作者可读的参考单。[SDK 列表方法](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/service.py:1328)、[SDK 请求及响应](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/models.py:891)、[SDK 路径](/Users/jiawy/Documents/xasp/xasp/packages/sdk/src/oa_sdk/api/workflow/_constants.py:61)

随后同操作者的本人发起列表实际返回 29 条记录，精确筛选得到两条 home 流程且创建人与配置操作者一致，选定只读参考 `1331996639875678240`。native CLI 公开投影先只确认 workflowId；同一受信客户端继续读取原始详情，最终确认 returnedRequestId=`1331996639875678240`、workflowId=`1290510326722355255`、nested `form.id=1253331513746121491` 且 `operatorOwnerMatches=true`，取得独立 home workflow/form 组合的真实绑定证明。该参考只证明关系，不复制业务内容、不替代当前身份，也不证明新建/修订权限或完整财务写入。[列表与公开投影](../reports/home-reference-summary.json)、[最终绑定证明](../reports/home-binding-proof.json)

## 人员、居住地与往返性质

连接中的 OA `operatorId` 是本次所有请求的 `userid`，按当前新华清身份契约核验 `queryEmployee.id`。申请人 `sqr` 为该明确操作者；被报销人 `ccr` 为本次独立解析的真实报销人。两者不相同仍不改变操作人、申请人或申请组织。人员零匹配、多匹配、无权限或原始候选不完整均阻止派发，不能为建单而替换成另一人。来源 helper 要求被报销人姓名精确、option ID 非空无首尾空白且 `type=user`，明确禁止回退申请人；新华清继续采用自己的严格人员 ID 与完整分页规则。[现有 OA 身份契约](oa.md)、[来源 helper](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/travel_expense.py:510)、[业务身份边界](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:35)

申请单位 `sqdw` 和部门 `sqbm` 跟随已核验申请人组织，不从发票抬头、报销人、A 用户名或实例所有者推导。收款人 `skr` 是另一业务角色，不是身份认证依据；银行账号始终作为字符串，必须来自当前获准来源，不能借用操作者或其他报销人账户。旧脚本有 profile/历史收款回忆流程，新 CLI 不读取或依赖旧缓存。[来源上下文检查](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:115)、[业务输入](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:21)、[旧缓存行为](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_flow.py:177)

`cfdd` 是该张车票或行程材料明确记载的出发地点；`jzd` 是被报销人的居住地，不能把票据终点自动当成居住地。当前明确的居住地优先；历史值只有在单独授权、同报销人、同业务、有效记录和可靠归属均核实后才可作为来源，参考单号本身不提供这种证明。City 的 `optionId` 与完整 `content` 必须来自同一精确匹配记录，歧义或未知保留未决。[地点 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data.md:5)、[最新 Skill](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:37)

“往返”是本次明确选择的业务类别，源码没有单独的往返性质枚举，也不要求机械凑成去程和返程两行。完整业务候选按每张真实车票一行，多票分别成行；没有返程事实就不补返程。`jzd` 不是“到达地点”字段，不因去程/返程而自动交换它与 `cfdd`。目标环境实际另有 `dddd` 到达地点，旧 builder 没有映射它；本批也不将用户的居住地暗写为到达地点。[行生成规则](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data.md:15)、[不得补返程](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:39)、[真实字段](../reports/home-live-contract.json)

已有 requestId、参考单据、上传 ID 和发票 ID 均不能用于替代上述身份核验。参考单只证明当前 workflow/form 组合；恢复只接受本执行已经记账的对象，不把另一会话或“最近一张”草稿认成本次成功，不自动修订或删除未知归属单据。[历史草稿边界](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:15)

## City 候选目录与语义校验

一手城市源是有限静态资产 `city-options.json`，121,310 字节，`schemaVersion=1/source=administrative_area.sql`；reference 说明来自 `all_teams` 的中国有效数据，本次核对为 1 国家、34 省级地区和 369 市级记录。完整形状为 `countryId/countryName/provinces[]`，省记录含 `provinceName/provinceId/optionId/content/cities[]`，市记录含 `cityName/cityId/optionId/content/cityLevelId/cityLevelName`。`cityLevelId` 不是提交城市 ID，城市等级也不能用来断定住宿政策。[城市 owner](/Users/jiawy/Documents/xasp/xasp/skill/common/oa-shared/references/city-option-resolution.md:5)、[目录原件](/Users/jiawy/Documents/xasp/xasp/skill/common/oa-shared/references/city-options.json:1)

新华清将这份非秘密数据固定为[自有包资产](../../src/providers/oa/assets/home-city-options.json)，保持上述 SHA-256，使用自己的 TypeScript [读取及匹配实现](../../src/providers/oa/home-city.ts)，无需旧 Python 或工作区。必要的 `oa.city.search` 是本地候选查询；精确匹配返回同一记录的 ID/label，零个或多个候选不自动取第一条。home 输入即使已经给出三段数字和 label，也必须通过固定目录的精确 pair 核验；只通过正则不能证明城市身份，ID/label 错配、未知项、目录缺失或损坏均停止该事实编码。候选版本/目录摘要进入计划，准备后不得换目录悄然派发。

静态目录不证明当前 profile 的 OA 目录完全相同，也不证明本人的居住地；目标环境真实有效实例与静态候选冲突时停止使用冲突候选，保留实际回读证据。xasp `cities.py` 虽有 `/api/bcw/administrativeArea/cascade` 常量，但 `fetch_rows` 明确丢弃 client 后直接加载本地数据；当前 SDK 未给出该路由的已核实 method、请求或响应契约。本批不把未使用常量变成网络 API，也不在目录错误时联网兜底。[实际读取路径](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/cities.py:107)、[目录冲突边界](/Users/jiawy/Documents/xasp/xasp/skill/common/oa-shared/references/city-option-resolution.md:35)

## 金额、时间与有效材料

完整 home 费用候选中的 Money 使用以元计的十进制金额字符串，两位小数；新华清内部核算应使用整数分，向 OA 输出元字符串。源码本身没有币种字段，不能从 Money 类型推断外币换算。旧 29 字段规则为每行 `hj=je+qtje`，无其他金额时 `qtje` 省略并按零计算；`bxze=sum(hj)`，单收款行 `fkje=bxze`。实测 37 字段新增住宿费 `zsf`，旧公式没有解释它如何参与合计，不能将这个旧公式当成当前完整财务契约，也不能无依据把住宿并入其他金额。本批 incomplete 不输出这些财务字段，服务器零默认值只报告为默认存在，不能当成已核实的零报销事实。[公共金额单位](/Users/jiawy/Documents/xasp/xasp/skill/common/oa-expense-common/references/expense-evidence.md:5)、[旧金额 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/policy.md:21)、[来源十进制组装](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:157)、[实际字段](../reports/home-live-contract.json)

票面 `fpje` 与可报 `sbje` 分开。政策 reference 候选允许用户明确给出小于票面金额的实报金额，不允许按席别、比例或当前票价回推；同票行 `je` 应对应已经确定的 `sbje`。退改费用只有可靠关联原车票时才计入该行 `qtje` 且增加单据数，不能再重复计入 `je`；无法关联时的独立费用行仍需真实事实及专属费用资格。完整源码中的“单行单发票即用票面 amount 填 je”和“未给 sbje 默认票面”不等于当前人员已获准报销该金额。[政策 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/policy.md:12)、[旧默认行为](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:123)

申请日期是明确业务输入，不能自动使用执行当天。完整行程向 OA 写 `YYYY-MM-DD HH`；必须保留输入/材料中的原始分钟证据及向小时投影的规则，`departure<=arrival`，没有真实到达时间不估算。home CLI reference、当前 Skill、旧 form-data 文档对此有冲突，见下表。日期范围或申请单只证明材料中的计划/陈述，不证明行程已执行、实际返程、票据归属或实付费用。[输入语义](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:23)、[时间校验](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:63)

Harness 使用自身 PDF/视觉能力读取原件，CLI 复用[材料事实契约](material-facts.md)核对摘要、日期、精确金额、来源证据及重复，不新增 OCR/模型服务。当前材料草稿只将受控 PDF 原件作为普通附件：发票 PDF 的 `kind=invoice` 仍是材料分类，不会因此生成 OA 发票实体、验真或报销关联。`FileComponent` 写本次上传回执的 fileId；`EinvoiceComponent` 只能写真实 OA 发票实体 infoId，不能使用模型 JSON、旧 ID 或普通 fileId。[来源附件与发票分流](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:187)、[发票字段 owner](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data.md:21)

无票费用、账户、城市、时间、交通等级、金额或材料归属缺失时保留明确 missingFacts，不填假值、不把缺口改成零、不自动改为另一人或另一类报销。身份、权限、真正必填字段、重复票或未知创建结果不能通过“仅草稿”绕过。只有实时 schema 确实允许省略的业务缺项才进入 incomplete 草稿，结果固定 `businessComplete=false`。[未决边界](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:40)

## 本批不完整草稿的确定边界

公开输入必须显式带 `expenseType:"home-travel"` 与 `mode:"incomplete"`，CLI、目录/API、MCP 共用同一个 schema/执行器；拒绝其他 expenseType、额外身份/环境/requestId/formData/任意远端 ID 字段，不能静默转成差旅输入。事实、原件和人员来自本次获准任务，绑定与 `userid` 来自连接，不能由业务 JSON 覆盖。City option 是明确的业务值，其合法形状另受下面的 schema 限制。完整逐票财务规则在上文保留为后续能力门槛，不把候选规则或 fixture 当成已实现完整报销。

本批输入字段为 `reimburseeName/applicationDate/reason/trips/materials`。每个 `trips` 对象只接收本次已知的 `origin/destination/residence/departureTime/arrivalTime/transport/documentCount/note`，未知值省略；City 使用同一城市记录的 `{optionId,content}`，`optionId` 是国家、省份、城市三级 ID 的逗号连接，不能使用“省、市、县”或行政区划代码替代。`materials` 使用 `{path,kind:"invoice"|"support"}`，不接收来源未定的金额、银行账号、住宿或补贴字段。日期、小时与非负整数单据数在本地校验；明确提供的 0 张保留为已提供事实，缺失不猜成 1，此入口不宣称已完成票据张数/费用闭环。输入不增加另一套身份选择或旧任务 ID 回填入口。[来源 City 示例](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data-examples.md:32)

本批基础字段为主表 `sqr/sqrq/ccsy/fj`、每条实际输入行的 `ccr/tssm`；明确提供的 `origin/destination/residence/departureTime/arrivalTime/transport/documentCount` 分别映射该行 `cfdd/dddd/jzd/cfsj/ddsj/jtgj/djzs`，并完整回查。13 种可写事实映射、全部 37 个已知字段的类型/归属及全体字段的可省略/未删除条件在 prepare 和首次 apply 派发前核对。`tssm` 是子表特殊说明，并非主表目的地；每行保留用户 note、缺少的行程字段清单与固定声明“金额、票据资格及收款信息待核实；不完整草稿，不得提交”，成品不超过 100 UTF-16 单元，超长派发前拒绝，不能依赖 OA 截断。`ccr` 保留明确被报销人；稀疏行不表示车票、材料归属和完整财务已核实。申请单位/部门没有核实不填，未提供的行程事实、全部金额、账户与发票明细省略，不用假时间、假城市或零金额填空。

执行计划绑定独立操作名、版本、home workflow/form/参考单、全部实时元数据指纹、操作者、独立报销人、规范化输入和不可变原件摘要；不能消费现有差旅的 prepared/uncertain 执行。`prepare` 只读校验；`apply --yes` 或业务命令 `--yes --idempotency-key` 才可派发。一次上传每件材料后，仅一次 `doCreateRequest(isnextflow=0,isNewFormData=true)` 携带明确的目标字段，取得可信 requestId 后仅回查，不追加一次相同全量 save。SOURCE 已指出重发完整新数据可能追加重复行。[统一写入契约](cli.md)、[来源单次创建](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_flow.py:106)

同对象回查须核对 request/workflow/form、申请人/被报销人、全部目标文本和选项、附件集合、各实际输入行以及待提交状态；存在 SUBMIT 日志、额外有效金额/银行/票据/交通行、身份或字段差异时不宣称草稿已正确保存。SOURCE 的 `bxze` 非空检查仅适用旧完整草稿，不适用于本批故意省略金额的材料草稿；新华清必须按本次真实字段集合完整比较。数值零服务器默认可以单独标记，但不能接受有实际业务含义的额外数据。[旧 verify_saved](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_flow.py:47)、[旧 verify_form](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_verification.py:50)

每次写派发前先持久化步骤。重复同键同摘要只返回已有状态，输入/原件/绑定变化冲突；已派发未决、断线、取消、缺 requestId 或回查失败不重放上传/创建，不换键建第二张。已知 requestId 从执行记录恢复只读核查，无法定位时如实返回 uncertain；不扫描“最近草稿”猜对象。status/reconcile 复用现有 SQLite 与恢复绑定，记录摘要和可信对象 ID，不保存银行账户、票据正文或 token。本批不提供 home 草稿修订、完整财务关联或提交动作。[来源不确定保护](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/draft_flow.py:106)、[统一恢复契约](cli.md)

## 源码冲突与待核实事实

| 已查到的来源事实 | 新华清处理与真实验收门槛 |
| --- | --- |
| 旧 form-data.md 允许估算到达小时并不标预估；当前 Skill 禁止航空猜时，CLI reference 要求真实时间，home_travel.py 将缺到达时间记 soft gap | 不估算到达时间；本批省略具体行程并保留待补。铁路时刻核验不是本批新增服务。 |
| home_travel.py 主表申请日期直接 date.today()，Skill 明确要求 applicationDate 来源 | 新输入显式提供日期，不继承运行当天默认；真实输入与回查逐字比较。 |
| 旧 helper Decimal.quantize 没有显式舍入模式；其他金额只在 extra>0 时写但总额包含 extra；零值 reportedAmount 通过 or 回退票面 | 完整财务进入开发前必须冻结负数、超精度、零实报和舍入规则；当前全部省略，不复制这些默认。 |
| policy.md 要求行 je 使用 sbje，旧 home builder 在一票一行缺额时用 amount | 材料金额不等于可报金额，不自动从票面补实报；仍需真实费用决策、分配和整数分闭环。 |
| 源 schema 共29字段；目标环境实测37字段，新增住宿费、到达地点及6个主表字段，全部可省略且未删除 | 真实字段优先；本批只写13种受支持事实映射中的已知值，包括明确到达地点；住宿与其他完整财务仍待契约。不用只读验证代替生产写入验收。 |
| fixture 中状态 code=6/desc=待提交、人员90001/90002、request9007199254740993皆为合成 | 状态映射、可编辑性、申请人身份与真实落库必须分别取得实际证据，不能用合成状态开闸。 |
| 源 schema 包含往返明细附件1273440683525996545，home_travel.py FIELDS/组装器并未写该字段 | 本批附件只写已选主表 fj；不凭 schema 存在就新增逐行附件。 |
| jzd 历史 reference 写“当前用户”，最新 Skill 写“同报销人” | 不在本批自动读取历史；后续获准使用历史时必须核实同被报销人和同业务，不能取操作者居住地。 |

对应冲突证据：[旧场景时间规则](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/references/form-data.md:17)、[当前 Skill](/Users/jiawy/Documents/xasp/xasp/skill/oa/oa-home-travel-expense/SKILL.md:26)、[home 缺口与默认](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/home_travel.py:95)、[共享金额格式](/Users/jiawy/Documents/xasp/xasp/apps/cli/src/oa_cli/travel_expense.py:91)、[原 fixture](../../tests/fixtures/oa/home-travel-expense.json:350)。

本次研究和合成 fixture 不能给出真实材料、居住地、收款、票据资格或生产写能力结论。统一验收须分别记录代码实现、合成故障/幂等验证、目标环境只读元数据以及获准的真实草稿保存/回查证据；真实提交继续在当前授权之外。
