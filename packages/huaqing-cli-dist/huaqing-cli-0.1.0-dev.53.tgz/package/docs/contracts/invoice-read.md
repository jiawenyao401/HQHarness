# OA 发票只读契约

本切片服务 M3.1/M3.2，将原件票号关联到当前操作者可见的 OA 票据实体与原始状态。查询、查看和匹配共用命令目录和执行器。

`huaqing oa invoice +match --input FILE` 对应 `oa.invoice.match`。输入为 `number`、`date`、`buyer`、`totalAmount` 四个字符串。完整查询未命中返回 `status:"absent"` 和 `infoId:null`。仅在唯一实体的详情核对通过、明确未占用且未删除时返回 `status:"matched"` 和真实 `infoId`，两种成功结果的 `scope` 都为 `operator-visible`。覆盖不完整、多实体、事实不一致或状态未证实时返回错误。结果只证明此次可见池的匹配，后续关联仍需在实际写入前重新校验。

## 固定来源与认证

来源为 xasp `origin/codex/expense-draft-hardening-20261014` 的提交 `eaf64280a69e0f1889c44cb52d077faf045d7152`，`packages/sdk/src/oa_sdk/api/invoice/service.py` 及实际 HTTP transport 测试。当前另一分支 e5ece87 的 SDK 缺少这两个方法，不能用其缺失来否定既有协议。来源摘要及真实验证登记在开发里程碑。

继续使用独立 OA OpenAPI 应用会话及显式核验的操作者；不使用参考 weaver CLI 的 Cookie、ETEAMSID 或 invoice token。路径追加在已配置 base（包含 `/papi/openapi`）之后，以下两项均为 POST：

| Operation | 路径 | 固定请求 |
| --- | --- | --- |
| `oa.invoice.query` | `/api/inc/biz/v1/sync` | JSON `content=number,sreim="0",mask=281474976710655,mext=524287,page_size,start_pos,bill_type=0,req_type=1,flag=0,userid` |
| `oa.invoice.inspect` | `/api/inc/biz/v1/get` | JSON `ids:[infoId],userid` |

两处 `userid` 都是核验后的十进制**字符串**：JSON 和 query 各一份；token 仅由运行时加到 query。tenantKey header 来自同一固定连接配置，不接受业务覆盖。这与 workflow 写入的数字 userid 编码不同，应按端点契约分别执行。没有 `req_base`、`number` 筛选参数、`userFlag/isDelFlag`。

`/api/inc/get`、`/api/inc/sync` 是不同的 Web 路径，不替代本契约的版本化 OpenAPI 路径；这些路径上的100010不能用来断言正确接口也被拒绝。遇到正确路径的认证/业务拒绝仍返回实际错误，不换凭据或猜其它路径。

## 输入与读取范围

query 的 number 为20位字符串（保留前导零，排除全零）；pageSize 1–100，maxPages 1–10。底层 content 可能模糊匹配，输出只保留票号逐字相等的记录，分页覆盖以已扫描记录数计。sreim固定为查询全部报销状态，而不是仅未报销。

inspect接受已知OA infoId，只读唯一实体，不把附件fileId当票据ID、不猜实体或切换操作者。CLI/API共用执行器；MCP作为写入流程配套读取，须启动allow-write，不消费写确认或稳定键。

## 响应及失败

外层必须为 `message.errcode=0,data:{...}`。query 的 total 必须是明确的非负安全整数；数值原文由传输保留后再严格解析。生产已观察到空结果为 `data:{total:0}`，仅明确零总数允许缺失/null infos 归一为空；正总数必须有数组。

分页要求总数稳定、实体 ID 不重复、每页长度与剩余数一致。达到页数预算返回 `coverage.complete=false,nextStart`，不称全部完成；页不一致失败，不返回误导的部分成功。coverage 的范围固定为 `operator-visible`，只覆盖本次查询，不能当作全租户或历史草稿的原子防重保证。

inspect 必须只有一个 infos 项、逐项 `ret.ret=0`，且 `info.id` 等于请求 ID。若同时出现 fid/id 必须一致，避免业务标识混用。嵌套业务失败、缺标识、响应冲突和超限明确报错，不自动重试。

输出最小投影包括 id/number/code/date/totalAmount，以及原文 `sreim,treim,zreim,reimingMoney,reimedMoney`。数字 ID、金额和状态保留原始词法字符串；缺值为 null，不把缺失的已用金额补零。列表筛选码与票据状态码不是同一语义。`eligibility` 恒为 `unknown`：找到票据或读到0都不是报销资格、验真或未占用承诺。

测试 OA 的票池和详情均已观察到明确未占用且未删除时，`treim`、`zreim` 同时为精确空字符串。匹配和关联只有在完整票池和精确详情均出现该组合、状态都为 `sreim=0` 和 `del=0`、票面事实一致且其他占用金额无冲突时接受。单个空值、缺字段、`null`、占用和删除仍按原规则处理。公开查询继续把空金额投影为 `null`。
无关字段、票面原文、购买方、附件链接与上游错误文本不透传。HTTP/业务失败及取消保持现有错误/总时限契约；没有 Cookie、权限修改、入库、上传或创建流程的回退。
