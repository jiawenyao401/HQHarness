# 差旅草稿的发票专栏关联

`oa.expense.invoice.link`（`oa expense invoice link`）为既有差旅草稿追加已核实的发票实体，服务M3.2/M3.3。本动作独立于完整财务：缺少银行、收款或全部逐日行程时，仍可把真实发票放入专用发票栏，保持`businessComplete:false`。开发状态统一见[里程碑](../development-milestones.md)。

新建差旅任务由 [Workflow Skill 流程](expense-workflow.md)在草稿和票据准备好后调用独立关联操作。本文规定关联的输入、作用域与恢复契约。

输入为`{mode:"invoice-link",targetRequestId,expectedRevision,invoices}`。每票显式提供`infoId/number/date/buyer/totalAmount/description`；`claimedAmount`仅在本次含税申领额已确认时提供，限1–100张，ID及票号唯一；金额为两位小数字符串；提供申领额时须为明确正金额且不超过票面总额，未确认则省略。不从票面自动推定可报额。不需要银行、行程、费用分摊；不接受操作者、任意表单、HTTP路径或字段覆盖。

先用`oa.expense.inspect`取得同一目标当前revision。发票必须已按[专用入库契约](invoice-save.md)保存，或由当前操作者票夹精确查询并完整inspect确认；普通附件fileId、上传处理回执、预览ID或失败行ID不作infoId。既有未决保存不能重放。新关联派发前核对同票唯一可见、票面事实完全一致、明确未占用且未删除；草稿阶段允许验真未知，不意味着完整财务/正式提交可跳过验真。

占用证据不足时返回 `OA_EXPENSE_INVOICE_USAGE_UNKNOWN`。其中 `error.details.issues` 可定位票池结果或票据详情记录中缺失或无效的字段路径，省略源值及票据信息。当前关联停止在派发前，保留已保存的草稿和已回读的入库结果。

```sh
huaqing schema oa.expense.invoice.link --format json
huaqing oa expense invoice link --dry-run --input '/absolute/invoice-link.json' --format json
huaqing operations prepare oa.expense.invoice.link --input '/absolute/invoice-link.json' --idempotency-key TASK_INVOICE_LINK --format json --non-interactive
huaqing operations apply EXECUTION_ID --input '/absolute/invoice-link.json' --yes --format json --non-interactive
huaqing operations status EXECUTION_ID --format json --non-interactive
huaqing operations reconcile EXECUTION_ID --input '/absolute/invoice-link.json' --format json --non-interactive
```

prepare只读，不上传或保存。实际写入仍要求当前任务授权与显式确认。direct `--yes --idempotency-key` 与prepare/apply共用执行器；MCP仅在allow-write下提供，不读取本地原件。

已核实的保存协议为POST `/api/workflow/core/paService/v1/saveFormData`，携带运行时精确userid、精确requestId及稀疏formData。只追加发票子表`1261248478487396359`，每张票同一正dataIndex的已知字段：`1261248478487396360`仅`dataOptions:[{optionId:真实infoId}]`，日期`1261248478487396361`、已确认时才写申领额`1261249637910462469`、购买方`1297967841852219392`、说明`1261490955110727680`。EInvoice option不发送content；旧源明确记录该值会导致上传发票栏为空。来源为xasp `travel_expense.py` build_form_data及`oa-travel-expense/references/pitfalls-form.md`，与既定完整差旅五字段相同。

目标要求固定模板、当前操作者创建、可编辑且待提交，输入 `revision` 须精确匹配。操作保全旧发票行、普通附件、人员、账户、金额、行程、未知字段、选项及物理行身份。新建任务按报销 Skill 取得真实票据实体 ID 后调用本操作，兼容的混合材料调用也使用同一专用票据通道。历史重复挂载需要定位同一原件及具体引用，再单独修正。新票行追加到既有发票行之后，成功以回读新行和未触数据为准。

输出`linkedToDraft:true`仅在精确新票行与全部未触数据回查通过后返回，`revision`为当前快照摘要；cached不是新回查，`preservedFieldsMatched`仅live为true。`invoiceCount`仅本次新关联数；`authenticityVerified`与“已关联”分开，未知或缓存不补造结论。`claimAmountsConfirmed`和`pendingClaimCount`明确哪些申领额仍未知；未知格只允许省略、空白或零默认，零不作真实申领额，非零自动填值不能当成确认。`businessComplete`恒false，不提交、不审批、不补财务。

本地先持久化执行与步骤，再只派发一次`link-invoice-data`保存，按目标及票号摘要占用资源；输入/目标/元数据变化拒绝旧计划。成功可向同目标后续complete转移，未决及同票跨目标保持阻断。丢回执或回查失败保留执行和目标，status/reconcile仅观察原对象；不重建草稿、不换键重写、不将uncertain历史改成成功。
