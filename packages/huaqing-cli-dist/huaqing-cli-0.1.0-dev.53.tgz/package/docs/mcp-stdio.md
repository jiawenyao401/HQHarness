# MCP stdio 接入

通过同一个安装包运行 `huaqing mcp serve --stdio`，宿主通过 stdin/stdout 交换 MCP 消息。工具从 operation 目录投影，调用同一 `execute()`；OA 认证、人员规则、参数和结果校验仍由原实现负责。无需 A 会话或特定 Harness 的身份文件。

## 启动

```sh
node /absolute/安装目录/dist/cli.js mcp serve --stdio \
  --config /absolute/配置/config.json --profile oa-profile \
  --tools system.info,auth.status,oa.workflow.todo,oa.workflow.detail \
  --timeout 30000
```

`--tools`使用逗号分隔的 **operation ID**；省略时选择当前已启用且显式开放的operation。默认启用登记的只读集合，按OA/A/QCC连接过滤；写入流程及其配套票据/恢复工具须启动时加`--allow-write`，读本机材料的工具还须明确`--file-root`。未知、重复、空白或缺少相应授权的ID在启动时拒绝。它控制本进程工具范围，不能授予上游权限。

`--timeout` 为每次工具调用的总预算上限，范围 1–300000 毫秒，默认 30000。MCP 的 stdin/stdout 由协议占用，不接受 `--input`、`--json`、`--output` 或 `--format`；启动错误只写安全的 stderr 诊断。`mcp serve --help` 可离线使用。

宿主需要传入的进程配置示意：

```json
{
  "command": "/absolute/path/to/node",
  "args": [
    "/absolute/安装目录/dist/cli.js", "mcp", "serve", "--stdio",
    "--config", "/absolute/配置/config.json", "--profile", "oa-profile",
    "--tools", "system.info,auth.status,oa.workflow.todo,oa.workflow.detail"
  ],
  "env": {
    "HUAQING_STATE_HOME": "/absolute/私有状态目录",
    "HUAQING_CREDENTIAL_STORE": "encrypted-file",
    "HUAQING_CREDENTIAL_MASTER_KEY_FILE": "/absolute/独立密钥目录/master-key"
  }
}
```

按宿主要求把上述进程设置放进其 MCP 配置中。密钥文件和状态目录使用运行用户的私有权限；配置中的 appKeyRef/appSecretRef 引用也必须能在该进程环境中解析。示例只说明进程字段，具体产品/版本接入仍按 M4.4 实测。

首次 OA 登录通过原 CLI 的 `auth login` 完成，使用相同 config/profile、状态目录及凭据后端。MCP 不暴露登录、退出或修改默认 profile；既有读取仍可能刷新应用会话、保存人员核验证据并产生退出码 11 的未决状态，不能把“远端业务只读”理解为本地状态完全不变。

启用已经交付的写入和恢复工具，例如修订既有草稿：

```sh
huaqing mcp serve --stdio --allow-write \
  --config /absolute/config.json --profile oa-profile \
  --tools oa.expense.amend,operations.prepare,operations.apply,operations.status,operations.reconcile
```

需处理PDF/图片原件时，另外重复提供`--file-root /absolute/private-materials`。只配置材料目录，不把凭据、状态或整个文件系统作为材料根。事由修订等不读本机文件的工具不要求材料根；混合prepare/apply/reconcile若收到含文件的业务输入，仍由实际读取处执行同一根授权。

## 工具与发现

| operation ID | MCP 工具名 | 可用条件 |
| --- | --- | --- |
| `system.info` | `huaqing_system_info` | 无账号、无配置可用 |
| `auth.status` | `huaqing_auth_status` | 固定 profile 配置了 OA 连接 |
| `oa.person.resolve` | `huaqing_oa_person_resolve` | 同上；读取时仍校验认证 |
| `oa.identity.show` | `huaqing_oa_identity_show` | 固定 profile 配置了 OA 连接 |
| `oa.workflow.todo` | `huaqing_oa_workflow_todo` | 同上；读取时重新核验操作者 |
| `oa.workflow.detail` | `huaqing_oa_workflow_detail` | 同上；读取时重新核验操作者 |
| `oa.workflow.fields` | `huaqing_oa_workflow_fields` | 同上；读取明确 form ID 的字段元数据，不授予写入能力 |
| `oa.workflow.search` | `huaqing_oa_workflow_search` | 配置 OA 连接，传 `resolveForm:true` 可在唯一命中时同时返回表单和字段 |
| `oa.workflow.draft.create` | `huaqing_oa_workflow_draft_create` | 固定 profile 配置获准的 `workflowDrafts`，启动时开放写入，调用时传确认和稳定任务键 |
| `oa.workflow.travel.application.draft` | `huaqing_oa_workflow_travel_application_draft` | 启动时开放写入。使用 `--tools` 的宿主需列入该 ID。调用时需要目标 OA 连接的 `travelApplication` 绑定、确认和稳定任务键 |
| `agentos.me`、`knowledge.context/search/document.get` | 同一ID转换规则 | 配置独立agentos连接；首次登录须同profile CLI，调用仍受A资源ACL限制 |
| `qcc.tools.list`、`qcc.company.search/detail` | 同一ID转换规则 | 配置qcc连接；企业工具还须显式批准真实schema，可能计费 |

华清服务端发现不解析秘密、不登录、不请求远端；`qcc.tools.list`本身是显式查询供应商目录的业务工具。仅配置了连接不证明权限。调用再次核对允许集合和配置能力，不能通过猜名执行隐藏写工具、auth.login或profile.use。`auth.status`保留OA连接条件；只有A的profile可用同上下文CLI `auth status --provider agentos`查询本地会话。

显式`--allow-write`后，目录中标注的业务写入及prepare/apply/status/reconcile工具才能发现和调用。已开放的材料核对只需`--file-root`，无需业务写许可。直接上传/发票保存工具没有材料根时不公开。写入注解按真实effects投影，status/票据查询等配套读取仍为readOnly；注解是提示，不能代替共同执行器的确认、身份或幂等检查。

实际 profile 名和进程环境变量快照在启动时固定；其他进程修改默认 profile 不会让运行中的 MCP 切换账号。每次 list/call 重新读取配置；一次 call 的能力检查和业务执行使用同一份配置快照。连接被移除或配置无效时明确失败，不回退到其他 profile。修改启动参数、进程环境或工具允许集合后须重启进程；同一 profile 的连接配置变更在下一次调用读取。

## 参数与结果

每个工具的 arguments 使用两层结构：

```json
{
  "input": {"page": 1, "pageSize": 20},
  "execution": {"timeoutMs": 10000}
}
```

`input`必填，其schema直接来自对应operation，可通过`huaqing schema ID`离线查看。无业务参数时传`{"input":{}}`。所有工具的execution可指定timeoutMs，它只能缩短启动预算；只读工具不接受写入选项。直接业务写入接受confirm、idempotencyKey和dryRun；prepare只额外接受idempotencyKey，apply只额外接受confirm，status/reconcile仅接受timeoutMs。两层均拒绝未知字段，config/profile/env、操作者、roots或任意CLI flags不能从tool arguments覆盖。

```json
{
  "input": {"targetRequestId":"123","updates":{"reason":{"expected":"原事由","value":"已核实新事由"}}},
  "execution": {"confirm":true,"idempotencyKey":"task-amend-001","timeoutMs":30000}
}
```

确认和稳定键由原业务执行器检查：未确认返回10，direct缺稳定键返回2；只写allow-write不能绕过这些条件。prepare返回executionId后，apply须原输入、该ID及confirm=true；强杀或退出11后保持原键/输入，通过status与只读reconcile核实，不换键重放。

成功及业务失败都返回相同的 CLI envelope，放在 `structuredContent` 中，并以相同 JSON 写入一条 text content，兼容只能读取文本的宿主。`outputSchema` 同样包装 envelope，其 data 复用 operation 的输出 schema。MCP `_meta["huaqing/exitCode"]` 给出对应 CLI 退出码；它不是 MCP 服务器进程的退出码。

业务错误返回 `isError: true`，例如输入 2、认证 3、权限 4、超时 5、未决 11。未知/隐藏工具及不支持的方法属于协议错误。原始异常、凭据和上游正文不写进协议错误或 stderr；合法业务数据仍可能敏感，由宿主控制展示和保存。

`meta.requestId` 仍是 CLI 调用追踪 ID；JSON-RPC id、OA 申请单 ID 和后续 M3 executionId 分别使用，不可互换。错误处理与 auth.status/identity.show 的恢复原则见 [通用进程指南](harness-process.md)。

## 取消和连接生命周期

客户端取消通知经 SDK 传给同一个业务 AbortSignal，停止后续步骤。SDK 在请求取消或连接关闭后抑制该请求的回包，因此客户端不能期待额外的退出码 130 envelope；取消也不撤销已发送的请求。需要确认认证状态时，保持连接并另发 auth.status，或使用相同配置的 CLI 查询。

服务器自身的工具期限没有取消 JSON-RPC 请求，仍会返回正常的错误结果。认证轮换结果不明时保留 `status=uncertain`、退出码 11 和 `retryable=false`；不以普通超时覆盖。服务端 Adapter 不增加自动重试，现有安全业务读取保留原有有限重试规则。

业务已完成持久提交并返回确定成功时，外层迟到期限不把该结果重写成普通超时。写入派发后的丢响应/取消/超时仍由执行记录返回11和已知回执；普通写工具TIMEOUT也不标为可自动重试。客户端取消后SDK是否发送最终回包仍按协议处理，结果未收到不能解释为没有执行。

QCC企业查询虽为read，也标记metered：已收到的结果保留，外层TIMEOUT不标可重试；tools/call派发后未决退出11，不能按普通读取循环重试。原始供应商result保持businessStatus=unclassified；isError及quotaMayBeConsumed均须核对。OA 文件下载、知识库授权下载、Skills导出、状态运维与外部MCP通用包装仅提供标准进程入口。OA 文件元数据使用只读工具 `huaqing_oa_file_info`。

期限限制等待和后续步骤，不能抢占 JavaScript 同线程的同步校验；这部分工作由输入上限约束。与 CLI 一致，已确定的配置、权限或业务错误保留原类别，受控取消才按对应期限原因映射为超时，未决结果始终优先。不能仅凭调用耗时推断应收到哪一错误码。

宿主应在读完所需响应后关闭 stdin。EOF 或进程终止会取消在途工作并关闭连接；如果没有收到最终结果，按可能已经派发处理，通过现有状态入口核实，不能直接重放写操作。

连接采用有界传输：输入帧上限 8 MiB + 64 KiB（包含协议字段），最多 32 个在途请求/handler、待决请求总字节最多 64 MiB；单次事件循环批次最多 64 条消息。单响应最多 32 MiB、待发送总量最多 64 MiB，输出背压及退出收尾预算分别为 5 秒。无效 JSON/UTF-8、不完整 EOF、重复在途请求 ID 或超限会关闭连接并输出固定安全诊断，不伪造业务成功。宿主应控制并发和读取 stdout；断连后核实已有请求状态。

## 协议与范围

锁定官方 TypeScript SDK server/core 2.4.0，使用 `serveStdio` 处理现代 `2026-07-28` 和旧版 `2025-11-25` 的连接生命周期。现代客户端使用 `server/discover` 及每请求的协议元数据；旧版客户端使用 initialize/initialized。版本、resultType 和编码由 SDK 处理，不另外实现 JSON-RPC 路由。[官方 stdio 实现](https://github.com/modelcontextprotocol/typescript-sdk/blob/v2.4.0/packages/server/src/server/serveStdio.ts)

材料根由部署方在启动参数明确提供，最多16个现有目录；默认没有根即拒绝全部业务材料读取。根固定canonical位置和目录身份，实际快照读取处在打开前后核对根/祖先身份、文件引用和稳定字节；路径逃逸、最终符号链接、根替换和文件变动均拒绝，图文仍遵循原件类型/大小/摘要限制。POSIX拒绝组/其他用户可写的材料目录；Windows ACL由部署方设置。配置与凭据引用是独立的启动授权，不受业务输入扩权。

固定SDK在现代2026-07-28协议不支持旧式server→client listRoots请求，因此本实现统一使用静态部署根，兼容现代与旧宿主，不要求roots能力或额外握手。该策略是业务路径授权，不是对同UID恶意本机进程的OS沙箱；材料目录须由可信写入者保持稳定，不承诺敌对本机并发下原子beneath约束。

新增工具的真实宿主、跨平台及生产写入验收由统一里程碑记录；代码或本机替身通过不等于所有Harness已经验收。
